---
name: Standalone social media
description: Reliable demo imagery and video in Replit previews without third-party media hosts.
---

For standalone social experiences, visual content should remain renderable without depending on redirecting or unavailable image-host endpoints; self-contained SVG/data visuals are a reliable fallback for editorial tiles, stories, and feed media.

**Why:** Preview screenshots exposed broken-image placeholders when the initial source-image endpoint was unavailable, which made an otherwise polished interface look unfinished.

**How to apply:** Prefer generated local assets or self-contained SVG/data URIs for sample content unless the project explicitly depends on a real media API or object storage.

For playable demo Reels, bundle VP8/Opus WebM files instead of relying on H.264/AAC MP4, even if the latter serves successfully.

**Why:** The preview browser rejected a valid, locally served H.264 MP4 with `DEMUXER_ERROR_NO_SUPPORTED_STREAMS`, while transcoding the same footage to VP8/Opus WebM made playback and sound controls work. Cross-origin sample video hosts were also blocked in the preview.

**How to apply:** Prefer local WebM assets for sample playback in this environment; check media decoding in a fresh browser session, not only HTTP status or FFprobe output.