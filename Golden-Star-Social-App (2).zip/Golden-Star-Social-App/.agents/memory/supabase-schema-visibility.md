---
name: Supabase schema visibility
description: SQL Editor success is not proof that Golden Star Pro's REST endpoint sees the migration.
---

Treat a successful Supabase SQL Editor migration and visibility through the
app's Data API as separate checks. Verify required columns and tables through
the configured app endpoint before declaring a live feature ready.

**Why:** In this project, SQL Editor checks reported the new column and table,
while both the connected REST API and the running app's API URL still reported
the pre-migration schema after an explicit PostgREST cache refresh. The cause
was not established; repeating the same SQL blindly would not resolve the
uncertainty.

**How to apply:** Probe a newly added column and table using the app's actual
REST endpoint, reporting only status/error codes. If SQL and REST disagree,
investigate project/branch targeting and Data API schema visibility before
testing dependent user flows.

For public Live, keep the database-backed status and events when the Data API
works, but allow a Realtime Presence/Broadcast path when those tables are not
visible. Viewer access to Agora in that path must use a short-lived,
server-signed proof issued only to an authenticated host; hiding a schema
error must never silently turn live video into a local preview.

**Why:** The user specifically wanted Go Live functional without changing the
app design while SQL Editor and the Data API disagreed. Presence was verified
across two clients, while direct REST reads still failed.

**How to apply:** On future live changes, preserve authenticated Agora tokens,
real remote streams, and the database path when available. Do not treat an
unverified local camera preview as a successful broadcast.