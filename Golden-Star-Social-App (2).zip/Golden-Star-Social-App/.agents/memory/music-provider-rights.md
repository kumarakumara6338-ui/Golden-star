---
name: Music provider rights
description: Honest catalog counts and the boundary between previews, declared licenses, and reel soundtrack permissions.
---

Never generate fake song inventories or imply that a large provider catalog
establishes language-specific counts. Show live query counts with their actual
unit: Archive searches can count albums/recordings, not individual playable
MP3 tracks. iTunes searches cap results per query and provide no global total.

**Why:** The user requested 50,000+ real songs and fixed language counts; the
available providers do not establish those language totals. Invented entries
or reused audio under different names would misrepresent the catalog.

**How to apply:** Keep discovery live and paginated. Treat unsupported counts
as unknown, and clarify when resolving an album selects its first playable MP3.

iTunes previews are promotional content, not reel soundtracks. Keep them
proximate to their store links and do not offer attachment/download/mixing.
Archive CC0/Public Domain metadata is uploader-declared, not independently
verified ownership or a blanket guarantee of copyright safety.

**Why:** Apple restricts promotional previews from saving or synchronizing with
video. Internet Archive can contain inaccurate rights declarations, including
commercial songs incorrectly labelled public domain.

**How to apply:** Resolve and inspect license metadata before selecting Archive
audio, keep rights disclosures visible, and never claim “100% No Copyright.”
Any guaranteed-safe catalog needs rights-cleared provenance beyond metadata.