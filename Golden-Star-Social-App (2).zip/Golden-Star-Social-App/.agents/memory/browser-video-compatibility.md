---
name: Browser video compatibility
description: Why valid MP4 files may fail in the Replit preview browser and how to choose reliable media.
---

For locally hosted video in the Replit preview browser, prefer VP9/Opus WebM over assuming H.264/AAC MP4 will play.

**Why:** Valid, range-served MP4s from multiple sources produced a browser demuxer "no supported streams" error despite responding with the correct content type and HTTP 206. Converting short clips to VP9/Opus WebM made playback and sound work. Remote videos can also be blocked by the preview browser's response-origin policy.

**How to apply:** When building video playback, verify actual browser media readiness and advancing playback time, not just HTTP status or file metadata. Host playable clips locally when remote-origin media fails.