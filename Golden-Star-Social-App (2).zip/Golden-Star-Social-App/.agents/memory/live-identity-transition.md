---
name: Live identity transition
description: Why added authentication providers preserve existing accounts and do not silently attach browser data.
---

Shared live identity was approved as the replacement for browser-only demo login.
Do not automatically attach old local posts or chats to the first new shared
account signed in on a device.

Preserve existing Supabase email accounts when adding Firebase authentication.
Firebase accounts are additional identities, not an implicit migration or a
same-email account merge. Provider-specific password recovery must target the
provider that owns the account.

**Why:** The user explicitly chose to keep existing email accounts rather than
move all authentication to Firebase. Matching an email address is not proof
that two provider identities should share browser data.

**Why:** The legacy data belongs to an unverified local identity. Automatically
associating it with a new remote account on a shared device could expose another
person's content. Old data should remain intact until its owner explicitly
chooses an import.

**How to apply:** Future cross-device data migration should verify ownership and
ask for an explicit import choice before copying legacy browser content.