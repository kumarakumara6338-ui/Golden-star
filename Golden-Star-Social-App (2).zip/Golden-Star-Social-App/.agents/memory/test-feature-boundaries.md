---
name: Test feature boundaries
description: Why demo phone and social features remain separate from real account security and live broadcasts.
---

Keep phone test identities isolated from Supabase accounts. Demo camera sessions
must be visibly labelled as local previews, not broadcasts. Local follows,
reports, blocked-user filtering, and PIN challenges must not be described as
shared-user access control, delivered moderation reports, or real account MFA.
Never show an enabled end-to-end-encryption claim for browser-only chat.

**Why:** The user explicitly chose a working test version after being told that
the mock OTP cannot protect real accounts and browser-only data cannot enforce
cross-device blocking or encrypted messaging.

**How to apply:** Preserve those boundaries when adding test features or
changing login flows. Real email authentication and Agora broadcasting remain
separate. Only promote a security label when its actual implementation exists.

Do not reintroduce provider-backed AI without an explicit request. The user
chose to remove the external assistant and keep only the green local helper.
Limit
privacy and cost claims to the local helper's processing; do not claim the
entire app shares no data or has no operating costs. Mark supplied reward
amounts and withdrawal times as unverified unless a real rewards system
establishes them.

**Why:** The user explicitly chose local-only assistance. The original FAQ
request included absolute privacy/free-AI claims and earnings promises, while
the app uses external authentication. Those labels would misrepresent the app.

**How to apply:** Keep local answers offline, unsaved, and clearly described as
preset information. Do not add an external assistant or a second launcher as
a fallback.