# Finish the Golden Star Pro live setup

The Supabase REST connection cannot alter database tables. The connected project
already has a `live_users` table, but does not yet have its required `user_id`
or `started_at` columns. **Live cannot go on air until this migration is run.**

1. Open the Supabase project that owns the app's `VITE_SUPABASE_URL` and
   `VITE_SUPABASE_PUBLISHABLE_KEY`. It must be the same project as the connected
   Supabase REST integration.
2. Open **SQL Editor**, paste all of [`live.sql`](./live.sql), and run it once.
   This extends `live_users` in place; it does not delete its existing rows.
   Review any existing policies on that table before running it, because
   pre-existing permissive policies are not removed by this migration.
3. Confirm **Authentication → Providers → Email** is enabled (it was enabled
   when this integration was inspected). New users must verify their email.
4. Open the web app over HTTPS on two phones. Sign up with two distinct
   accounts, start live from one, and watch from the other.

If SQL Editor shows the columns and table but the app still says they are
missing, check the **API URL of the SQL Editor project** against the app's
`VITE_SUPABASE_URL`, including any project branch. Then run
`NOTIFY pgrst, 'reload schema';` in that project's SQL Editor and check the
Data API again. A successful SQL query in one database does not prove that
the app's REST endpoint sees the same schema.

Agora video uses `VITE_AGORA_APP_ID` in the browser and the
`AGORA_APP_CERTIFICATE` **only on the API server** to issue short-lived tokens.
Do not put the certificate in client code. "Add song" streams an audio file
chosen from the broadcaster's device, mixed with their microphone; it does
not fetch or rebroadcast audio from YouTube. Gifts are free in-app reactions,
not payments.

The prior demo's accounts, posts and chats remain in each original browser's
storage; they are not automatically transferred into a newly verified shared
account, nor do old local posts and chats become cross-device content.