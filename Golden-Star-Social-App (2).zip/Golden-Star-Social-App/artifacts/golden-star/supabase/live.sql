-- Run once in the Supabase SQL Editor for the project connected to Golden Star Pro.
-- The existing live_users table is extended in place; existing rows are not removed.
create table if not exists public.live_users (
  user_id uuid unique references auth.users(id) on delete cascade,
  is_live boolean not null default false,
  started_at timestamptz,
  display_name text,
  song_title text,
  last_seen_at timestamptz
);

alter table public.live_users
  add column if not exists user_id uuid references auth.users(id) on delete cascade,
  add column if not exists started_at timestamptz,
  add column if not exists display_name text,
  add column if not exists song_title text,
  add column if not exists last_seen_at timestamptz;

create unique index if not exists live_users_user_id_unique on public.live_users (user_id);
alter table public.live_users enable row level security;

drop policy if exists "Golden Star live users read" on public.live_users;
create policy "Golden Star live users read" on public.live_users
  for select to authenticated using (true);
drop policy if exists "Golden Star live users create" on public.live_users;
create policy "Golden Star live users create" on public.live_users
  for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Golden Star live users update" on public.live_users;
create policy "Golden Star live users update" on public.live_users
  for update to authenticated using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create table if not exists public.live_events (
  id bigint generated always as identity primary key,
  live_user_id uuid not null references auth.users(id) on delete cascade,
  sender_user_id uuid not null references auth.users(id) on delete cascade,
  sender_name text not null,
  event_type text not null check (event_type in ('chat', 'like', 'gift')),
  message text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists live_events_recent on public.live_events (live_user_id, id desc);
alter table public.live_events enable row level security;
drop policy if exists "Golden Star live events read" on public.live_events;
create policy "Golden Star live events read" on public.live_events
  for select to authenticated using (true);
drop policy if exists "Golden Star live events send" on public.live_events;
create policy "Golden Star live events send" on public.live_events
  for insert to authenticated with check (
    auth.uid() = sender_user_id
    and length(message) <= 400
    and exists (
      select 1 from public.live_users
      where user_id = live_user_id and is_live = true
        and last_seen_at > now() - interval '60 seconds'
    )
  );

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'live_users'
  ) then
    alter publication supabase_realtime add table public.live_users;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'live_events'
  ) then
    alter publication supabase_realtime add table public.live_events;
  end if;
end $$;

-- The app's existing Delete account action must remove the real account, too.
create or replace function public.delete_my_account()
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  delete from auth.users where id = auth.uid();
end $$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;