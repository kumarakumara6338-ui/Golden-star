import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ExternalLink, Loader2, Music2, Pause, Play, Search, Check } from 'lucide-react';
import { searchMusic, resolveMusicTrack } from '@workspace/api-client-react';
import type { MusicTrack } from '@workspace/api-client-react';
import './music-catalog.css';

export type { MusicTrack };
type Source = 'archive' | 'itunes';
const langs = ['all', 'Kannada', 'Hindi', 'Tamil', 'Telugu', 'Malayalam', 'English'] as const;
type Cat = { id: string; label: string; language: (typeof langs)[number]; category: 'all' | 'trending' | 'no-copyright' };
const cats: Cat[] = [
  ...langs.map(l => ({ id: l, label: l === 'all' ? 'All' : l, language: l, category: 'all' as const })),
  { id: 'no-copyright', label: 'No Copyright', language: 'all', category: 'no-copyright' },
  { id: 'trending', label: 'Trending', language: 'all', category: 'trending' },
];
const ROW = 68, VIEW = 340, PAGE = 50;

export default function MusicCatalog({ onChoose, selectedId, testPrefix = 'music', chooseLabel = 'Use', archiveOnly = false, onBusyChange, disabled = false }: {
  onChoose?: (track: MusicTrack) => void; selectedId?: string | null; testPrefix?: string; chooseLabel?: string; archiveOnly?: boolean; onBusyChange?: (busy: boolean) => void; disabled?: boolean;
}) {
  const [input, setInput] = useState('');
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('all');
  const [source, setSource] = useState<Source>('archive');
  const selectCat = (id: string) => { setCat(id); if (id === 'no-copyright') setSource('archive'); };
  const selectSource = (v: Source) => { if (archiveOnly && v !== 'archive') return; setSource(v); if (v === 'itunes' && cat === 'no-copyright') setCat('all'); };
  const [items, setItems] = useState<MusicTrack[]>([]);
  const [next, setNext] = useState<number | undefined>(0);
  const [hasMore, setHasMore] = useState(false);
  const [total, setTotal] = useState<number | undefined>();
  const [notice, setNotice] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [scroll, setScroll] = useState(0);
  const [playing, setPlaying] = useState<MusicTrack | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [rowError, setRowError] = useState('');
  const busyCb = useRef(onBusyChange);
  busyCb.current = onBusyChange;
  const isBusy = busyId !== null;
  useEffect(() => { busyCb.current?.(isBusy); return () => busyCb.current?.(false); }, [isBusy]);
  const gen = useRef(0);
  const actGen = useRef(0);
  const actCtrl = useRef<AbortController | null>(null);
  const cancelActions = () => { actGen.current++; actCtrl.current?.abort(); actCtrl.current = null; setBusyId(null); };
  useEffect(() => () => { actGen.current++; actCtrl.current?.abort(); }, []);
  const ctrl = useRef<AbortController | null>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const sentinel = useRef<HTMLDivElement>(null);
  const loadingRef = useRef(false);
  const nextRef = useRef<number | undefined>(0);
  const hasMoreRef = useRef(false);
  const itemsLen = useRef(0);

  useEffect(() => { const h = window.setTimeout(() => setQ(input.trim()), 350); return () => window.clearTimeout(h); }, [input]);

  const load = useCallback(async (reset: boolean) => {
    if (!reset && (loadingRef.current || !hasMoreRef.current)) return;
    if (reset) { ctrl.current?.abort(); gen.current++; }
    const my = gen.current;
    const c = cats.find(x => x.id === cat)!;
    const ac = new AbortController();
    ctrl.current = ac;
    loadingRef.current = true; setLoading(true); setError('');
    try {
      const res = await searchMusic({ q: q || undefined, language: c.language, source, category: c.category, limit: PAGE, offset: reset ? 0 : nextRef.current ?? 0 }, { signal: ac.signal });
      if (my !== gen.current) return;
      const base = reset ? [] : itemsRef.current;
      const seen = new Set(base.map(i => i.id));
      const merged = [...base, ...res.items.filter(i => !seen.has(i.id))];
      itemsRef.current = merged; itemsLen.current = merged.length;
      setItems(merged);
      nextRef.current = res.nextOffset; hasMoreRef.current = !!(res.hasMore && res.nextOffset !== undefined);
      setNext(res.nextOffset); setHasMore(hasMoreRef.current); setTotal(res.total); setNotice(res.notice);
    } catch (e) {
      if (my === gen.current && (e as Error).name !== 'AbortError') setError('Could not load music. Check your connection and retry.');
    } finally {
      if (my === gen.current) { loadingRef.current = false; setLoading(false); }
    }
  }, [q, cat, source]);
  const itemsRef = useRef<MusicTrack[]>([]);

  useEffect(() => {
    cancelActions(); setPlaying(null); setRowError('');
    itemsRef.current = []; itemsLen.current = 0; nextRef.current = 0; hasMoreRef.current = true;
    setItems([]); setHasMore(false); setTotal(undefined); setScroll(0);
    if (boxRef.current) boxRef.current.scrollTop = 0;
    void load(true);
    return () => ctrl.current?.abort();
  }, [load]);

  useEffect(() => {
    const el = sentinel.current, root = boxRef.current;
    if (!el || !root || typeof IntersectionObserver === 'undefined') return;
    const io = new IntersectionObserver(es => { if (es[0].isIntersecting) void load(false); }, { root, rootMargin: '200px' });
    io.observe(el);
    return () => io.disconnect();
  }, [load, items.length]);

  const start = Math.max(0, Math.floor(scroll / ROW) - 4);
  const end = Math.min(items.length, Math.ceil((scroll + VIEW) / ROW) + 4);
  const visible = useMemo(() => items.slice(start, end), [items, start, end]);

  const resolve = async (t: MusicTrack): Promise<MusicTrack | null> => {
    cancelActions();
    const my = actGen.current, ac = new AbortController();
    actCtrl.current = ac;
    setBusyId(t.id); setRowError('');
    try {
      const r = await resolveMusicTrack({ id: t.id }, { signal: ac.signal });
      if (my !== actGen.current) return null;
      if (!r.reelSafe || !r.audioUrl) throw new Error('unverified');
      return r;
    } catch { if (my !== actGen.current) return null; setRowError(`“${t.title}” could not be verified as a playable CC0/Public-domain MP3. It was not used.`); return null; }
    finally { if (my === actGen.current) setBusyId(null); }
  };
  const play = async (t: MusicTrack) => {
    if (playing?.id === t.id) { cancelActions(); setPlaying(null); return; }
    cancelActions(); setPlaying(null);
    if (t.provider === 'itunes') { if (t.audioUrl) setPlaying(t); else setRowError('No preview available for this store item.'); return; }
    const r = await resolve(t);
    if (r) setPlaying(r);
  };
  const choose = async (t: MusicTrack) => {
    if (disabled || t.provider !== 'archive' || !t.reelSafe || !onChoose) return;
    setPlaying(null);
    const r = await resolve(t);
    if (r) { setPlaying(null); onChoose(r); }
  };

  return <div className="mc" data-testid={`${testPrefix}-catalog`}>
    <div className="mc-switch" role="group" aria-label="Music source">
      <button type="button" className={source === 'archive' ? 'on' : ''} aria-pressed={source === 'archive'} onClick={() => selectSource('archive')} data-testid={`${testPrefix}-source-archive`}>CC0 / Public-domain</button>
      {!archiveOnly && <button type="button" className={source === 'itunes' ? 'on' : ''} aria-pressed={source === 'itunes'} onClick={() => selectSource('itunes')} data-testid={`${testPrefix}-source-itunes`}>iTunes store previews</button>}
    </div>
    <label className="mc-search"><Search size={16} /><input value={input} onChange={e => setInput(e.target.value)} placeholder="Search songs, artists, albums" aria-label="Search music" data-testid={`${testPrefix}-search`} /></label>
    <div className="mc-cats" role="group" aria-label="Music categories">
      {cats.map(c => <button type="button" key={c.id} className={cat === c.id ? 'on' : ''} aria-pressed={cat === c.id} onClick={() => selectCat(c.id)} data-testid={`${testPrefix}-cat-${c.id}`}>{c.label}</button>)}
    </div>
    {source === 'itunes' && <p className="mc-warn" data-testid={`${testPrefix}-itunes-note`}>Store previews are for listening only, up to 200 results per keyword. They are provided for promotional use of Apple's catalog; always view the track on iTunes. They cannot be attached to posts or reels.</p>}
    <p className="mc-note" data-testid={`${testPrefix}-count`}>{loading && !items.length ? 'Searching…' : source === 'archive' && total !== undefined ? `${total.toLocaleString()} recordings found on Internet Archive for this search. ` : ''}{notice}{source === 'archive' && ' Album items select the first playable MP3, whose title can differ from the row title.'}</p>
    {cat === 'no-copyright' && <p className="mc-note" data-testid={`${testPrefix}-nc-note`}>The CC0 / Public-domain source already lists only that subset, so No Copyright shows the same set as All.</p>}
    {rowError && <p role="alert" className="mc-err" data-testid={`${testPrefix}-row-error`}>{rowError}</p>}
    {error && <p role="alert" className="mc-err">{error} <button type="button" onClick={() => void load(true)} data-testid={`${testPrefix}-retry`}>Retry</button></p>}
    <div className="mc-box" ref={boxRef} style={{ height: VIEW }} onScroll={e => setScroll(e.currentTarget.scrollTop)} data-testid={`${testPrefix}-list`}>
      {!items.length && !loading && !error && <div className="mc-empty"><Music2 size={26} /><strong>No tracks found</strong><span>Try another keyword or category.</span></div>}
      {!items.length && loading && Array.from({ length: 5 }, (_, i) => <div className="mc-skel" key={i} style={{ height: ROW - 8 }} />)}
      <div style={{ height: items.length * ROW, position: 'relative' }}>
        {visible.map((t, k) => {
          const i = start + k, safe = t.provider === 'archive' && t.reelSafe, on = playing?.id === t.id;
          return <div key={t.id} className={`mc-row ${selectedId === t.id ? 'sel' : ''}`} style={{ top: i * ROW, height: ROW - 8 }} data-testid={`${testPrefix}-row-${t.id}`}>
            <span className="mc-art">{t.artworkUrl ? <img src={t.artworkUrl} alt="" loading="lazy" /> : <Music2 size={18} />}</span>
            <span className="mc-copy"><strong>{t.title}</strong><small>{t.artist} · {t.language}</small><small className="mc-lic">{safe ? 'CC0 / Public domain — uploader-declared. Check uploader license before use.' : 'Store preview'}</small></span>
            <span className="mc-acts">
              <button type="button" aria-label={`${on ? 'Stop' : 'Play'} ${t.title}`} disabled={busyId === t.id} onClick={() => void play(t)} data-testid={`${testPrefix}-play-${t.id}`}>{busyId === t.id ? <Loader2 size={15} className="spin" /> : on ? <Pause size={15} /> : <Play size={15} />}</button>
              {t.provider === 'itunes' && <a href={t.sourceUrl} target="_blank" rel="noopener noreferrer" className="mc-itunes" data-testid={`${testPrefix}-itunes-${t.id}`}>View on iTunes <ExternalLink size={11} /></a>}
              {safe && <a href={t.sourceUrl} target="_blank" rel="noopener noreferrer" className="mc-src" aria-label={`Source of ${t.title}`} data-testid={`${testPrefix}-source-${t.id}`}><ExternalLink size={13} /></a>}
              {safe && onChoose && <button type="button" className="mc-use" disabled={disabled || busyId !== null} onClick={() => void choose(t)} data-testid={`${testPrefix}-choose-${t.id}`}>{selectedId === t.id ? <Check size={14} /> : chooseLabel}</button>}
            </span>
          </div>;
        })}
      </div>
      <div ref={sentinel} style={{ height: 1 }} />
    </div>
    {hasMore && <button type="button" className="mc-more" disabled={loading} onClick={() => void load(false)} data-testid={`${testPrefix}-load-more`}>{loading ? 'Loading…' : 'Load more'}</button>}
    {playing?.audioUrl && <div className="mc-player" data-testid={`${testPrefix}-player`}>
      <p>{playing.title} — {playing.artist}{playing.provider === 'itunes' && <> · <a href={playing.sourceUrl} target="_blank" rel="noopener noreferrer">View on iTunes</a> · promotional preview</>}</p>
      <audio key={playing.id} src={playing.audioUrl} controls autoPlay controlsList="nodownload" preload="none" onEnded={() => setPlaying(null)} onError={() => { setRowError('This stream is unavailable from the source host right now. Nothing was played; use the source link to listen there.'); setPlaying(null); }} data-testid={`${testPrefix}-audio`} />
    </div>}
  </div>;
}
