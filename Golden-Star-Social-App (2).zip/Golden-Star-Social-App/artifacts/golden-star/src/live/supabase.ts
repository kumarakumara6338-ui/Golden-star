import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

export const supabase = url && key ? createClient(url, key, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
}) : null;

export function liveClient() {
  if (!supabase) throw new Error('Supabase is not configured for this app.');
  return supabase;
}

export type LiveUser = {
  user_id: string;
  is_live: boolean;
  started_at: string | null;
  display_name: string | null;
  song_title: string | null;
  last_seen_at: string | null;
};

export type LiveEvent = {
  id: number;
  live_user_id: string;
  sender_user_id: string;
  sender_name: string;
  event_type: 'chat' | 'like' | 'gift';
  message: string;
  created_at: string;
};

export function activeLive(user: LiveUser): boolean {
  return user.is_live && !!user.last_seen_at && Date.now() - Date.parse(user.last_seen_at) < 60_000;
}