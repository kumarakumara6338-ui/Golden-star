import type { LiveUser } from './supabase';
import type { RealtimeChannel } from '@supabase/supabase-js';
import { liveClient } from './supabase';

export const LIVE_DIRECTORY_CHANNEL = 'golden-star-active-broadcasts';

export type LivePresence = {
  role?: string;
  user_id?: string;
  display_name?: string;
  started_at?: string;
  song_title?: string | null;
  roomProof?: string;
};

export type LiveDirectoryEntry = LiveUser & { roomProof?: string };

let sharedChannel: RealtimeChannel | null = null;
let users = 0;
const syncListeners = new Set<() => void>();
const statusListeners = new Set<(status: string) => void>();
let directoryConnected = false;
let readinessWaiters = new Set<() => void>();

export function acquireLiveDirectory(onSync?: () => void, onStatus?: (status: string) => void) {
  if (!sharedChannel) {
    const channel = liveClient().channel(LIVE_DIRECTORY_CHANNEL, { config: { presence: { key: crypto.randomUUID() } } });
    channel.on('presence', { event: 'sync' }, () => {
      notifySync();
    });
    directoryConnected = false;
    readinessWaiters = new Set();
    sharedChannel = channel;
    channel.subscribe(status => {
      if (sharedChannel !== channel) return;
      directoryConnected = status === 'SUBSCRIBED';
      if (directoryConnected) {
        for (const resolve of [...readinessWaiters]) resolve();
        readinessWaiters.clear();
        notifySync();
      }
      for (const listener of [...statusListeners]) {
        try { listener(status); } catch { /* A consumer callback must not interrupt connection recovery. */ }
      }
    });
  }
  users++;
  if (onSync) syncListeners.add(onSync);
  if (onStatus) statusListeners.add(onStatus);
  const channel = sharedChannel;
  if (directoryConnected && onSync) {
    try { onSync(); } catch { /* A consumer callback must not interrupt shared presence updates. */ }
  }
  let released = false;
  return {
    channel,
    waitUntilReady(timeoutMs = 15_000) {
      if (directoryConnected) return Promise.resolve();
      return new Promise<void>((resolve, reject) => {
        let settled = false;
        const finish = () => {
          if (settled) return;
          settled = true;
          window.clearTimeout(timeout);
          readinessWaiters.delete(finish);
          resolve();
        };
        const timeout = window.setTimeout(() => {
          if (settled) return;
          settled = true;
          readinessWaiters.delete(finish);
          reject(new Error('Live presence is taking too long to reconnect. Please try again.'));
        }, timeoutMs);
        readinessWaiters.add(finish);
        if (directoryConnected) finish();
      });
    },
    release() {
      if (released) return;
      released = true;
      if (onSync) syncListeners.delete(onSync);
      if (onStatus) statusListeners.delete(onStatus);
      users--;
      if (users === 0) {
        if (sharedChannel === channel) sharedChannel = null;
        directoryConnected = false;
        for (const resolve of [...readinessWaiters]) resolve();
        readinessWaiters.clear();
        syncListeners.clear();
        statusListeners.clear();
        void liveClient().removeChannel(channel);
      }
    },
  };
}

export function presenceToLive(presence: LivePresence): LiveDirectoryEntry | null {
  if (!presence || presence.role !== 'host'
    || typeof presence.user_id !== 'string' || !presence.user_id.trim() || presence.user_id.length > 200
    || typeof presence.display_name !== 'string' || !presence.display_name.trim() || presence.display_name.length > 120
    || typeof presence.roomProof !== 'string' || !presence.roomProof.trim() || presence.roomProof.length > 4096
    || typeof presence.started_at !== 'string' || !Number.isFinite(Date.parse(presence.started_at))
    || !(presence.song_title === null || presence.song_title === undefined
      || (typeof presence.song_title === 'string' && presence.song_title.length <= 200))) return null;
  return {
    user_id: presence.user_id, is_live: true, started_at: presence.started_at,
    last_seen_at: new Date().toISOString(), display_name: presence.display_name,
    song_title: presence.song_title || null, roomProof: presence.roomProof,
  };
}

function notifySync() {
  for (const listener of [...syncListeners]) {
    try { listener(); } catch { /* An individual consumer must not block shared presence updates. */ }
  }
}