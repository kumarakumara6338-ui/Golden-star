import { useEffect, useRef, useState } from 'react';
import type { CurrentUser } from '../pro-types';
import LiveStageView from '../LiveStageView';

type Props = { user: CurrentUser; onLeave: () => void };
type DemoEvent = { id: string; type: 'chat' | 'like' | 'gift'; name: string; text: string };

export default function DemoLiveSession({ user, onLeave }: Props) {
  const videoContainerRef = useRef<HTMLDivElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const songRef = useRef<{ audio: HTMLAudioElement; url: string } | null>(null);
  const songInput = useRef<HTMLInputElement>(null);
  const generationRef = useRef(0);
  const endingRef = useRef(false);
  const switchInProgress = useRef(false);
  const [status, setStatus] = useState('Requesting camera and microphone access…');
  const [error, setError] = useState<string | null>(null);
  const [muted, setMuted] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'front' | 'back'>('front');
  const [songName, setSongName] = useState<string | null>(null);
  const [events, setEvents] = useState<DemoEvent[]>([]);

  useEffect(() => {
    const generation = ++generationRef.current;
    let active = true;

    function isCurrent() {
      return active && generationRef.current === generation;
    }

    async function startPreview() {
      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          throw new Error('Camera and microphone access is not available in this browser. Open this page over HTTPS and try again.');
        }
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user' },
          audio: true,
        });
        if (!isCurrent()) {
          stream.getTracks().forEach(track => track.stop());
          return;
        }
        streamRef.current = stream;
        const video = document.createElement('video');
        video.autoplay = true;
        video.playsInline = true;
        video.muted = true;
        video.setAttribute('aria-label', 'Your private camera preview');
        videoRef.current = video;
        video.srcObject = stream;
        videoContainerRef.current?.replaceChildren(video);
        try {
          await video.play();
        } catch {
          if (isCurrent()) throw new Error('Your camera is ready, but the preview could not start. Check browser playback permissions and try again.');
        }
        if (!isCurrent()) return;
        setError(null);
        setStatus('');
      } catch (cause) {
        if (!isCurrent()) return;
        setError(permissionMessage(cause));
        setStatus('');
      }
    }

    void startPreview();
    return () => {
      active = false;
      if (generationRef.current === generation) generationRef.current++;
      stopMedia();
    };
  }, []);

  function stopMedia() {
    const stream = streamRef.current;
    streamRef.current = null;
    stream?.getTracks().forEach(track => track.stop());
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.srcObject = null;
      videoRef.current.remove();
      videoRef.current = null;
    }
    const song = songRef.current;
    songRef.current = null;
    if (song) {
      song.audio.pause();
      song.audio.removeAttribute('src');
      song.audio.load();
      URL.revokeObjectURL(song.url);
    }
  }

  function closeSession() {
    if (endingRef.current) return;
    endingRef.current = true;
    generationRef.current++;
    stopMedia();
    onLeave();
  }

  async function switchCamera() {
    const stream = streamRef.current;
    if (!stream || switchInProgress.current) return;
    const generation = generationRef.current;
    const nextFacing = cameraFacing === 'front' ? 'back' : 'front';
    switchInProgress.current = true;
    setStatus('Switching camera…');
    let pendingTracks: MediaStreamTrack[] = [];
    let rollback: { oldStream: MediaStream; nextCamera: MediaStreamTrack } | null = null;
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error('Camera switching is not available in this browser.');
      const cameraStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { exact: nextFacing === 'front' ? 'user' : 'environment' } },
        audio: false,
      });
      pendingTracks = cameraStream.getTracks();
      const nextCamera = cameraStream.getVideoTracks()[0];
      if (!nextCamera) {
        pendingTracks.forEach(track => track.stop());
        pendingTracks = [];
        throw new Error('No camera was returned by the browser.');
      }
      pendingTracks.filter(track => track !== nextCamera).forEach(track => track.stop());
      pendingTracks = [nextCamera];
      if (generationRef.current !== generation || endingRef.current || !streamRef.current) {
        pendingTracks.forEach(track => track.stop());
        pendingTracks = [];
        return;
      }
      const oldStream = streamRef.current;
      const oldCameraTracks = oldStream.getVideoTracks();
      const nextStream = new MediaStream([nextCamera, ...oldStream.getAudioTracks()]);
      streamRef.current = nextStream;
      rollback = { oldStream, nextCamera };
      const video = videoRef.current;
      if (video) {
        video.srcObject = nextStream;
      }
      oldCameraTracks.forEach(track => track.stop());
      rollback = null;
      pendingTracks = [];
      if (video) {
        try { await video.play(); } catch { /* The existing stream remains active if playback was interrupted. */ }
      }
      setCameraFacing(nextFacing);
      setError(null);
      setStatus('');
    } catch (cause) {
      pendingTracks.forEach(track => track.stop());
      if (rollback) {
        rollback.nextCamera.stop();
        streamRef.current = rollback.oldStream;
        try {
          if (videoRef.current) videoRef.current.srcObject = rollback.oldStream;
        } catch { /* The original stream is still owned and will stop on close. */ }
      }
      if (generationRef.current === generation && !endingRef.current) {
        setError(permissionMessage(cause));
        setStatus('');
      }
    } finally {
      switchInProgress.current = false;
    }
  }

  function toggleMute() {
    const mic = streamRef.current?.getAudioTracks()[0];
    if (!mic) {
      setError('Microphone access is unavailable. Allow microphone access and restart the demo.');
      return;
    }
    const nextMuted = !muted;
    mic.enabled = !nextMuted;
    setMuted(nextMuted);
  }

  async function playSong(file?: File) {
    if (!file) return;
    if (!file.type.startsWith('audio/')) {
      setError('Choose an audio file from your device.');
      return;
    }
    const generation = generationRef.current;
    const url = URL.createObjectURL(file);
    const audio = new Audio(url);
    audio.loop = true;
    try {
      await audio.play();
      if (generationRef.current !== generation || endingRef.current) {
        audio.pause();
        URL.revokeObjectURL(url);
        return;
      }
      const previous = songRef.current;
      previous?.audio.pause();
      if (previous) URL.revokeObjectURL(previous.url);
      songRef.current = { audio, url };
      setSongName(file.name);
      setError(null);
    } catch (cause) {
      audio.pause();
      URL.revokeObjectURL(url);
      if (generationRef.current === generation && !endingRef.current) {
        setError(cause instanceof Error
          ? `Could not play this song locally: ${cause.message}`
          : 'Could not play this song locally. Check your browser audio permissions.');
      }
    }
  }

  function addLocalEvent(type: DemoEvent['type'], message: string) {
    const text = type === 'chat' ? message.slice(0, 300)
      : type === 'like' ? 'added a local demo like'
        : 'added a local demo star gift';
    setEvents(current => [...current, {
      id: crypto.randomUUID(), type, name: user.name, text,
    }].slice(-60));
  }

  return <>
    <input ref={songInput} type="file" accept="audio/*" aria-label="Choose a local demo song" className="sr-only"
      onChange={event => { void playSong(event.target.files?.[0]); event.target.value = ''; }} />
    <LiveStageView role="host" demo hostName={user.name} videoContainerRef={videoContainerRef}
      status={status} error={error} viewerCount={0} muted={muted} cameraFacing={cameraFacing}
      songName={songName} events={events}
      onSwitchCamera={() => { void switchCamera(); }} onToggleMute={toggleMute}
      onAddSong={() => songInput.current?.click()} onEnd={closeSession} onClose={closeSession}
      onLike={() => addLocalEvent('like', 'liked locally')} onGift={() => addLocalEvent('gift', 'gifted locally')}
      onSendChat={message => addLocalEvent('chat', message)} />
  </>;
}

function permissionMessage(cause: unknown) {
  if (cause instanceof DOMException) {
    if (cause.name === 'NotAllowedError' || cause.name === 'PermissionDeniedError' || cause.name === 'SecurityError') {
      return 'Camera or microphone access was denied. Allow access in your browser settings, then try the demo again.';
    }
    if (cause.name === 'NotFoundError' || cause.name === 'DevicesNotFoundError') {
      return 'No camera or microphone was found. Connect a device and try again.';
    }
    if (cause.name === 'NotReadableError' || cause.name === 'TrackStartError') {
      return 'Your camera or microphone is busy in another app. Close that app and try again.';
    }
    if (cause.name === 'OverconstrainedError' || cause.name === 'ConstraintNotSatisfiedError') {
      return 'That camera is not available on this device. Try switching back to the other camera.';
    }
  }
  return cause instanceof Error ? cause.message : 'Could not start your camera preview. Check browser permissions and try again.';
}