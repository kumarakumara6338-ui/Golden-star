import { useEffect, useRef, useState } from 'react';
import AgoraRTC, { type IAgoraRTCClient, type ICameraVideoTrack, type ILocalAudioTrack, type IMicrophoneAudioTrack } from 'agora-rtc-sdk-ng';
import type { RealtimeChannel } from '@supabase/supabase-js';
import type { CurrentUser } from '../pro-types';
import { getAppAccessToken } from '../auth-tokens';
import LiveStageView from '../LiveStageView';
import { activeLive, liveClient, type LiveEvent, type LiveUser } from './supabase';
import { acquireLiveDirectory, presenceToLive, type LivePresence } from './presence';

type Props = { user: CurrentUser; hostId: string; hostName: string; displayName?: string; roomProof?: string; onLeave: () => void };
type StageEvent = { id: string; type: 'chat' | 'like' | 'gift'; name: string; text: string };
type Resources = {
  client?: IAgoraRTCClient;
  camera?: ICameraVideoTrack;
  mic?: IMicrophoneAudioTrack;
  mixed?: ILocalAudioTrack;
  context?: AudioContext;
  destination?: MediaStreamAudioDestinationNode;
  song?: HTMLAudioElement;
  songUrl?: string;
};

async function getToken(hostId: string, role: 'host' | 'viewer', roomProof?: string) {
  const accessToken = await getAppAccessToken();
  const response = await fetch('/api/live/token', {
    method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${accessToken}` },
    body: JSON.stringify({ hostId, role, ...(roomProof ? { roomProof } : {}) }),
  });
  const data = await response.json() as { error?: string; token?: string; channel?: string; uid?: number; roomProof?: string };
  if (!response.ok || !data.token || !data.channel || !data.uid) throw new Error(data.error || 'Could not connect to live video.');
  return { token: data.token, channel: data.channel, uid: data.uid, roomProof: data.roomProof };
}

export default function LiveSession({ user, hostId, hostName, displayName, roomProof, onLeave }: Props) {
  const host = user.id === hostId;
  const firebaseIdentity = isFirebaseId(user.id) || isFirebaseId(hostId);
  const senderName = displayName?.trim() || user.name;
  const videoContainerRef = useRef<HTMLDivElement>(null);
  const songInput = useRef<HTMLInputElement>(null);
  const songChanging = useRef(false);
  const resources = useRef<Resources>({});
  const alive = useRef(true);
  const ending = useRef(false);
  const databaseReady = useRef(false);
  const hostPresence = useRef<LivePresence | null>(null);
  const directoryChannel = useRef<RealtimeChannel | null>(null);
  const activityChannel = useRef<RealtimeChannel | null>(null);
  const activityReady = useRef<(() => Promise<void>) | null>(null);
  const [status, setStatus] = useState('Connecting to live video…');
  const [error, setError] = useState<string | null>(null);
  const [viewerCount, setViewerCount] = useState(0);
  const [events, setEvents] = useState<StageEvent[]>([]);
  const [muted, setMuted] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'front' | 'back'>('front');
  const [songName, setSongName] = useState<string | null>(null);

  function appendStageEvent(event: StageEvent) {
    setEvents(current => current.some(item => item.id === event.id)
      ? current
      : [...current, event].slice(-60));
  }

  useEffect(() => {
    alive.current = true;
    ending.current = false;
    const client = liveClient();
    let localActivityConnected = false;
    const localActivityWaiters = new Set<() => void>();
    let hostAnnouncementAttempted = false;
    const directory = acquireLiveDirectory(() => {
      if (!host && alive.current) {
        const current = Object.values(directory.channel.presenceState<LivePresence>()).flat()
          .find(entry => presenceToLive(entry)?.user_id === hostId);
        const validCurrent = current ? presenceToLive(current) : null;
        if (validCurrent) setSongName(validCurrent.song_title || null);
        else if (roomProof) setError('This broadcast has ended.');
      }
    }, state => {
      if (state === 'SUBSCRIBED' && host && alive.current && hostPresence.current) {
        void directory.channel.track(hostPresence.current).then(async result => {
          if (!alive.current || ending.current) {
            try { await directory.channel.untrack(); } catch { /* The directory may already be closed. */ }
            return;
          }
          if (result !== 'ok') setError('Could not restore your live presence. Please rejoin.');
        }).catch(() => {
          if (alive.current) setError('Could not restore your live presence. Please rejoin.');
        });
      }
    });
    directoryChannel.current = directory.channel;
    if (!host && roomProof) {
      const current = Object.values(directory.channel.presenceState<LivePresence>()).flat()
        .find(entry => presenceToLive(entry)?.user_id === hostId);
      const validCurrent = current ? presenceToLive(current) : null;
      if (validCurrent) setSongName(validCurrent.song_title || null);
    }
    const channel = client.channel(`golden-star-presence-${hostId}`, { config: { presence: { key: crypto.randomUUID() } } });
    const eventsChannel = client.channel(`golden-star-events-${hostId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'live_events', filter: `live_user_id=eq.${hostId}` }, payload => {
        const row = payload.new as LiveEvent;
        if (alive.current) appendStageEvent(toStageEvent(row));
      });
    const broadcastChannel = client.channel(`golden-star-room-activity-${hostId}`)
      .on('broadcast', { event: 'activity' }, ({ payload }) => {
        if (!alive.current || !payload || !['chat', 'like', 'gift'].includes(payload.type)
          || typeof payload.id !== 'string' || typeof payload.name !== 'string' || typeof payload.text !== 'string') return;
        appendStageEvent({
          id: payload.id.slice(0, 80), type: payload.type as StageEvent['type'],
          name: payload.name.slice(0, 80), text: payload.text.slice(0, 300),
        });
      });
    activityChannel.current = broadcastChannel;
    activityReady.current = () => new Promise<void>((resolve, reject) => {
      if (localActivityConnected) { resolve(); return; }
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timeout);
        localActivityWaiters.delete(finish);
        resolve();
      };
      const timeout = window.setTimeout(() => {
        if (settled) return;
        settled = true;
        localActivityWaiters.delete(finish);
        reject(new Error('Live conversation is taking too long to reconnect. Please try again.'));
      }, 12_000);
      localActivityWaiters.add(finish);
      if (localActivityConnected) finish();
    });
    broadcastChannel.subscribe(state => {
      localActivityConnected = state === 'SUBSCRIBED';
      if (localActivityConnected) {
        for (const resolve of [...localActivityWaiters]) resolve();
        localActivityWaiters.clear();
      }
      if ((state === 'CHANNEL_ERROR' || state === 'TIMED_OUT') && alive.current) {
        setError('Live conversation is reconnecting…');
      } else if (localActivityConnected && alive.current) {
        setError(current => current === 'Live conversation is reconnecting…' ? null : current);
      }
    });
    const statusChannel = client.channel(`golden-star-live-status-${hostId}`)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'live_users', filter: `user_id=eq.${hostId}` }, payload => {
        const live = payload.new as LiveUser;
        if (!host && !live.is_live && alive.current) { setError('This broadcast has ended.'); setStatus(''); }
        if (!host && live.song_title && alive.current) setSongName(live.song_title);
      });
    channel.on('presence', { event: 'sync' }, () => {
      const count = Object.values(channel.presenceState<{ role?: string }>()).flat().filter(value => value.role === 'viewer').length;
      if (alive.current) setViewerCount(count);
    });
    let heartbeat: number | undefined;

    async function begin() {
      try {
        if (!import.meta.env.VITE_AGORA_APP_ID) throw new Error('Agora is not configured.');
        let latest: LiveUser | null = null;
        if (!host && !roomProof && !firebaseIdentity) {
          const { data, error: cause } = await client.from('live_users')
            .select('user_id,is_live,started_at,display_name,song_title,last_seen_at')
            .eq('user_id', hostId).maybeSingle();
          if (!alive.current || ending.current) return;
          if (cause || !data || !activeLive(data as LiveUser)) throw new Error('This broadcast has ended.');
          latest = data as LiveUser;
          databaseReady.current = true;
          setSongName(latest.song_title);
        }
        const token = await getToken(hostId, host ? 'host' : 'viewer', roomProof);
        if (!alive.current || ending.current) return;
        await directory.waitUntilReady();
        if (!alive.current) return;
        const rtc = AgoraRTC.createClient({ mode: 'live', codec: 'vp8' });
        resources.current.client = rtc;
        await rtc.setClientRole(host ? 'host' : 'audience');
        if (!alive.current || ending.current) {
          try { await rtc.leave(); } catch { /* The client may not have joined yet. */ }
          return;
        }
        rtc.on('user-published', async (remote, mediaType) => {
          try {
            await rtc.subscribe(remote, mediaType);
             if (!alive.current) {
               try { await rtc.unsubscribe(remote, mediaType); } catch { /* The room may already have closed. */ }
               return;
             }
            if (mediaType === 'video' && videoContainerRef.current) {
              remote.videoTrack?.play(videoContainerRef.current);
              setStatus('');
            }
            if (mediaType === 'audio') remote.audioTrack?.play();
          } catch { if (alive.current) setError('Could not play the live stream. Try rejoining.'); }
        });
        rtc.on('user-unpublished', (_, mediaType) => {
          if (mediaType === 'video' && alive.current) setStatus('Waiting for live video…');
        });
        rtc.on('token-privilege-will-expire', () => {
          void getToken(hostId, host ? 'host' : 'viewer', roomProof)
            .then(async next => {
              await rtc.renewToken(next.token);
              if (!alive.current) return;
              if (host && hostPresence.current && next.roomProof) {
                hostPresence.current = { ...hostPresence.current, roomProof: next.roomProof };
                const tracked = await directory.channel.track(hostPresence.current);
                if (alive.current && tracked !== 'ok') setError('Could not restore your live presence. Please rejoin.');
              }
            })
            .catch(() => { if (alive.current) setError('Your live connection is expiring. Rejoin the broadcast.'); });
        });
        await rtc.join(import.meta.env.VITE_AGORA_APP_ID, token.channel, token.token, token.uid);
        if (!alive.current || ending.current) { await rtc.leave(); return; }
        if (host) {
          setStatus('Starting your camera and microphone…');
          const camera = await AgoraRTC.createCameraVideoTrack({ facingMode: 'user' });
          if (!alive.current) { camera.close(); return; }
          resources.current.camera = camera;
          const mic = await AgoraRTC.createMicrophoneAudioTrack();
          if (!alive.current) { mic.close(); camera.close(); return; }
          resources.current.mic = mic;
          camera.play(videoContainerRef.current!);
          await rtc.publish([camera, mic]);
          if (!alive.current || ending.current) {
            try { await rtc.unpublish([camera, mic]); } catch { /* The client may already have left. */ }
            try { await rtc.leave(); } catch { /* The client may already have left. */ }
            return;
          }
          const now = new Date().toISOString();
          hostAnnouncementAttempted = true;
          if (!isFirebaseId(user.id)) {
            const { error: writeError } = await client.from('live_users').upsert({
              user_id: user.id, is_live: true, started_at: now, display_name: senderName,
              song_title: null, last_seen_at: now,
            }, { onConflict: 'user_id' });
            if (!alive.current || ending.current) {
              if (!writeError) await client.from('live_users').update({ is_live: false, song_title: null }).eq('user_id', user.id);
              return;
            }
            if (!writeError) {
              databaseReady.current = true;
              heartbeat = window.setInterval(() => {
                void client.from('live_users').update({ last_seen_at: new Date().toISOString() }).eq('user_id', user.id);
              }, 15_000);
            }
          }
          if (!token.roomProof) throw new Error('Could not announce the broadcast.');
          const presence: LivePresence = {
            role: 'host', user_id: user.id, display_name: senderName, started_at: now,
            song_title: null, roomProof: token.roomProof,
          };
          hostPresence.current = presence;
          const tracked = await directory.channel.track(presence);
          if (!alive.current || ending.current) {
            try { await directory.channel.untrack(); } catch { /* The directory may already be closed. */ }
            if (databaseReady.current) await client.from('live_users').update({ is_live: false, song_title: null }).eq('user_id', user.id);
            return;
          }
          if (tracked !== 'ok') throw new Error('Could not announce the live broadcast. Please try again.');
          setStatus('');
        } else {
          setStatus('Waiting for live video…');
        }
        if (databaseReady.current) eventsChannel.subscribe();
        if (databaseReady.current) statusChannel.subscribe();
        if (latest) {
          const { data: recent } = await client.from('live_events').select('*')
            .eq('live_user_id', hostId).gte('created_at', host ? new Date().toISOString() : (latest as LiveUser).started_at || new Date().toISOString())
            .order('id', { ascending: false }).limit(40);
          if (alive.current && recent?.length) setEvents(current => {
            const merged = [...recent.reverse().map(row => toStageEvent(row as LiveEvent)), ...current];
            return [...new Map(merged.map(item => [item.id, item])).values()].slice(-60);
          });
        }
        if (!alive.current || ending.current) return;
        channel.subscribe(async state => {
          if (state === 'SUBSCRIBED') {
            try {
              const result = await channel.track({ role: host ? 'host' : 'viewer', userId: user.id });
              if (alive.current && result !== 'ok') setError('Viewer count is temporarily unavailable.');
              if (!alive.current || ending.current) {
                try { await channel.untrack(); } catch { /* The channel may already have closed. */ }
              }
            } catch {
              if (alive.current) setError('Viewer count is temporarily unavailable.');
            }
          } else if ((state === 'CHANNEL_ERROR' || state === 'TIMED_OUT') && alive.current) {
            setError('Viewer count is temporarily unavailable.');
          }
        });
      } catch (cause) {
        if (alive.current) { setError(liveFailureMessage(cause)); setStatus(''); }
        if (heartbeat) { window.clearInterval(heartbeat); heartbeat = undefined; }
        if (host && hostPresence.current) {
          try { await directory.channel.untrack(); } catch { /* The channel may already be closed. */ }
          hostPresence.current = null;
        }
        if (host && !isFirebaseId(user.id) && (databaseReady.current || hostAnnouncementAttempted)) {
          await client.from('live_users').update({ is_live: false, song_title: null }).eq('user_id', user.id);
          databaseReady.current = false;
        }
        await stopResources();
      }
    }
    void begin();

    async function stopResources() {
      const held = resources.current;
      resources.current = {};
      held.song?.pause();
      if (held.songUrl) URL.revokeObjectURL(held.songUrl);
      try { await held.client?.leave(); } catch { /* Connection may already be closed. */ }
      held.camera?.stop(); held.camera?.close();
      held.mic?.stop(); held.mic?.close();
      held.mixed?.stop(); held.mixed?.close();
      if (held.context) void held.context.close().catch(() => undefined);
    }
    return () => {
      alive.current = false;
      ending.current = true;
      if (heartbeat) window.clearInterval(heartbeat);
      void client.removeChannel(channel);
      void client.removeChannel(eventsChannel);
      void client.removeChannel(broadcastChannel);
      void client.removeChannel(statusChannel);
      void stopResources();
      if (host && hostPresence.current) void directory.channel.untrack().catch(() => undefined);
      directoryChannel.current = null;
      activityChannel.current = null;
      activityReady.current = null;
      hostPresence.current = null;
      directory.release();
      if (host && !isFirebaseId(user.id) && (databaseReady.current || hostAnnouncementAttempted)) {
        void client.from('live_users').update({ is_live: false, song_title: null }).eq('user_id', user.id);
        databaseReady.current = false;
      }
    };
  }, [hostId, user.id, host]);

  async function end() {
    if (ending.current) return;
    ending.current = true;
    onLeave();
  }

  async function switchCamera() {
    const camera = resources.current.camera;
    if (!camera || !alive.current || ending.current) return;
    const next = cameraFacing === 'front' ? 'back' : 'front';
    try {
      await camera.setDevice({ facingMode: next === 'front' ? 'user' : 'environment' });
      if (!alive.current || ending.current || resources.current.camera !== camera) return;
      setCameraFacing(next);
    } catch {
      if (alive.current && !ending.current) setError('Could not switch cameras on this device.');
    }
  }

  async function toggleMute() {
    const mic = resources.current.mic;
    if (!mic || !alive.current || ending.current) return;
    try {
      await mic.setMuted(!muted);
      if (alive.current && !ending.current && resources.current.mic === mic) setMuted(!muted);
    } catch {
      if (alive.current && !ending.current) setError('Could not change microphone state.');
    }
  }

  async function addSong(file?: File) {
    if (!file) return;
    if (!file.type.startsWith('audio/')) { setError('Choose an audio file from your phone.'); return; }
    const held = resources.current;
    if (!held.client || !held.mic || !alive.current || ending.current) return;
    if (songChanging.current) { setError('Wait for the current song to finish loading.'); return; }
    songChanging.current = true;
    const title = file.name.slice(0, 200);
    let url: string | null = null;
    let song: HTMLAudioElement | null = null;
    let pendingMixed: ILocalAudioTrack | undefined;
    let microphoneUnpublished = false;
    try {
      if (!held.context) {
        held.context = new AudioContext();
        held.destination = held.context.createMediaStreamDestination();
        held.context.createMediaStreamSource(new MediaStream([held.mic.getMediaStreamTrack()])).connect(held.destination);
      }
      await held.context.resume();
      if (!alive.current || ending.current || resources.current !== held) return;
      url = URL.createObjectURL(file);
      song = new Audio(url);
      song.loop = true;
      held.context.createMediaElementSource(song).connect(held.destination!);
      held.song?.pause();
      if (held.songUrl) URL.revokeObjectURL(held.songUrl);
      held.song = song;
      held.songUrl = url;
      await song.play();
      if (!alive.current || ending.current || resources.current !== held) {
        song.pause();
        URL.revokeObjectURL(url);
        if (held.song === song) { held.song = undefined; held.songUrl = undefined; }
        return;
      }
      if (!held.mixed) {
        const mixed = AgoraRTC.createCustomAudioTrack({ mediaStreamTrack: held.destination!.stream.getAudioTracks()[0] });
        pendingMixed = mixed;
        held.mixed = mixed;
        await held.client.unpublish(held.mic);
        microphoneUnpublished = true;
        if (!alive.current || ending.current || resources.current !== held) {
          try { mixed.close(); } catch { /* The track may already have been closed. */ }
          song.pause();
          URL.revokeObjectURL(url);
          if (held.song === song) { held.song = undefined; held.songUrl = undefined; }
          song = null;
          url = null;
          return;
        }
        await held.client.publish(mixed);
        microphoneUnpublished = false;
        if (!alive.current || ending.current || resources.current !== held) {
          try { await held.client.unpublish(mixed); } catch { /* The client may already have left. */ }
          song.pause();
          URL.revokeObjectURL(url);
          if (held.song === song) { held.song = undefined; held.songUrl = undefined; }
          song = null;
          url = null;
          return;
        }
      }
      song = null;
      url = null;
      setSongName(title);
      if (databaseReady.current) {
        const { error: cause } = await liveClient().from('live_users').update({ song_title: title }).eq('user_id', user.id);
        if (cause) throw cause;
      }
      if (!alive.current || ending.current) return;
      if (hostPresence.current) {
        hostPresence.current = { ...hostPresence.current, song_title: title };
        const tracked = await directoryChannel.current?.track(hostPresence.current);
        if (!alive.current || ending.current) {
          try { await directoryChannel.current?.untrack(); } catch { /* The directory may already be closed. */ }
          return;
        }
        if (tracked !== 'ok') throw new Error('Could not share the song title.');
      }
      setError(null);
    } catch (cause) {
      if (song) song.pause();
      if (url) URL.revokeObjectURL(url);
      if (song && held.song === song) { held.song = undefined; held.songUrl = undefined; }
      if (pendingMixed && url && alive.current && !ending.current) {
        if (held.mixed === pendingMixed) held.mixed = undefined;
        try { await held.client?.unpublish(pendingMixed); } catch { /* The replacement track may not have published. */ }
        pendingMixed.stop();
        pendingMixed.close();
        if (microphoneUnpublished && held.mic && alive.current && !ending.current && resources.current === held) {
          try {
            await held.client?.publish(held.mic);
            if (!alive.current || ending.current || resources.current !== held) {
              try { await held.client?.unpublish(held.mic); } catch { /* The client may already have left. */ }
            }
          }
          catch {
            if (alive.current && !ending.current) setError('Could not restore your microphone after the song could not be added. End and restart the broadcast.');
          }
        }
      }
      if (alive.current && !ending.current) setError(cause instanceof Error ? cause.message : 'Could not add that song.');
    } finally {
      songChanging.current = false;
    }
  }

  async function sendEvent(type: 'chat' | 'like' | 'gift', message: string) {
    if (!alive.current || ending.current) return;
    let eventId: string = crypto.randomUUID();
    let savedToDatabase = false;
    if (!firebaseIdentity && (databaseReady.current || !roomProof)) {
      const { data, error: cause } = await liveClient().from('live_events').insert({
        live_user_id: hostId, sender_user_id: user.id, sender_name: senderName,
        event_type: type, message: message.slice(0, 300),
      }).select('id').single();
      if (!alive.current || ending.current) return;
      if (!cause && data?.id !== undefined && data?.id !== null) {
        eventId = String(data.id);
        savedToDatabase = true;
      }
    }
    const activity = {
      id: eventId, type, name: senderName,
      text: type === 'chat' ? message.slice(0, 300) : type === 'like' ? 'liked the broadcast' : 'sent a star gift',
    };
    const realtime = activityChannel.current;
    try {
      await activityReady.current?.();
    } catch {
      if (savedToDatabase) appendStageEvent(activity);
      if (alive.current && !ending.current) setError('Live conversation is unavailable. Try again when it reconnects.');
      return;
    }
    if (!alive.current || ending.current) return;
    let sent = false;
    try {
      sent = !!realtime && await realtime.send({ type: 'broadcast', event: 'activity', payload: activity }) === 'ok';
    } catch { /* Database persistence may still have succeeded. */ }
    if (!sent) {
      if (savedToDatabase) appendStageEvent(activity);
      if (alive.current && !ending.current) {
        setError(savedToDatabase
          ? 'Your activity was saved, but could not be shared with everyone in the room.'
          : `Could not send ${type}. Try again.`);
      }
      return;
    }
    if (alive.current && !ending.current) appendStageEvent(activity);
  }

  return <>
    <input ref={songInput} type="file" accept="audio/*" aria-label="Choose a song to broadcast" className="sr-only"
      onChange={event => { void addSong(event.target.files?.[0]); event.target.value = ''; }} />
    <LiveStageView role={host ? 'host' : 'viewer'} hostName={hostName}
      videoContainerRef={videoContainerRef} status={status} error={error} viewerCount={viewerCount}
      muted={muted} cameraFacing={cameraFacing} songName={songName} events={events}
      onSwitchCamera={() => { void switchCamera(); }} onToggleMute={() => { void toggleMute(); }}
      onAddSong={() => songInput.current?.click()} onEnd={() => { void end(); }}
      onClose={() => { void end(); }} onLike={() => { void sendEvent('like', 'liked the broadcast'); }}
      onGift={() => { void sendEvent('gift', 'sent a free star gift'); }}
      onSendChat={message => { void sendEvent('chat', message); }} />
  </>;
}

function toStageEvent(row: LiveEvent): StageEvent {
  return { id: String(row.id), type: row.event_type, name: row.sender_name,
    text: row.event_type === 'chat' ? row.message : row.event_type === 'like' ? 'liked the broadcast' : 'sent a star gift' };
}

function isFirebaseId(userId: string) {
  return userId.startsWith('firebase-');
}

function liveFailureMessage(cause: unknown) {
  if (cause instanceof DOMException) {
    if (cause.name === 'NotAllowedError' || cause.name === 'PermissionDeniedError' || cause.name === 'SecurityError') {
      return 'Camera or microphone access was denied. Allow access in your browser settings, then rejoin.';
    }
    if (cause.name === 'NotFoundError' || cause.name === 'DevicesNotFoundError') {
      return 'No camera or microphone was found on this device.';
    }
    if (cause.name === 'NotReadableError' || cause.name === 'TrackStartError') {
      return 'Your camera or microphone is busy in another app. Close that app and rejoin.';
    }
  }
  return cause instanceof Error ? cause.message : 'Could not start live video.';
}