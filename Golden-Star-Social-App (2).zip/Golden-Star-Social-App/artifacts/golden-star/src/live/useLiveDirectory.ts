import { useEffect, useState } from 'react';
import type { RealtimeChannel } from '@supabase/supabase-js';
import { activeLive, liveClient, type LiveUser } from './supabase';
import { acquireLiveDirectory, presenceToLive, type LiveDirectoryEntry, type LivePresence } from './presence';

export function useLiveDirectory(skipDatabase = false) {
  const [databaseUsers, setDatabaseUsers] = useState<LiveUser[]>([]);
  const [presenceUsers, setPresenceUsers] = useState<LiveDirectoryEntry[]>([]);
  const [databaseReady, setDatabaseReady] = useState(false);

  useEffect(() => {
    const client = liveClient();
    let mounted = true;
    let requestId = 0;
    let presenceChannel: RealtimeChannel | null = null;
    if (skipDatabase) {
      setDatabaseReady(false);
      setDatabaseUsers([]);
    }
    async function refresh() {
      const thisRequest = ++requestId;
      const { data, error: cause } = await client.from('live_users').select('user_id,is_live,started_at,display_name,song_title,last_seen_at').eq('is_live', true);
      if (!mounted || thisRequest !== requestId) return;
      if (cause) { setDatabaseReady(false); setDatabaseUsers([]); return; }
      setDatabaseReady(true);
      setDatabaseUsers(deduplicate(((data || []) as LiveUser[]).filter(activeLive)));
    }
    if (!skipDatabase) void refresh();
    const subscription = skipDatabase ? null : client.channel('golden-star-live-directory')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'live_users' }, () => { void refresh(); })
      .subscribe();
    function syncPresence() {
      if (!mounted || !presenceChannel) return;
      const users = Object.values(presenceChannel.presenceState<LivePresence>()).flat()
        .map(presenceToLive).filter((entry): entry is LiveDirectoryEntry => entry !== null);
      setPresenceUsers(deduplicate(users));
    }
    const directory = acquireLiveDirectory(syncPresence, status => {
      if (status === 'SUBSCRIBED') syncPresence();
    });
    presenceChannel = directory.channel;
    syncPresence();
    void directory.waitUntilReady().catch(() => {
      if (mounted) setPresenceUsers([]);
    });
    const interval = skipDatabase ? undefined : window.setInterval(() => { void refresh(); }, 15_000);
    return () => {
      mounted = false;
      requestId++;
      if (interval !== undefined) window.clearInterval(interval);
      if (subscription) void client.removeChannel(subscription);
      directory.release();
    };
  }, [skipDatabase]);

  const present = new Set(presenceUsers.map(user => user.user_id));
  const liveUsers: LiveDirectoryEntry[] = deduplicate([
    ...presenceUsers,
    ...(databaseReady ? databaseUsers.filter(user => !present.has(user.user_id)) : []),
  ]).sort((a, b) => validTimestamp(b.started_at) - validTimestamp(a.started_at));
  return { liveUsers };
}

function deduplicate<T extends LiveUser>(entries: T[]): T[] {
  const selected = new Map<string, T>();
  for (const entry of entries) {
    if (!entry.user_id) continue;
    const previous = selected.get(entry.user_id);
    if (!previous || validTimestamp(entry.started_at) > validTimestamp(previous.started_at)) {
      selected.set(entry.user_id, entry);
    }
  }
  return [...selected.values()];
}

function validTimestamp(value: string | null) {
  const timestamp = value ? Date.parse(value) : 0;
  return Number.isFinite(timestamp) ? timestamp : 0;
}