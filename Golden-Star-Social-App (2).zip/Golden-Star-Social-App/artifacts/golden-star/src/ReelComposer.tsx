import { useEffect, useRef, useState } from 'react';
import { ImagePlus, Music2, X } from 'lucide-react';
import YouTubeSongSearch from './YouTubeSongSearch';
import { publishReel, validateReelFile, type StoredReel } from './reel-store';
import MusicCatalog, { type MusicTrack } from './MusicCatalog';
import type { YouTubeVideo } from './youtube';

type Props = {
  userId: string;
  creator: string;
  onClose: () => void;
  onPublished: (reel: StoredReel) => void;
};

export default function ReelComposer({ userId, creator, onClose, onPublished }: Props) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [song, setSong] = useState<YouTubeVideo | null>(null);
  const [music, setMusic] = useState<MusicTrack | null>(null);
  const [error, setError] = useState('');
  const [musicBusy, setMusicBusy] = useState(false);
  const [busy, setBusy] = useState(false);
  const alive = useRef(true);

  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);
  useEffect(() => {
    if (!file) { setPreview(null); return; }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const pick = (f: File | undefined) => {
    if (!f) return;
    const problem = validateReelFile(f);
    if (problem) { setError(problem); return; }
    setError('');
    setFile(f);
  };

  const publish = async () => {
    if (!file || busy || musicBusy) return;
    setBusy(true);
    setError('');
    try {
      const reel = await publishReel(userId, creator, file, caption, song ?? undefined, music ?? undefined);
      onPublished(reel);
    } catch (e) {
      if (alive.current) setError((e as Error).message);
    } finally {
      if (alive.current) setBusy(false);
    }
  };

  return (
    <div className="absolute inset-0 z-30 flex flex-col bg-[#0d0c0a] text-[#f4ecd9]" role="dialog" aria-label="Create Reel" data-testid="composer-reel">
      <div className="flex items-center justify-between border-b border-[#ffd700]/20 px-4 py-3">
        <h3 className="text-lg font-bold text-[#ffd700]">Create Reel</h3>
        <button type="button" aria-label="Close" onClick={onClose} className="grid h-10 w-10 place-items-center" data-testid="button-close-composer"><X size={20} /></button>
      </div>
      <div className="flex-1 space-y-4 overflow-y-auto p-4">
        {file && <fieldset disabled={busy} className="min-w-0 border-0 p-0"><YouTubeSongSearch selected={song} onSelect={v => { setSong(v); if (v) setMusic(null); }} /></fieldset>}
        {song && (
          <p className="flex items-center gap-2 rounded-lg border border-[#ffd700]/40 bg-[#ffd700]/10 px-3 py-2 text-xs text-[#ffd700]" data-testid="text-selected-song">
            <Music2 size={14} /><span className="truncate">{song.title} - {song.channel}</span>
            <button type="button" disabled={busy} onClick={() => setSong(null)} className="ml-auto font-bold underline" data-testid="button-clear-song">Remove</button>
          </p>
        )}
        <div className="space-y-2">
          <p className="text-xs font-semibold text-[#ffd700]">CC0 / Public-domain music (optional)</p>
          <MusicCatalog archiveOnly disabled={busy} onBusyChange={setMusicBusy} testPrefix="composer-music" selectedId={music?.id} onChoose={t => { setMusic(t); setSong(null); }} />
          {musicBusy && <p role="status" className="text-[11px] text-[#ffd700]" data-testid="status-music-resolving">Checking track…</p>}
          {music && <p className="flex items-center gap-2 rounded-lg border border-[#ffd700]/40 bg-[#ffd700]/10 px-3 py-2 text-xs text-[#ffd700]" data-testid="text-selected-music">
            <Music2 size={14} /><span className="truncate">{music.title} - {music.artist}</span>
            <button type="button" disabled={busy} onClick={() => setMusic(null)} className="ml-auto font-bold underline" data-testid="button-clear-music">Remove</button></p>}
        </div>
        <div>
          <label htmlFor="reel-file" className="mb-1 block text-xs font-semibold text-[#ffd700]">Photo or video from your gallery (max 25 MB)</label>
          <label htmlFor="reel-file" className="flex h-12 cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-[#ffd700]/50 text-sm font-semibold text-[#ffd700]">
            <ImagePlus size={18} />{file ? 'Choose a different file' : 'Choose from gallery'}
          </label>
          <input id="reel-file" type="file" accept="image/*,video/*" className="sr-only" onChange={e => { pick(e.target.files?.[0]); e.target.value = ''; }} data-testid="input-reel-file" />
        </div>
        {file && preview && (
          <div className="overflow-hidden rounded-xl border border-[#ffd700]/20 bg-black">
            {file.type.startsWith('video/')
              ? <video src={preview} controls playsInline muted className="max-h-72 w-full object-contain" data-testid="preview-reel-video" />
              : <img src={preview} alt="Reel preview" className="max-h-72 w-full object-contain" data-testid="preview-reel-image" />}
          </div>
        )}
        <div>
          <label htmlFor="reel-caption" className="mb-1 block text-xs font-semibold text-[#ffd700]">Caption</label>
          <textarea id="reel-caption" value={caption} maxLength={200} rows={3} onChange={e => setCaption(e.target.value)}
            className="w-full rounded-lg border border-[#ffd700]/30 bg-[#1d1912] p-3 text-base outline-none" data-testid="input-reel-caption" />
        </div>
        <p className="text-[11px] leading-snug text-[#a69a83]">Saved only in this browser on this device. It is not uploaded or shared. The YouTube song plays separately in YouTube's own player; it is not mixed into or exported with your reel.</p>
        {error && <p role="alert" className="text-sm text-red-300" data-testid="text-composer-error">{error}</p>}
      </div>
      <div className="border-t border-[#ffd700]/20 p-4">
        <button type="button" disabled={!file || busy || musicBusy} onClick={() => void publish()}
          className="h-12 w-full rounded-lg bg-[#ffd700] text-sm font-bold text-[#17120a] disabled:opacity-40" data-testid="button-publish-reel">
          {busy ? 'Publishing' : 'Publish Reel'}
        </button>
      </div>
    </div>
  );
}
