import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { ExternalLink, MessageCircle, Play, X } from 'lucide-react';
import type { YouTubeVideo } from '../youtube';
import './youtube-results.css';

type YouTubeResultsProps = {
  videos: YouTubeVideo[];
  selected: YouTubeVideo | null;
  loading: boolean;
  error: string | null;
  query: string;
  hasMore: boolean;
  onPlay: (video: YouTubeVideo) => void;
  onChat: (video: YouTubeVideo) => void;
  onMore: () => void;
  onClose: () => void;
};

export default function YouTubeResults({
  videos,
  selected,
  loading,
  error,
  query,
  hasMore,
  onPlay,
  onChat,
  onMore,
  onClose,
}: YouTubeResultsProps) {
  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  useEffect(() => {
    if (!selected) return;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') closeRef.current();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      previousFocus?.focus();
    };
  }, [selected?.id]);

  return (
    <section className="yt-results" aria-label="YouTube video results" data-testid="section-youtube-results">
      <div className="yt-results__heading">
        <h2>YouTube videos</h2>
        {query.trim() && <span data-testid="text-youtube-query">Results for “{query.trim()}”</span>}
      </div>

      {error && (
        <div className="yt-results__message yt-results__message--error" role="alert" data-testid="status-youtube-error">
          <h3>Couldn’t load videos</h3>
          <p>{error}</p>
        </div>
      )}

      {videos.length > 0 && (
        <div className="yt-results__list" data-testid="list-youtube-videos">
          {videos.map((video) => (
            <article className="yt-results__item" key={video.id} data-testid={`card-youtube-video-${video.id}`}>
              <button
                className="yt-results__thumbnail"
                type="button"
                onClick={() => onPlay(video)}
                aria-label={`Play ${video.title}`}
                data-testid={`button-youtube-thumbnail-${video.id}`}
              >
                <img src={video.thumbnail} alt="" loading="lazy" data-testid={`img-youtube-thumbnail-${video.id}`} />
              </button>
              <div className="yt-results__details">
                <h3 className="yt-results__title" data-testid={`text-youtube-title-${video.id}`}>{video.title}</h3>
                <p className="yt-results__channel" data-testid={`text-youtube-channel-${video.id}`}>{video.channel}</p>
                <div className="yt-results__actions">
                  <button className="yt-results__button yt-results__button--play" type="button" onClick={() => onPlay(video)} data-testid={`button-youtube-play-${video.id}`}>
                    <Play size={13} fill="currentColor" aria-hidden="true" /> Play
                  </button>
                  <button className="yt-results__button" type="button" onClick={() => onChat(video)} data-testid={`button-youtube-chat-${video.id}`}>
                    <MessageCircle size={13} aria-hidden="true" /> Use in Chat
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      {loading && (
        <div className="yt-results__list" role="status" aria-label="Loading YouTube videos" data-testid="status-youtube-loading">
          {Array.from({ length: videos.length ? 1 : 3 }, (_, index) => (
            <div className="yt-results__skeleton" aria-hidden="true" key={index}>
              <div className="yt-results__skeleton-art" />
              <div className="yt-results__skeleton-lines"><div className="yt-results__skeleton-line" /><div className="yt-results__skeleton-line" /></div>
            </div>
          ))}
          <span className="sr-only">Loading YouTube videos</span>
        </div>
      )}

      {!loading && !error && videos.length === 0 && (
        <div className="yt-results__message" role="status" data-testid="status-youtube-empty">
          <h3>No videos found</h3>
          <p>{query.trim() ? 'Try a different search to find videos.' : 'Search to find videos on YouTube.'}</p>
        </div>
      )}

      {hasMore && videos.length > 0 && !error && (
        <button className="yt-results__more" type="button" onClick={onMore} disabled={loading} data-testid="button-youtube-load-more">
          {loading ? 'Loading more…' : 'Load more'}
        </button>
      )}

      {selected && createPortal(
        <div className="yt-player-backdrop" onClick={onClose} role="presentation" data-testid="backdrop-youtube-player">
          <div className="yt-player" role="dialog" aria-modal="true" aria-labelledby="yt-player-title" onClick={(event) => event.stopPropagation()} data-testid="dialog-youtube-player">
            <div className="yt-player__header">
              <div className="yt-player__heading">
                <h2 id="yt-player-title" data-testid="text-youtube-player-title">{selected.title}</h2>
                <p data-testid="text-youtube-player-channel">{selected.channel}</p>
              </div>
              <button className="yt-player__close" type="button" onClick={onClose} aria-label="Close video player" autoFocus data-testid="button-youtube-close">
                <X size={17} aria-hidden="true" />
              </button>
            </div>
            <div className="yt-player__frame">
              <iframe
                src={`https://www.youtube.com/embed/${encodeURIComponent(selected.id)}`}
                title={`${selected.title} — YouTube player`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                referrerPolicy="strict-origin-when-cross-origin"
                data-testid="iframe-youtube-player"
              />
            </div>
            <div className="yt-player__footer">
              <span>If the player is unavailable, open the video on YouTube.</span>
              <a className="yt-player__watch" href={`https://www.youtube.com/watch?v=${encodeURIComponent(selected.id)}`} target="_blank" rel="noopener noreferrer" data-testid="link-youtube-watch">
                Watch on YouTube <ExternalLink size={13} aria-hidden="true" />
              </a>
            </div>
          </div>
        </div>,
        document.body,
      )}
    </section>
  );
}