import { updateProfile } from 'firebase/auth';
import { getFirebaseAuth } from './firebase-auth';
import { liveClient } from './live/supabase';

export async function getAppAccessToken(): Promise<string> {
  const firebaseUser = getFirebaseAuth()?.currentUser;
  if (firebaseUser) return firebaseUser.getIdToken();

  const { data, error } = await liveClient().auth.getSession();
  if (error) throw error;
  if (!data.session?.access_token) throw new Error('No authenticated Firebase or Supabase session is available.');
  return data.session.access_token;
}

export async function updateAuthenticatedName(name: string): Promise<void> {
  const normalizedName = name.trim();
  if (!normalizedName) throw new Error('Enter a name.');

  const firebaseUser = getFirebaseAuth()?.currentUser;
  if (firebaseUser) {
    await updateProfile(firebaseUser, { displayName: normalizedName });
    return;
  }

  const { error } = await liveClient().auth.updateUser({ data: { full_name: normalizedName } });
  if (error) throw error;
}