import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Heart, Music2, Pause, Play, Plus, Send, Trash2, Volume2, VolumeX, X } from 'lucide-react';
import { artwork } from './content';
import { useMediaUrl } from './media';
import MusicCatalog, { type MusicTrack } from './MusicCatalog';
import ReelComposer from './ReelComposer';
import { deleteReel, loadOwnLikes, loadReels, ownReelShareUrl, saveOwnLikes, type StoredReel } from './reel-store';
import type { YouTubeVideo } from './youtube';

type Props = {
  t: (key: any, values?: Record<string, string | number>) => string;
  initialIndex: number;
  initialReelId?: string;
  onShareOwned?: (id: string) => void;
  liked: number[];
  onLike: (index: number) => void;
  onShare: (index: number) => void;
  userId: string;
  userName?: string;
  defaultCreator?: string;
  blockedUsers?: string[];
  onProfile?: (name: string) => void;
  onOwnProfile?: () => void;
  isFollowing?: (name: string) => boolean;
  onFollow?: (name: string) => void;
  isBlocked?: (name: string) => boolean;
};

const base = import.meta.env.BASE_URL;
const reels = [
  { creator: 'Blender Foundation', initials: 'BF', title: 'Sintel — trailer', description: 'Sintel © Blender Foundation, CC BY 3.0.', video: `${base}reels/sintel.webm`, likes: 842 },
  { creator: 'Blender Foundation', initials: 'BF', title: 'Big Buck Bunny — trailer', description: 'Big Buck Bunny © Blender Foundation, CC BY 3.0.', video: `${base}reels/bunny.webm`, likes: 1204 },
  { creator: 'MDN Web Docs', initials: 'MD', title: 'Flowers in motion', description: 'Flower sample video, CC0.', video: `${base}reels/flower.webm`, likes: 2318 },
];


type Item = {
  key: string; index: number; creator: string; initials: string; title: string; description: string;
  likes: number; owned?: StoredReel; video?: string;
};

function ReelMusicAudio({ src, playing, muted, testId }: { src: string; playing: boolean; muted: boolean; testId: string }) {
  const ref = useRef<HTMLAudioElement>(null);
  const [err, setErr] = useState('');
  useEffect(() => {
    const a = ref.current;
    if (!a) return;
    if (playing) a.play().then(() => setErr('')).catch(() => setErr('Music could not start. Press play on the audio bar.'));
    else a.pause();
    return () => a.pause();
  }, [playing, src]);
  return <div className="pointer-events-auto mt-2">
    <audio ref={ref} src={src} loop muted={muted} controls controlsList="nodownload" preload="none" className="h-8 w-full" onError={() => setErr('This music file could not be played.')} data-testid={testId} />
    {err && <p role="alert" className="mt-1 text-[10px] text-red-300" data-testid="text-reel-music-error">{err}</p>}
  </div>;
}

function ReelMedia({ item, active, playing, muted, onFail, onToggle, posterSeed }: {
  item: Item; active: boolean; playing: boolean; muted: boolean; onFail: () => void; onToggle: () => void; posterSeed: number;
}) {
  const owned = item.owned;
  const url = useMediaUrl(owned?.mediaId);
  const ref = useRef<HTMLVideoElement>(null);
  const isVideo = !owned || owned.mediaType === 'video';
  const src = owned ? url : item.video;
  useEffect(() => {
    const v = ref.current;
    if (!v) return;
    if (active && playing) v.play().catch(() => onToggle());
    else v.pause();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, playing, src]);
  if (owned && url === undefined) return <div className="h-full w-full animate-pulse bg-[#1d1912]" data-testid={`loading-reel-${item.index}`} />;
  if (owned && url === null) return <div className="grid h-full w-full place-items-center p-6 text-center text-sm text-red-300" role="alert">This reel's file is missing from this browser.</div>;
  if (!isVideo) return <img src={src ?? ''} alt={owned?.caption || 'Reel'} className="h-full w-full object-cover" onError={onFail} data-testid={`image-reel-${item.index}`} />;
  return <video ref={ref} src={src ?? undefined} poster={owned ? undefined : artwork(item.title, 61 + posterSeed)} className="h-full w-full object-cover" loop playsInline muted={muted}
    preload={active ? 'auto' : 'metadata'} onError={onFail} onClick={onToggle} data-testid={`video-reel-${item.index}`} />;
}

export default function ReelsExperience({ t, initialIndex, initialReelId, onShareOwned, liked, onLike, onShare, userId, userName, defaultCreator, blockedUsers = [], onProfile, onOwnProfile, isFollowing, onFollow, isBlocked }: Props) {
  const me = userName || defaultCreator || 'You';
  const [owned, setOwned] = useState<StoredReel[]>(() => loadReels(userId));
  const visible = useMemo<Item[]>(() => {
    const stat = reels.map((r, index) => ({ ...r, index, key: String(index) }))
      .filter(r => !blockedUsers.includes(r.creator) && !isBlocked?.(r.creator));
    // owned reels are never filtered by blocked creators
    const mine = owned.map((o, n) => ({
      key: `own:${o.id}`, index: reels.length + n, creator: o.creator || me, initials: (o.creator || me).slice(0, 2).toUpperCase(),
      title: o.caption || 'My reel', description: o.caption ? '' : 'Saved on this device only.', likes: 0, owned: o,
    }));
    return [...stat, ...mine];
  }, [blockedUsers, isBlocked, owned, me]);
  const max = Math.max(0, visible.length - 1);
  const scrollRef = useRef<HTMLDivElement>(null);
  const storeKey = `golden-star:reel-songs:${userId}`;
  const [active, setActive] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(true);
  const [failed, setFailed] = useState<number | null>(null);
  const [open, setOpen] = useState(false);
  const [composing, setComposing] = useState(false);
  const [embedId, setEmbedId] = useState<string | null>(null);
  const [confirmDel, setConfirmDel] = useState<string | null>(null);
  const [delError, setDelError] = useState('');
  const pendingScroll = useRef<string | null>(null);
  const [ownLiked, setOwnLiked] = useState<string[]>(() => loadOwnLikes(userId));
  const [notice, setNotice] = useState('');
  const musicKey = `golden-star:reel-music:${userId}`;
  const [tracks, setTracks] = useState<Record<string, MusicTrack>>(() => {
    try { return JSON.parse(localStorage.getItem(musicKey) || '{}'); } catch { return {}; }
  });
  const [songs, setSongs] = useState<Record<string, string>>(() => {
    try { return JSON.parse(localStorage.getItem(storeKey) || '{}'); } catch { return {}; }
  });

  useEffect(() => { setOwned(loadReels(userId)); setOwnLiked(loadOwnLikes(userId)); setEmbedId(null); }, [userId]);
  useEffect(() => {
    try { setSongs(JSON.parse(localStorage.getItem(storeKey) || '{}')); } catch { setSongs({}); }
  }, [storeKey]);

  const scrollTo = useCallback((i: number) => {
    setActive(i);
    const el = scrollRef.current;
    if (el) el.scrollTop = el.clientHeight * i;
  }, []);

  useEffect(() => {
    const byId = initialReelId ? visible.findIndex(v => v.owned?.id === initialReelId) : -1;
    const pos = byId >= 0 ? byId : visible.findIndex(v => !v.owned && v.index === initialIndex);
    scrollTo(Math.max(0, pos >= 0 ? pos : Math.min(max, initialIndex)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialIndex, initialReelId]);

  useEffect(() => {
    if (pendingScroll.current !== null) {
      const p = visible.findIndex(v => v.key === pendingScroll.current);
      pendingScroll.current = null;
      if (p >= 0) scrollTo(p);
    }
  }, [visible, scrollTo]);

  useEffect(() => { setEmbedId(null); }, [active]);

  const current = visible[active];
  const choose = (track: MusicTrack) => {
    if (!current) return;
    const next = { ...tracks, [current.key]: track };
    setTracks(next);
    try { localStorage.setItem(musicKey, JSON.stringify(next)); } catch { setNotice('Could not save your music choice in this browser.'); }
    setOpen(false);
  };

  const remove = async (reel: StoredReel) => {
    setDelError('');
    try {
      const pos = visible.findIndex(v => v.owned?.id === reel.id);
      await deleteReel(userId, reel.id);
      pendingScroll.current = (visible[pos - 1] ?? visible[pos + 1])?.key ?? null;
      const { [`own:${reel.id}`]: _drop, ...rest } = songs;
      setSongs(rest);
      const { [`own:${reel.id}`]: _t, ...restTracks } = tracks;
      setTracks(restTracks);
      try { localStorage.setItem(musicKey, JSON.stringify(restTracks)); } catch { /* storage unavailable */ }
      try { localStorage.setItem(storeKey, JSON.stringify(rest)); } catch { /* storage unavailable */ }
      setOwnLiked(loadOwnLikes(userId));
      setEmbedId(null);
      setOwned(loadReels(userId));
      setConfirmDel(null);
    } catch {
      setDelError('Could not delete this reel. Try again.');
    }
  };

  const like = (reel: Item) => {
    if (!reel.owned) { onLike(reel.index); return; }
    const id = reel.owned.id;
    const next = ownLiked.includes(id) ? ownLiked.filter(x => x !== id) : [...ownLiked, id];
    if (saveOwnLikes(userId, next)) setOwnLiked(next); else setNotice('Could not save your like in this browser.');
  };
  const share = async (reel: Item) => {
    if (!reel.owned) { onShare(reel.index); return; }
    if (onShareOwned) { onShareOwned(reel.owned.id); return; }
    const url = ownReelShareUrl(reel.owned.id);
    try {
      if (navigator.share) await navigator.share({ title: reel.title, url });
      else { await navigator.clipboard.writeText(url); setNotice('Link copied.'); }
    } catch (e) {
      if ((e as Error).name !== 'AbortError') setNotice('Could not share this link.');
    }
  };
  const btn = 'flex flex-col items-center gap-1 text-[11px] font-semibold text-[#f4ecd9] drop-shadow';
  const createBtn = (
    <button type="button" onClick={() => { setPlaying(false); setComposing(true); }}
      className="absolute right-3 top-3 z-10 flex h-10 items-center gap-1 rounded-full border border-[#ffd700] bg-black/70 px-3 text-xs font-bold text-[#ffd700]" data-testid="button-create-reel">
      <Plus size={16} />Create Reel
    </button>
  );

  return (
    <div className="relative mx-auto h-[calc(100dvh-140px)] min-h-[480px] w-full max-w-[430px] overflow-hidden rounded-2xl border border-[#ffd700]/20 bg-black">
      {createBtn}
      {!visible.length ? <p className="p-6 pt-16 text-center text-sm opacity-70 text-[#f4ecd9]">{t('mediaError')}</p> : (
      <div ref={scrollRef} className="h-full snap-y snap-mandatory overflow-y-scroll [scrollbar-width:none]"
        onScroll={e => { const el = e.currentTarget; setActive(Math.min(max, Math.round(el.scrollTop / el.clientHeight))); }}>
        {visible.map((reel, i) => {
          const isLiked = reel.owned ? ownLiked.includes(reel.owned.id) : liked.includes(reel.index);
          const mine = !!reel.owned;
          const following = !mine && (isFollowing?.(reel.creator) ?? false);
          const song = songs[reel.key];
          const track = tracks[reel.key] ?? reel.owned?.music;
          const label = track?.title ?? song;
          const yt: YouTubeVideo | undefined = reel.owned?.song;
          const embedding = yt && !track && embedId === yt.id && i === active;
          const reelMuted = muted || !!embedding || !!track?.audioUrl;
          return (
            <article key={reel.owned?.id ?? reel.title} className="relative h-full w-full snap-start snap-always bg-[#0d0c0a]">
              <ReelMedia item={reel} active={i === active} playing={playing} muted={reelMuted} posterSeed={i}
                onFail={() => setFailed(i)} onToggle={() => setPlaying(v => !v)} />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/30" />
              <div className="absolute bottom-4 left-4 right-20 text-[#f4ecd9]">
                <div className="mb-2 flex items-center gap-2">
                  <button type="button" onClick={() => (mine ? onOwnProfile?.() : onProfile?.(reel.creator))} className="flex items-center gap-2 text-sm font-bold" data-testid={`button-creator-${reel.index}`}>
                    <span className="grid h-8 w-8 place-items-center rounded-full border border-[#ffd700] bg-[#1d1912] text-xs text-[#ffd700]">{reel.initials}</span>
                    {reel.creator}
                  </button>
                  {onFollow && !mine && (
                    <button type="button" onClick={() => onFollow(reel.creator)} aria-pressed={following}
                      className={`rounded-md border px-3 py-1 text-xs font-bold ${following ? 'border-[#ffd700]/50 text-[#ffd700]' : 'border-[#ffd700] bg-[#ffd700] text-[#17120a]'}`}
                      data-testid={`button-follow-${reel.index}`}>{following ? 'Following' : 'Follow'}</button>
                  )}
                </div>
                <h2 className="text-base font-bold leading-tight">{reel.title}</h2>
                {reel.description && <p className="mt-1 text-xs text-[#d9ccb1]">{reel.description}</p>}
                {failed === i && <p role="alert" className="mt-1 text-xs text-red-300">{t('mediaError')}</p>}
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  {yt && !track ? (
                    <button type="button" onClick={() => setEmbedId(embedding ? null : yt.id)} aria-pressed={!!embedding}
                      className="flex max-w-full items-center gap-2 rounded-full border border-[#ffd700]/40 bg-black/50 py-1.5 pl-2 pr-3 text-xs font-semibold text-[#ffd700]" data-testid={`button-play-song-${reel.index}`}>
                      <Music2 size={16} /><span className="truncate">{yt.title}</span>
                    </button>
                  ) : (
                    <button type="button" onClick={() => setOpen(true)} className="flex max-w-full items-center gap-2 rounded-full border border-[#ffd700]/40 bg-black/50 py-1.5 pl-2 pr-3 text-xs font-semibold text-[#ffd700]" data-testid={`button-all-songs-${reel.index}`}>
                      <Music2 size={16} /><span className="truncate">{label ? label : 'All Songs'}</span>
                    </button>
                  )}
                  {mine && reel.owned && (
                    <button type="button" onClick={() => { setDelError(''); setConfirmDel(reel.owned!.id); }} aria-label="Delete reel"
                      className="grid h-8 w-8 place-items-center rounded-full border border-[#ffd700]/40 bg-black/50 text-[#ffd700]" data-testid={`button-delete-reel-${reel.index}`}><Trash2 size={14} /></button>
                  )}
                </div>
                {track?.audioUrl && i === active && (
                  <ReelMusicAudio key={track.id} src={track.audioUrl} playing={playing} muted={muted} testId={`audio-reel-music-${reel.index}`} />
                )}
                {track && <p className="mt-1 text-[10px] text-[#a69a83]" data-testid={`text-reel-music-${reel.index}`}>Music: {track.title} — {track.artist} · plays separately, not mixed into the reel.</p>}
                {embedding && yt && !track && (
                  <div className="pointer-events-auto mt-2 overflow-hidden rounded-lg border border-[#ffd700]/30 bg-black">
                    <iframe title={`YouTube player: ${yt.title}`} className="aspect-video w-full"
                      src={`https://www.youtube-nocookie.com/embed/${yt.id}?autoplay=1&playsinline=1&controls=1&rel=0`}
                      allow="autoplay; encrypted-media; picture-in-picture" referrerPolicy="strict-origin-when-cross-origin" allowFullScreen data-testid={`iframe-song-${reel.index}`} />
                    <p className="px-2 py-1 text-[10px] text-[#a69a83]">Plays separately in YouTube's player. Reel sound is muted while it plays. If it does not start, press play in the player.</p>
                  </div>
                )}
              </div>
              <div className="absolute bottom-4 right-3 flex flex-col items-center gap-5">
                <button className={btn} aria-label={t(playing ? 'pause' : 'play')} onClick={() => setPlaying(v => !v)} data-testid={`button-playpause-${reel.index}`}>
                  {playing ? <Pause size={26} /> : <Play size={26} />}</button>
                <button className={`${btn} ${isLiked ? 'text-[#ffd700]' : ''}`} aria-label={t(isLiked ? 'unlikeReel' : 'likeReel')} onClick={() => like(reel)} data-testid={`button-like-reel-${reel.index}`}>
                  <Heart size={26} fill={isLiked ? 'currentColor' : 'none'} /><span>{reel.likes + Number(isLiked)}</span></button>
                <button className={btn} aria-label={t('shareReel')} onClick={() => void share(reel)} data-testid={`button-share-reel-${reel.index}`}>
                  <Send size={24} /></button>
                <button className={btn} aria-label={t(muted ? 'unmute' : 'mute')} onClick={() => setMuted(v => !v)} data-testid={`button-mute-${reel.index}`}>
                  {muted ? <VolumeX size={24} /> : <Volume2 size={24} />}</button>
              </div>
            </article>
          );
        })}
      </div>
      )}
      {notice && (
        <p role="status" className="absolute inset-x-4 top-16 z-20 rounded-lg border border-[#ffd700]/40 bg-black/80 px-3 py-2 text-xs text-[#f4ecd9]" onClick={() => setNotice('')} data-testid="text-reel-notice">{notice}</p>
      )}
      {confirmDel && (
        <div className="absolute inset-0 z-20 grid place-items-center bg-black/70 p-6" onClick={() => setConfirmDel(null)}>
          <div role="alertdialog" aria-label="Delete reel" className="w-full rounded-2xl border border-[#ffd700]/30 bg-[#15130f] p-4 text-[#f4ecd9]" onClick={e => e.stopPropagation()}>
            <p className="text-sm font-semibold">Delete this reel and its saved file from this browser?</p>
            {delError && <p role="alert" className="mt-2 text-xs text-red-300">{delError}</p>}
            <div className="mt-4 flex gap-2">
              <button type="button" onClick={() => setConfirmDel(null)} className="h-11 flex-1 rounded-lg border border-[#ffd700]/40 text-sm font-bold text-[#ffd700]" data-testid="button-cancel-delete">Cancel</button>
              <button type="button" onClick={() => { const r = owned.find(o => o.id === confirmDel); if (r) void remove(r); }} className="h-11 flex-1 rounded-lg bg-[#ffd700] text-sm font-bold text-[#17120a]" data-testid="button-confirm-delete">Delete</button>
            </div>
          </div>
        </div>
      )}
      {composing && (
        <ReelComposer userId={userId} creator={me} onClose={() => setComposing(false)}
          onPublished={r => {
            setOwned(loadReels(userId));
            pendingScroll.current = `own:${r.id}`;
            setComposing(false);
            setPlaying(true);
          }} />
      )}
      {open && (
        <div className="absolute inset-0 z-20 flex items-end bg-black/60" onClick={() => setOpen(false)}>
          <div role="dialog" aria-label="All Songs" className="max-h-[90%] w-full overflow-y-auto rounded-t-2xl border-t border-[#ffd700]/30 bg-[#15130f] p-4 text-[#f4ecd9]" onClick={e => e.stopPropagation()}>
            <div className="mb-1 flex items-center justify-between">
              <h3 className="text-lg font-bold text-[#ffd700]">All Songs</h3>
              <button type="button" aria-label="Close" onClick={() => setOpen(false)} data-testid="button-close-songs"><X size={20} /></button>
            </div>
            <p className="mb-3 text-[11px] leading-snug text-[#a69a83]">Only CC0 / Public-domain archive tracks can be chosen (declared by the uploader; check the source). Audio plays separately and is not mixed into the video.</p>
            <MusicCatalog archiveOnly testPrefix="reel-music" selectedId={current ? tracks[current.key]?.id : undefined} onChoose={choose} />
          </div>
        </div>
      )}
    </div>
  );
}
