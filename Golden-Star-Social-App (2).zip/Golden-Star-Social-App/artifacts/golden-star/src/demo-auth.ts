import type { CurrentUser } from './pro-types';
import { clearDemoPin } from './demo-security';

const accountsKey = 'golden-star-demo-phone-accounts';
const identityKey = 'golden-star-demo-user';
const demoIdPrefix = 'demo-phone-';
let demoStorageIssue: string | null = null;

function storageUnavailable(action: string): Error {
  const message = `Browser storage is unavailable, so the local demo ${action} could not be completed. Restore browser storage and retry; real email sign-in is still available.`;
  demoStorageIssue = message;
  return new Error(message);
}

function clearStorageIssue(): void {
  demoStorageIssue = null;
}

export function getDemoStorageIssue(): string | null {
  return demoStorageIssue;
}

type DemoAccount = CurrentUser & {
  passwordSalt?: string;
  passwordHash?: string;
};

function isDemoAccount(value: unknown): value is DemoAccount {
  if (!value || typeof value !== 'object') return false;
  const account = value as Partial<DemoAccount>;
  return typeof account.id === 'string'
    && account.id.startsWith(demoIdPrefix)
    && typeof account.name === 'string'
    && typeof account.phone === 'string'
    && (!account.email || typeof account.email === 'string')
    && (!account.passwordSalt || typeof account.passwordSalt === 'string')
    && (!account.passwordHash || typeof account.passwordHash === 'string');
}

function readAccounts(): DemoAccount[] {
  let raw: string | null;
  try {
    raw = localStorage.getItem(accountsKey);
  } catch {
    throw storageUnavailable('phone account lookup');
  }
  if (!raw) return [];
  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    throw new Error('Saved local demo phone accounts are invalid. No demo accounts were deleted; restore the local demo data or use real email sign-in.');
  }
  if (!Array.isArray(value) || !value.every(isDemoAccount)) {
    throw new Error('Saved local demo phone accounts are invalid. No demo accounts were deleted; restore the local demo data or use real email sign-in.');
  }
  return value;
}

function writeAccounts(accounts: DemoAccount[]): void {
  try {
    localStorage.setItem(accountsKey, JSON.stringify(accounts));
    clearStorageIssue();
  } catch {
    throw storageUnavailable('phone account update');
  }
}

function toPublicUser(account: DemoAccount): CurrentUser {
  return {
    id: account.id,
    name: account.name,
    phone: account.phone,
    ...(account.email ? { email: account.email } : {}),
  };
}

function normalizePhone(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (digits.length < 8 || digits.length > 15) {
    throw new Error('Enter a phone number with 8 to 15 digits, including its country code.');
  }
  return `+${digits}`;
}

async function hashPassword(password: string, salt: Uint8Array): Promise<string> {
  if (!globalThis.crypto?.subtle) throw new Error('Secure password storage is unavailable in this browser.');
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({
    name: 'PBKDF2',
    salt: Uint8Array.from(salt),
    iterations: 120000,
    hash: 'SHA-256',
  }, key, 256);
  return [...new Uint8Array(bits)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

/** Reads only the local demo identity; it never queries Supabase. */
export function readDemoUser(): CurrentUser | null {
  let raw: string | null;
  try {
    raw = localStorage.getItem(identityKey);
  } catch {
    demoStorageIssue = 'Browser storage is unavailable, so the local demo identity could not be restored. Real email sign-in is still available.';
    return null;
  }
  if (raw === null) return null;
  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    discardInvalidDemoIdentity();
    return null;
  }
  if (!value || typeof value !== 'object') {
    discardInvalidDemoIdentity();
    return null;
  }
  const user = value as Partial<CurrentUser>;
  if (typeof user.id !== 'string' || !user.id.startsWith(demoIdPrefix)
    || typeof user.name !== 'string' || typeof user.phone !== 'string') {
    discardInvalidDemoIdentity();
    return null;
  }
  try {
    const account = readAccounts().find(item => item.id === user.id);
    if (!account) {
      demoStorageIssue = 'The saved demo identity has no matching local phone account and was not restored. Other demo accounts were retained.';
      return null;
    }
    clearStorageIssue();
    return toPublicUser(account);
  } catch (cause) {
    demoStorageIssue = cause instanceof Error ? cause.message : 'Local demo accounts could not be read. Other browser data was left unchanged.';
    return null;
  }
}

function discardInvalidDemoIdentity(): void {
  try {
    localStorage.removeItem(identityKey);
    demoStorageIssue = 'The saved demo identity was invalid and has been discarded. Other local demo accounts were retained.';
  } catch {
    demoStorageIssue = 'The saved demo identity was invalid but could not be discarded because browser storage is unavailable. Other local demo accounts were left unchanged.';
  }
}

export function saveDemoUser(user: CurrentUser): void {
  if (!user.id.startsWith(demoIdPrefix) || !user.phone) throw new Error('Only a local demo phone identity can be saved here.');
  const account = readAccounts().find(item => item.id === user.id && item.phone === user.phone);
  if (!account) throw new Error('This demo identity is not registered in local browser storage.');
  try {
    localStorage.setItem(identityKey, JSON.stringify(toPublicUser(account)));
    clearStorageIssue();
  } catch {
    throw storageUnavailable('identity save');
  }
}

export function clearDemoUser(): void {
  try {
    localStorage.removeItem(identityKey);
    clearStorageIssue();
  } catch {
    storageUnavailable('identity cleanup');
  }
}

export function deleteDemoUser(userId: string): void {
  if (!userId.startsWith(demoIdPrefix)) throw new Error('Only a local demo phone account can be deleted here.');
  const rawIdentity = localStorage.getItem(identityKey);
  let identity: unknown = null;
  if (rawIdentity) {
    try {
      identity = JSON.parse(rawIdentity);
    } catch {
      throw new Error('Saved demo identity is invalid. Restore or clear it before deleting this account.');
    }
  }
  const accounts = readAccounts();
  writeAccounts(accounts.filter(account => account.id !== userId));
  clearDemoPin(userId);
  if (identity && typeof identity === 'object' && (identity as Partial<CurrentUser>).id === userId) {
    clearDemoUser();
  }
}

export function getDemoPhoneUser(phoneInput: string): CurrentUser | null {
  const phone = normalizePhone(phoneInput);
  const account = readAccounts().find(item => item.phone === phone);
  return account ? toPublicUser(account) : null;
}

export function hasDemoPhoneAccount(phoneInput: string): boolean {
  return getDemoPhoneUser(phoneInput) !== null;
}

/**
 * Creates/reads a browser-only test account after the fixed mock OTP is verified.
 * Phone authentication does not create or modify any Supabase account.
 */
export function completeDemoPhoneLogin(phoneInput: string, nameInput: string): CurrentUser {
  const phone = normalizePhone(phoneInput);
  const accounts = readAccounts();
  const existing = accounts.find(item => item.phone === phone);
  if (existing) return toPublicUser(existing);

  const name = nameInput.trim();
  if (!name) throw new Error('Enter a display name for this local demo account.');
  const account: DemoAccount = {
    id: `${demoIdPrefix}${phone.slice(1)}`,
    name,
    phone,
  };
  writeAccounts([...accounts, account]);
  return toPublicUser(account);
}

export function updateDemoUserName(userId: string, nameInput: string): CurrentUser {
  if (!userId.startsWith(demoIdPrefix)) throw new Error('Only a local demo phone account can be updated here.');
  const name = nameInput.trim();
  if (!name) throw new Error('Name cannot be empty.');
  const accounts = readAccounts();
  const index = accounts.findIndex(item => item.id === userId);
  if (index < 0) throw new Error('The local demo phone account could not be found.');
  accounts[index] = { ...accounts[index], name };
  writeAccounts(accounts);
  const user = toPublicUser(accounts[index]);
  if (localStorage.getItem(identityKey)) saveDemoUser(user);
  return user;
}

/** Stores a salted password hash for local demo recovery; phone login remains OTP-only. */
export async function resetDemoPhonePassword(phoneInput: string, password: string): Promise<void> {
  const phone = normalizePhone(phoneInput);
  if (password.length < 8) throw new Error('Password must be at least 8 characters.');
  if (!globalThis.crypto?.subtle || !globalThis.crypto?.getRandomValues) throw new Error('Secure password storage is unavailable in this browser.');
  const accounts = readAccounts();
  const index = accounts.findIndex(item => item.phone === phone);
  if (index < 0) throw new Error('Password reset is available only for an existing local demo phone account.');
  const salt = crypto.getRandomValues(new Uint8Array(16));
  accounts[index] = {
    ...accounts[index],
    passwordSalt: [...salt].map(byte => byte.toString(16).padStart(2, '0')).join(''),
    passwordHash: await hashPassword(password, salt),
  };
  writeAccounts(accounts);
}