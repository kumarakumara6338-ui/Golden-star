import { getApps, initializeApp } from 'firebase/app';
import {
  getAuth,
  type Auth,
  type User,
} from 'firebase/auth';
import type { CurrentUser } from './pro-types';
import { parseFirebaseWebConfig, type FirebaseWebConfig } from './firebase-web-config';

type FirebaseConfig = FirebaseWebConfig;

const firebaseAppName = 'golden-star-auth';
let parsedConfig: FirebaseConfig | null = null;
let configIssue = '';
let configLoaded = false;
let authInstance: Auth | null = null;

function loadConfig(): FirebaseConfig | null {
  if (configLoaded) return parsedConfig;
  configLoaded = true;
  const parsed = parseFirebaseWebConfig(import.meta.env.VITE_FIREBASE_CONFIG);
  configIssue = parsed.issue;
  parsedConfig = parsed.config;
  return parsedConfig;
}

export function getFirebaseConfigIssue(): string {
  loadConfig();
  return configIssue;
}

export function getFirebaseAuth(): Auth | null {
  const config = loadConfig();
  if (!config) return null;
  if (authInstance) return authInstance;

  try {
    const existingApp = getApps().find(app => app.name === firebaseAppName);
    const app = existingApp ?? initializeApp(config, firebaseAppName);
    authInstance = getAuth(app);
    configIssue = '';
    return authInstance;
  } catch {
    configIssue = 'Firebase could not initialize. Check the Firebase client configuration and app setup.';
    return null;
  }
}

export async function getFirebaseAccountId(uid: string): Promise<string> {
  const projectId = loadConfig()?.projectId;
  if (!projectId) {
    throw new Error(getFirebaseConfigIssue() || 'Firebase project configuration is unavailable.');
  }
  const bytes = new TextEncoder().encode(`firebase:${projectId}:${uid}`);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  const hex = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
  return `firebase-${hex.slice(0, 32)}`;
}

export async function firebaseUserToCurrentUser(user: User): Promise<CurrentUser> {
  return {
    id: await getFirebaseAccountId(user.uid),
    name: user.displayName?.trim() || user.email?.split('@')[0] || user.phoneNumber || 'Golden Star member',
    ...(user.phoneNumber ? { phone: user.phoneNumber } : {}),
    ...(user.email ? { email: user.email } : {}),
    authProvider: 'firebase',
  };
}