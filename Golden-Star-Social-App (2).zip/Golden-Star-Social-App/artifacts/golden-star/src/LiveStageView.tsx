import { useState, type FormEvent, type RefObject } from 'react';
import { Camera, Eye, Gift, Heart, MessageCircle, Mic, MicOff, Music2, Send, SwitchCamera, X } from 'lucide-react';
import './live-stage.css';

export type LiveStageViewProps = {
  role: 'host' | 'viewer';
  hostName: string;
  demo?: boolean;
  videoContainerRef: RefObject<HTMLDivElement | null>;
  status: string;
  error: string | null;
  viewerCount: number;
  muted: boolean;
  cameraFacing: 'front' | 'back';
  songName: string | null;
  events: { id: string; type: 'chat' | 'like' | 'gift'; name: string; text: string }[];
  onSwitchCamera: () => void;
  onToggleMute: () => void;
  onAddSong: () => void;
  onEnd: () => void;
  onClose: () => void;
  onLike: () => void;
  onGift: () => void;
  onSendChat: (message: string) => void;
};

export default function LiveStageView({
  role, hostName, demo = false, videoContainerRef, status, error, viewerCount, muted, cameraFacing,
  songName, events, onSwitchCamera, onToggleMute, onAddSong, onEnd, onClose,
  onLike, onGift, onSendChat,
}: LiveStageViewProps) {
  const [message, setMessage] = useState('');
  const isHost = role === 'host';
  const initials = hostName.trim().split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase() || 'GS';

  function submitChat(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const trimmed = message.trim();
    if (!trimmed) return;
    onSendChat(trimmed);
    setMessage('');
  }

  return (
    <section className={`live-stage live-stage--${role}`} aria-label={demo ? `${hostName}'s local live demo` : `${hostName}'s live broadcast`}>
      <div className="live-stage__frame">
        <div ref={videoContainerRef} className="live-stage__video" aria-label="Live video" data-testid="container-live-video" />
        <div className="live-stage__top">
          <div className="live-stage__identity">
            <span className="live-stage__avatar" aria-hidden="true">{initials}</span>
            <div className="live-stage__person">
              <strong data-testid="text-live-host-name">{hostName}</strong>
              <span>{demo ? 'Camera preview only · not broadcast' : isHost ? 'Your broadcast' : 'Broadcasting now'}</span>
            </div>
          </div>
          <div className="live-stage__top-actions">
            {(demo || (!status && !error)) && <span className="live-stage__badge" data-testid="badge-live">{demo ? 'DEMO LIVE' : 'LIVE'}</span>}
            <span className="live-stage__count" aria-label={`${viewerCount.toLocaleString()} viewers`} data-testid="text-live-viewer-count"><Eye size={14} aria-hidden="true" /> {viewerCount.toLocaleString()}</span>
            <button className="live-stage__close" type="button" onClick={onClose} aria-label={isHost ? 'Close live stage' : 'Leave live broadcast'} title={isHost ? 'Close stage' : 'Leave live'} data-testid="button-close-live"><X size={19} aria-hidden="true" /></button>
          </div>
        </div>
        <div className="live-stage__frame-foot">
          <p className="live-stage__kicker">Golden Star Pro / after hours</p>
          <h1 className="live-stage__headline">The moment<br />is live.</h1>
          {songName && <div className="live-stage__song" data-testid="text-live-song"><Music2 size={15} aria-hidden="true" /><span>{songName}</span></div>}
        </div>
      </div>

      <aside className="live-stage__side" aria-label="Live activity and controls">
        <div className="live-stage__side-head">
          <span>In the room</span>
          <h2>Live conversation</h2>
        </div>
        <div className="live-stage__events" role="log" aria-label="Live activity" aria-live="polite" aria-relevant="additions text" data-testid="feed-live-events">
          {events.length === 0 ? <p className="live-stage__empty">The room is open. Be the first to say something.</p> : events.map(item => (
            <p key={item.id} className={`live-stage__event live-stage__event--${item.type}`} data-testid={`event-live-${item.id}`}>
              {item.type === 'chat' ? <MessageCircle size={13} aria-hidden="true" /> : item.type === 'like' ? <Heart size={13} aria-hidden="true" /> : <Gift size={13} aria-hidden="true" />}
              <span><strong>{item.name}</strong>{' '}{item.text}</span>
            </p>
          ))}
        </div>
        {error ? <p className="live-stage__status live-stage__error" role="alert" data-testid="status-live-error">{error}</p> : status && <p className="live-stage__status" role="status" data-testid="status-live">{status}</p>}
        {demo && <p className="mb-3 text-xs leading-relaxed text-amber-100/75">Demo only — comments, likes, gifts, and music stay on this device.</p>}
        {isHost ? (
          <div aria-label="Host controls">
            <div className="live-stage__host-controls">
              <button className="live-stage__tool" type="button" onClick={onSwitchCamera} aria-label={`Switch camera, currently ${cameraFacing} facing`} title={`Switch camera (${cameraFacing})`} data-testid="button-switch-camera"><SwitchCamera size={20} aria-hidden="true" /><span>Flip camera</span></button>
              <button className="live-stage__tool" type="button" onClick={onToggleMute} aria-pressed={muted} aria-label={muted ? 'Unmute microphone' : 'Mute microphone'} data-testid="button-toggle-live-mute">{muted ? <MicOff size={20} aria-hidden="true" /> : <Mic size={20} aria-hidden="true" />}<span>{muted ? 'Unmute' : 'Mute'}</span></button>
              <button className="live-stage__tool" type="button" onClick={onAddSong} aria-label={songName ? 'Change song' : 'Add a song'} data-testid="button-add-live-song"><Music2 size={20} aria-hidden="true" /><span>{songName ? 'Change song' : 'Add song'}</span></button>
            </div>
            <div className="live-stage__controls mt-2">
              <form className="live-stage__composer" onSubmit={submitChat}>
                <input type="text" value={message} maxLength={300} onChange={event => setMessage(event.target.value)} aria-label={demo ? 'Write a demo chat message' : 'Write a live chat message'} placeholder="Say something..." data-testid="input-live-chat" />
                <button className="live-stage__send" type="submit" disabled={!message.trim()} aria-label="Send message" data-testid="button-send-live-chat"><Send size={17} aria-hidden="true" /></button>
              </form>
              <button className="live-stage__icon-button" type="button" onClick={onLike} aria-label={demo ? 'Add a demo like' : 'Like this live broadcast'} title="Like" data-testid="button-like-live"><Heart size={21} aria-hidden="true" /></button>
              <button className="live-stage__icon-button" type="button" onClick={onGift} aria-label={demo ? 'Add a demo gift' : 'Send a gift'} title="Send gift" data-testid="button-gift-live"><Gift size={21} aria-hidden="true" /></button>
            </div>
            <button className="live-stage__end" type="button" onClick={onEnd} data-testid="button-end-live"><Camera size={16} aria-hidden="true" /> End live</button>
          </div>
        ) : (
          <div className="live-stage__controls">
            <form className="live-stage__composer" onSubmit={submitChat}>
              <input type="text" value={message} maxLength={300} onChange={event => setMessage(event.target.value)} aria-label="Write a live chat message" placeholder="Say something..." data-testid="input-live-chat" />
              <button className="live-stage__send" type="submit" disabled={!message.trim()} aria-label="Send message" data-testid="button-send-live-chat"><Send size={17} aria-hidden="true" /></button>
            </form>
            <button className="live-stage__icon-button" type="button" onClick={onLike} aria-label="Like this live broadcast" title="Like" data-testid="button-like-live"><Heart size={21} aria-hidden="true" /></button>
            <button className="live-stage__icon-button" type="button" onClick={onGift} aria-label="Send a gift" title="Send gift" data-testid="button-gift-live"><Gift size={21} aria-hidden="true" /></button>
          </div>
        )}
      </aside>
    </section>
  );
}