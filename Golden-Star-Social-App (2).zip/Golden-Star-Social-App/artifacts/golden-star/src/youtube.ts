export type YouTubeVideo = {
  id: string;
  title: string;
  channel: string;
  thumbnail: string;
};

export function youtubeVideoId(link: string): string | null {
  try {
    const url = new URL(link.trim());
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    const host = url.hostname.toLowerCase();
    const parts = url.pathname.split('/').filter(Boolean);
    let id: string | undefined | null;
    if (host === 'youtu.be' || host === 'www.youtu.be') id = parts[0];
    else if (['youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtube-nocookie.com', 'www.youtube-nocookie.com'].includes(host)) {
      id = parts[0] === 'watch' ? url.searchParams.get('v') :
        ['shorts', 'live', 'embed', 'v'].includes(parts[0]) ? parts[1] : null;
    }
    return id && /^[a-zA-Z0-9_-]{11}$/.test(id) ? id : null;
  } catch {
    return null;
  }
}

export function youtubeIdInText(text: string): string | null {
  for (const candidate of text.match(/https?:\/\/[^\s<>"']+/g) || []) {
    const id = youtubeVideoId(candidate.replace(/[).,!]+$/, ''));
    if (id) return id;
  }
  return null;
}

export function youtubeWatchUrl(id: string): string {
  return `https://www.youtube.com/watch?v=${id}`;
}

export function youtubeThumbnail(id: string): string {
  return `https://img.youtube.com/vi/${id}/mqdefault.jpg`;
}