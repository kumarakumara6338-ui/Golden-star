import { useEffect, useRef, useState, type FormEvent, type MouseEvent } from 'react';
import {
  ArrowLeft, Check, CheckCheck, ChevronDown, CircleUserRound, Copy, Download, FileText,
  Forward, ImagePlus, Info, Paperclip, Phone, Reply, Send, Smile, Trash2,
   UserRoundX, Video, X, Shield,
} from 'lucide-react';
import type { ChatMessage } from './pro-types';
import { useMediaUrl } from './media';
import { youtubeIdInText, youtubeThumbnail, youtubeWatchUrl } from './youtube';
import './chat-pro.css';

type ChatPageProps = {
  contacts: string[];
  messages: Record<string, ChatMessage[]>;
  blockedUsers: string[];
  onSend: (contact: string, text: string, replyTo?: number) => void;
  onAttach: (contact: string, file: File, replyTo?: number) => Promise<void> | void;
  onDelete: (contact: string, ids: number[]) => void;
  onForward: (source: string, ids: number[], target: string) => void;
  onBlock: (name: string) => void;
  onUnblock: (name: string) => void;
  onCall: (kind: 'audio' | 'video', name: string) => void;
  onToast: (message: string) => void;
  incomingShare?: { id: string; title: string } | null;
  onShareConsumed?: () => void;
};

const emojiChoices = ['😀', '😂', '🥰', '😉', '😍', '😎', '🤍', '✨', '🌟', '💛', '🎉', '👍', '🙏', '❤️', '🔥', '😊'];

function initials(name: string) {
  return name.trim().split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase() || '?';
}

function AttachmentPreview({ message }: { message: ChatMessage }) {
  const url = useMediaUrl(message.attachmentId);
  if (!message.attachmentId) return null;
  const type = (message.attachmentType || '').toLowerCase();
  const name = message.attachmentName || 'Attachment';
  const isImage = type.startsWith('image/') || /\.(png|jpe?g|gif|webp|avif)$/i.test(name);
  const isVideo = type.startsWith('video/') || /\.(mp4|webm|mov|m4v)$/i.test(name);
  if (url === undefined) return <span className="pro-chat-media-loading">Loading attachment…</span>;
  if (!url) return <span className="pro-chat-media-missing">Attachment unavailable</span>;
  if (isImage) return <a className="pro-chat-image-link" href={url} target="_blank" rel="noreferrer"><img className="pro-chat-image" src={url} alt={name} /></a>;
  if (isVideo) return <video className="pro-chat-video" src={url} controls preload="metadata" aria-label={name} />;
  return <a className="pro-chat-download" href={url} download={name}><FileText size={18} /><span>{name}</span><Download size={16} /></a>;
}

function MessageItem({
  message, selected, selectionMode, onToggle, onMenu, onDoubleClick, onContextMenu,
}: {
  message: ChatMessage;
  selected: boolean;
  selectionMode: boolean;
  onToggle: () => void;
  onMenu: () => void;
  onDoubleClick: () => void;
  onContextMenu: (event: MouseEvent) => void;
}) {
  const pressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const longPressed = useRef(false);
  const [playingVideo, setPlayingVideo] = useState(false);
  const youtubeId = youtubeIdInText(message.text);
  const cancelPress = () => {
    if (pressTimer.current) clearTimeout(pressTimer.current);
    pressTimer.current = null;
  };
  const startPress = () => {
    cancelPress();
    longPressed.current = false;
    pressTimer.current = setTimeout(() => {
      longPressed.current = true;
      onMenu();
    }, 520);
  };
  const handleClick = () => {
    if (longPressed.current) {
      longPressed.current = false;
      return;
    }
    if (selectionMode) onToggle();
  };
  useEffect(() => cancelPress, []);
  return (
    <div className={`pro-chat-message-row ${selected ? 'is-selected' : ''}`} onClick={handleClick}>
      {selectionMode && <button type="button" className="pro-chat-select-dot" onClick={event => { event.stopPropagation(); onToggle(); }} aria-label={selected ? 'Deselect message' : 'Select message'}>{selected ? <Check size={13} /> : null}</button>}
      <article
        className={`pro-chat-bubble ${message.attachmentId ? 'has-attachment' : ''}`}
        onPointerDown={startPress}
        onPointerUp={cancelPress}
        onPointerLeave={cancelPress}
        onPointerCancel={cancelPress}
        onContextMenu={event => { event.preventDefault(); cancelPress(); onContextMenu(event); }}
        onDoubleClick={event => { event.preventDefault(); onDoubleClick(); }}
        aria-label="Message"
      >
        {message.forwarded && <span className="pro-chat-forwarded"><Forward size={12} /> Forwarded</span>}
        {message.replyTo && <div className="pro-chat-reply-in-bubble"><span>Replying to</span><p>{message.replyTo.text}</p></div>}
        {message.text && <p className="pro-chat-message-text">{message.text}</p>}
         {youtubeId && <div className="pro-chat-youtube" onClick={event => event.stopPropagation()} onPointerDown={event => event.stopPropagation()}>
           {playingVideo ? <iframe src={`https://www.youtube.com/embed/${youtubeId}`} title="YouTube video in chat" allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen /> :
             <button type="button" className="pro-chat-youtube-play" data-testid={`button-play-chat-video-${message.id}`} onClick={() => setPlayingVideo(true)}><img src={youtubeThumbnail(youtubeId)} alt="YouTube video thumbnail" /><span>▶ Play YouTube video</span></button>}
           <a href={youtubeWatchUrl(youtubeId)} target="_blank" rel="noopener noreferrer">Open on YouTube</a>
         </div>}
        <AttachmentPreview message={message} />
        <div className="pro-chat-message-meta">
          {message.createdAt && <time>{new Date(message.createdAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</time>}
          {message.status === 'sent' && <span className="pro-chat-status" aria-label="Sent" title="Sent"><Check size={13} /></span>}
          {message.status === 'delivered' && <span className="pro-chat-status" aria-label="Delivered" title="Delivered"><CheckCheck size={15} /></span>}
          {message.status === 'seen' && <span className="pro-chat-status seen" aria-label="Seen" title="Seen"><CheckCheck size={15} /></span>}
        </div>
      </article>
    </div>
  );
}

export default function ChatPage({
  contacts, messages, blockedUsers, onSend, onAttach, onDelete, onForward,
  onBlock, onUnblock, onCall, onToast, incomingShare, onShareConsumed,
}: ChatPageProps) {
  const [activeContact, setActiveContact] = useState(contacts[0] || '');
  const [draft, setDraft] = useState('');
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null);
  const [menuMessage, setMenuMessage] = useState<number | null>(null);
  const [contactMenu, setContactMenu] = useState<string | null>(null);
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [forwardPicker, setForwardPicker] = useState<number[] | null>(null);
  const [showEmoji, setShowEmoji] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [contactSearch, setContactSearch] = useState('');
  const fileInput = useRef<HTMLInputElement>(null);
  const cameraInput = useRef<HTMLInputElement>(null);
  const messagesEnd = useRef<HTMLDivElement>(null);
  const blocked = blockedUsers.includes(activeContact);
  const thread = messages[activeContact] || [];

  useEffect(() => {
    if (!contacts.includes(activeContact)) setActiveContact(contacts[0] || '');
  }, [contacts, activeContact]);
  useEffect(() => {
    messagesEnd.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [activeContact, thread.length]);
  useEffect(() => {
    setMenuMessage(null);
    setSelectedIds([]);
    setSelectionMode(false);
    setReplyTo(null);
    setDraft('');
  }, [activeContact]);
  useEffect(() => {
    if (!incomingShare) return;
    setDraft(`${incomingShare.title}\n${youtubeWatchUrl(incomingShare.id)}`.slice(0, 500));
    onShareConsumed?.();
  }, [incomingShare?.id]);

  const copyText = async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      onToast('Copied');
    } catch {
      onToast('Clipboard access was denied');
    }
  };
  const messageById = (id: number) => thread.find(message => message.id === id);
  const toggleSelected = (id: number) => setSelectedIds(ids => ids.includes(id) ? ids.filter(value => value !== id) : [...ids, id]);
  const openForward = (ids: number[]) => {
    setMenuMessage(null);
    setContactMenu(null);
    setForwardPicker(ids);
  };
  const deleteMessages = (ids: number[]) => {
    onDelete(activeContact, ids);
    setSelectedIds([]);
    setSelectionMode(false);
    setMenuMessage(null);
    setForwardPicker(null);
  };
  const sendMessage = (event: FormEvent) => {
    event.preventDefault();
    const text = draft.trim();
    if (!text || blocked || !activeContact) return;
    onSend(activeContact, text, replyTo?.id);
    setDraft('');
    setReplyTo(null);
    setShowEmoji(false);
  };
  const attachFile = async (file?: File) => {
    if (!file || blocked || !activeContact) return;
    try {
      await onAttach(activeContact, file, replyTo?.id);
      setReplyTo(null);
    } catch (error) {
      onToast(error instanceof Error ? error.message : 'Could not attach this file');
    }
  };
  const paste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) setDraft(current => `${current}${text}`.slice(0, 500));
    } catch {
      onToast('Clipboard access was denied');
    }
  };
  const chooseForwardTarget = (target: string) => {
    if (!forwardPicker) return;
    onForward(activeContact, forwardPicker, target);
    setForwardPicker(null);
    setSelectedIds([]);
    setSelectionMode(false);
  };
  const openMessageMenu = (id: number) => {
    setContactMenu(null);
    setMenuMessage(current => current === id ? null : id);
  };
  const onMessageContext = (id: number) => setMenuMessage(id);
  const beginReply = (id: number) => {
    const message = messageById(id);
    if (message) setReplyTo(message);
    setMenuMessage(null);
  };
  const beginSelection = (id: number) => {
    setSelectionMode(true);
    setSelectedIds(ids => ids.includes(id) ? ids : [...ids, id]);
    setMenuMessage(null);
  };
  const contactPress = useRef<ReturnType<typeof setTimeout> | null>(null);
  const contactLongPressed = useRef(false);
  const clearContactPress = () => {
    if (contactPress.current) clearTimeout(contactPress.current);
    contactPress.current = null;
  };
  const startContactPress = (name: string) => {
    clearContactPress();
    contactLongPressed.current = false;
    contactPress.current = setTimeout(() => {
      contactLongPressed.current = true;
      setContactMenu(name);
    }, 520);
  };
  useEffect(() => clearContactPress, []);

  return (
    <section className="pro-chat" aria-label="Chat">
      <div className="pro-chat-heading"><div><span className="pro-chat-eyebrow">GOLDEN STAR PRO · PRIVATE SPACE</span><h1>Messages</h1><p>Your conversations stay on this device.</p></div><span className="pro-chat-local-pill"><span /> Local chat</span></div>
      <div className="pro-chat-shell">
        <aside className="pro-chat-sidebar">
          <div className="pro-chat-sidebar-title"><h2>Conversations</h2><span>{contacts.length}</span></div>
          <label className="pro-chat-search"><span className="pro-chat-visually-hidden">Search contacts</span><input value={contactSearch} onChange={event => setContactSearch(event.target.value)} placeholder="Find a conversation" /></label>
          <div className="pro-chat-contact-list">
            {contacts.filter(name => name.toLowerCase().includes(contactSearch.toLowerCase())).map((name, index) => (
              <div className="pro-chat-contact-wrap" key={name}
                onPointerDown={() => startContactPress(name)}
                onPointerUp={clearContactPress}
                onPointerLeave={clearContactPress}
                onPointerCancel={clearContactPress}
                onContextMenu={event => { event.preventDefault(); clearContactPress(); setContactMenu(name); }}>
                <button type="button" className={`pro-chat-contact ${name === activeContact ? 'active' : ''}`} onClick={() => {
                  if (contactLongPressed.current) { contactLongPressed.current = false; return; }
                  setActiveContact(name);
                }}>
                  <span className="pro-chat-avatar">{initials(name)}</span>
                  <span className="pro-chat-contact-copy"><strong>{name}</strong><small>{blockedUsers.includes(name) ? 'Blocked' : (messages[name]?.[Math.max(0, (messages[name]?.length || 1) - 1)]?.text || 'Start a conversation')}</small></span>
                  {blockedUsers.includes(name) && <UserRoundX size={15} className="pro-chat-blocked-icon" />}
                </button>
                {contactMenu === name && <div className="pro-chat-contact-menu" role="menu" onPointerDown={event => event.stopPropagation()} onContextMenu={event => event.stopPropagation()}>
                  <button type="button" role="menuitem" onClick={() => { setActiveContact(name); setShowInfo(true); setContactMenu(null); }}><Info size={15} /> Contact info</button>
                  <button type="button" role="menuitem" onClick={() => { blockedUsers.includes(name) ? onUnblock(name) : onBlock(name); setContactMenu(null); }}><UserRoundX size={15} /> {blockedUsers.includes(name) ? 'Unblock User' : 'Block User'}</button>
                </div>}
              </div>
            ))}
            {!contacts.length && <p className="pro-chat-no-contacts">No contacts available.</p>}
          </div>
          <p className="pro-chat-sidebar-note">Messages and calls are local app actions. No delivery is implied.</p>
        </aside>

        <main className="pro-chat-thread">
          <div className="flex items-start gap-2 border-b border-[#43361b] bg-[#171309] px-4 py-2 text-xs leading-relaxed text-[#cbb874]" title="These messages stay in your browser; no recipient key exchange or encrypted network messaging is enabled."><Shield size={15} className="mt-0.5 shrink-0" /><span><strong>End-to-End Encryption: not enabled in this demo.</strong> Local messages only; no WhatsApp connection or encrypted delivery.</span></div>
          {activeContact ? <>
            <header className="pro-chat-header">
              <div className="pro-chat-person">
                <span className="pro-chat-avatar">{initials(activeContact)}</span><span><strong>{activeContact}</strong><small>{blocked ? 'Blocked contact' : 'Private conversation'}</small></span>
              </div>
              <div className="pro-chat-header-actions">
                <button type="button" aria-label="Audio call" title="Audio call" disabled={blocked} onClick={() => onCall('audio', activeContact)}><Phone size={18} /></button>
                <button type="button" aria-label="Video call" title="Video call" disabled={blocked} onClick={() => onCall('video', activeContact)}><Video size={19} /></button>
                <button type="button" aria-label="Contact information" title="Contact information" onClick={() => setShowInfo(true)}><Info size={18} /></button>
              </div>
            </header>
            <div className="pro-chat-demo-note">Preview status only · no message is delivered to another person</div>
            {blocked && <div className="pro-chat-block-banner"><UserRoundX size={18} /><span><strong>{activeContact} is blocked.</strong> You can’t send messages, attach files, or start a call while this contact is blocked.</span></div>}
            {selectionMode && <div className="pro-chat-selection-bar"><strong>{selectedIds.length} selected</strong><div>
              <button type="button" disabled={!selectedIds.length} onClick={() => { const text = selectedIds.map(id => { const message = messageById(id); return message?.text || message?.attachmentName || ''; }).filter(Boolean).join('\n'); void copyText(text); }}><Copy size={15} /> Copy</button>
              <button type="button" disabled={!selectedIds.length} onClick={() => openForward(selectedIds)}><Forward size={15} /> Forward</button>
              <button type="button" disabled={!selectedIds.length} onClick={() => deleteMessages(selectedIds)}><Trash2 size={15} /> Delete</button>
              <button type="button" aria-label="Exit selection" onClick={() => { setSelectionMode(false); setSelectedIds([]); }}><X size={16} /></button>
            </div></div>}
            <div className="pro-chat-messages">
              {!thread.length && <div className="pro-chat-empty"><span className="pro-chat-empty-star">✦</span><strong>Your space with {activeContact}</strong><p>Messages you add here remain in this app’s local conversation.</p></div>}
              {thread.map(message => <div className="pro-chat-message-wrap" key={message.id}>
                <MessageItem
                  message={message}
                  selected={selectedIds.includes(message.id)}
                  selectionMode={selectionMode}
                  onToggle={() => toggleSelected(message.id)}
                  onMenu={() => openMessageMenu(message.id)}
                  onContextMenu={() => onMessageContext(message.id)}
                  onDoubleClick={() => { void copyText(message.text || message.attachmentName || ''); }}
                />
                {menuMessage === message.id && <div className="pro-chat-message-menu" role="menu">
                  <button type="button" role="menuitem" onClick={() => { void copyText(message.text || message.attachmentName || ''); setMenuMessage(null); }}><Copy size={15} /> Copy</button>
                  <button type="button" role="menuitem" onClick={() => beginReply(message.id)}><Reply size={15} /> Reply</button>
                  <button type="button" role="menuitem" onClick={() => openForward([message.id])}><Forward size={15} /> Forward</button>
                  <button type="button" role="menuitem" onClick={() => deleteMessages([message.id])}><Trash2 size={15} /> Delete</button>
                  <button type="button" role="menuitem" onClick={() => beginSelection(message.id)}><Check size={15} /> Select multiple</button>
                </div>}
              </div>)}
              <div ref={messagesEnd} />
            </div>
            {replyTo && <div className="pro-chat-reply-compose"><div><span>Replying to</span><p>{replyTo.text || replyTo.attachmentName || 'Attachment'}</p></div><button type="button" aria-label="Cancel reply" onClick={() => setReplyTo(null)}><X size={17} /></button></div>}
            <form className="pro-chat-composer" onSubmit={sendMessage}>
              <div className="pro-chat-compose-tools">
                <button type="button" title="Attach a file" aria-label="Attach a file" disabled={blocked} onClick={() => fileInput.current?.click()}><Paperclip size={18} /></button>
                <button type="button" title="Take a photo or video" aria-label="Take a photo or video" disabled={blocked} onClick={() => cameraInput.current?.click()}><ImagePlus size={18} /></button>
                <button type="button" title="Paste from clipboard" aria-label="Paste from clipboard" disabled={blocked} onClick={() => void paste()}><span className="pro-chat-paste-label">Paste</span></button>
              </div>
              <div className="pro-chat-input-wrap">
                <textarea value={draft} maxLength={500} rows={1} disabled={blocked} onChange={event => setDraft(event.target.value)} placeholder={blocked ? 'Unblock this contact to write' : 'Write a message…'} aria-label="Write a message" onKeyDown={event => {
                  if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendMessage(event); }
                }} />
                <div className="pro-chat-emoji-wrap">
                  <button type="button" className="pro-chat-emoji-trigger" aria-label="Choose emoji" title="Choose emoji" disabled={blocked} onClick={() => setShowEmoji(open => !open)}><Smile size={19} /></button>
                  {showEmoji && <div className="pro-chat-emoji-picker" aria-label="Emoji picker">{emojiChoices.map(emoji => <button type="button" key={emoji} aria-label={`Insert ${emoji}`} onClick={() => setDraft(value => `${value}${emoji}`.slice(0, 500))}>{emoji}</button>)}</div>}
                </div>
              </div>
              <button className="pro-chat-send" type="submit" aria-label="Send message" disabled={blocked || !draft.trim()}><Send size={17} /></button>
              <input ref={fileInput} className="pro-chat-hidden-input" type="file" aria-label="Choose attachment" onChange={event => { void attachFile(event.target.files?.[0]); event.currentTarget.value = ''; }} />
              <input ref={cameraInput} className="pro-chat-hidden-input" type="file" accept="image/*,video/*" capture="environment" aria-label="Capture photo or video" onChange={event => { void attachFile(event.target.files?.[0]); event.currentTarget.value = ''; }} />
              <span className="pro-chat-size-note">Attachments up to 25 MB</span>
            </form>
          </> : <div className="pro-chat-empty-thread"><CircleUserRound size={34} /><strong>Select a contact</strong><span>Choose a conversation to get started.</span></div>}
        </main>
      </div>

      {showInfo && activeContact && <div className="pro-chat-modal-backdrop" onClick={() => setShowInfo(false)}>
        <section className="pro-chat-info-panel" aria-label={`${activeContact} contact information`} onClick={event => event.stopPropagation()}>
          <div className="pro-chat-panel-heading"><button type="button" aria-label="Back to chat" onClick={() => setShowInfo(false)}><ArrowLeft size={18} /></button><h2>Contact information</h2><button type="button" aria-label="Close contact information" onClick={() => setShowInfo(false)}><X size={19} /></button></div>
          <span className="pro-chat-avatar pro-chat-avatar-large">{initials(activeContact)}</span><h3>{activeContact}</h3><p className="pro-chat-info-caption">Golden Star contact</p>
          <div className="pro-chat-info-card"><Info size={16} /><span>This is a local chat interface. It does not confirm that a real person received messages or calls.</span></div>
          <button type="button" className={`pro-chat-block-action ${blocked ? 'is-unblock' : ''}`} onClick={() => blocked ? onUnblock(activeContact) : onBlock(activeContact)}><UserRoundX size={17} />{blocked ? 'Unblock User' : 'Block User'}</button>
        </section>
      </div>}

      {forwardPicker && <div className="pro-chat-modal-backdrop" onClick={() => setForwardPicker(null)}>
        <section className="pro-chat-forward-panel" aria-label="Forward to contact" onClick={event => event.stopPropagation()}>
          <div className="pro-chat-panel-heading"><h2>Forward to…</h2><button type="button" aria-label="Close contact picker" onClick={() => setForwardPicker(null)}><X size={19} /></button></div>
          <p>{forwardPicker.length} message{forwardPicker.length === 1 ? '' : 's'} will be added to a local conversation.</p>
          <div className="pro-chat-forward-list">{contacts.map(name => <button type="button" key={name} disabled={blockedUsers.includes(name)} onClick={() => chooseForwardTarget(name)}><span className="pro-chat-avatar">{initials(name)}</span><strong>{name}{blockedUsers.includes(name) ? ' · Blocked' : ''}</strong><ChevronDown size={15} /></button>)}</div>
          {!contacts.length && <p>No contacts available.</p>}
        </section>
      </div>}
    </section>
  );
}