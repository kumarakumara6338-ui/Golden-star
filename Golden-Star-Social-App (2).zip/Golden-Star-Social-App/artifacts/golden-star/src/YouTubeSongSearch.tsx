import { useEffect, useRef, useState } from 'react';
import { Music2, Search } from 'lucide-react';
import type { YouTubeVideo } from './youtube';

type Props = {
  selected?: YouTubeVideo | null;
  onSelect: (video: YouTubeVideo) => void;
  autoFocus?: boolean;
};

type Page = { items: YouTubeVideo[]; nextPageToken?: string };

export default function YouTubeSongSearch({ selected, onSelect, autoFocus }: Props) {
  const [q, setQ] = useState('');
  const [items, setItems] = useState<YouTubeVideo[]>([]);
  const [next, setNext] = useState<string | undefined>();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [retry, setRetry] = useState(0);
  const ctrl = useRef<AbortController | null>(null);

  const run = async (query: string, token?: string) => {
    ctrl.current?.abort();
    const c = new AbortController();
    ctrl.current = c;
    setLoading(true);
    setError('');
    try {
      const url = `/api/youtube/search?q=${encodeURIComponent(query)}${token ? `&pageToken=${encodeURIComponent(token)}` : ''}`;
      const res = await fetch(url, { signal: c.signal, credentials: 'include' });
      if (!res.ok) throw new Error('bad');
      const data = (await res.json()) as Page;
      const list = Array.isArray(data.items) ? data.items : [];
      setItems(prev => (token ? [...prev, ...list] : list));
      setNext(data.nextPageToken);
    } catch (e) {
      if ((e as Error).name === 'AbortError') return;
      setError('Song search is unavailable right now.');
    } finally {
      if (ctrl.current === c) setLoading(false);
    }
  };

  useEffect(() => {
    const query = q.trim();
    if (query.length < 2) { ctrl.current?.abort(); setItems([]); setNext(undefined); setLoading(false); setError(''); return; }
    const id = setTimeout(() => { void run(query); }, 350);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, retry]);

  useEffect(() => () => ctrl.current?.abort(), []);

  return (
    <div className="text-[#f4ecd9]" data-testid="song-search">
      <label htmlFor="yt-song-q" className="mb-1 block text-xs font-semibold text-[#ffd700]">Search YouTube for a song</label>
      <div className="flex items-center gap-2 rounded-lg border border-[#ffd700]/30 bg-[#1d1912] px-3">
        <Search size={16} className="text-[#a69a83]" />
        <input id="yt-song-q" value={q} onChange={e => setQ(e.target.value)} autoFocus={autoFocus} type="search"
          placeholder="Song or artist" className="h-11 w-full bg-transparent text-base outline-none placeholder:text-[#a69a83]" data-testid="input-song-search" />
      </div>
      <div aria-live="polite" className="mt-2">
        {loading && !items.length && <div className="grid gap-2">{[0, 1, 2].map(n => <div key={n} className="h-14 animate-pulse rounded-lg bg-[#1d1912]" />)}</div>}
        {error && (
          <p role="alert" className="text-xs text-red-300">{error}{' '}
            <button type="button" onClick={() => setRetry(n => n + 1)} className="font-bold text-[#ffd700] underline" data-testid="button-song-retry">Retry</button></p>
        )}
        {!loading && !error && q.trim().length >= 2 && !items.length && <p className="text-xs text-[#a69a83]">No songs found.</p>}
        {q.trim().length < 2 && !items.length && <p className="flex items-center gap-1 text-xs text-[#a69a83]"><Music2 size={14} />Type at least 2 characters.</p>}
      </div>
      {items.length > 0 && (
        <ul className="mt-2 grid max-h-64 gap-1.5 overflow-y-auto">
          {items.map(v => (
            <li key={v.id}>
              <button type="button" onClick={() => onSelect(v)} aria-pressed={selected?.id === v.id}
                className={`flex w-full items-center gap-3 rounded-lg border p-2 text-left ${selected?.id === v.id ? 'border-[#ffd700] bg-[#ffd700]/10' : 'border-[#ffd700]/15 bg-[#1d1912]'}`}
                data-testid={`button-yt-result-${v.id}`}>
                <img src={v.thumbnail} alt="" className="h-10 w-16 shrink-0 rounded object-cover" />
                <span className="min-w-0"><span className="block truncate text-sm font-semibold">{v.title}</span>
                  <span className="block truncate text-xs text-[#a69a83]">{v.channel}</span></span>
              </button>
            </li>
          ))}
          {next && (
            <li><button type="button" disabled={loading} onClick={() => void run(q.trim(), next)}
              className="w-full rounded-lg border border-[#ffd700]/40 py-2 text-xs font-bold text-[#ffd700] disabled:opacity-50" data-testid="button-song-more">
              {loading ? 'Loading' : 'Load more'}</button></li>
          )}
        </ul>
      )}
    </div>
  );
}
