import { useSyncExternalStore } from 'react';
import { Star } from 'lucide-react';
import { useMediaUrl } from './media';
import { getAppLogoId, subscribeToAppLogo } from './logo-store';

export interface BrandLogoProps {
  size?: number;
  className?: string;
}

export function BrandLogo({ size = 16, className }: BrandLogoProps) {
  const logoId = useSyncExternalStore(subscribeToAppLogo, getAppLogoId, () => null);
  const logoUrl = useMediaUrl(logoId ?? undefined);

  if (logoUrl) {
    return <img src={logoUrl} alt="" aria-hidden="true" className={className} style={{ width: size, height: size, objectFit: 'contain' }} />;
  }

  return <Star size={size} className={className} fill="currentColor" aria-hidden="true" />;
}

export default BrandLogo;