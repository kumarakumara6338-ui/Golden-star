import { useState, type FormEvent } from 'react';
import { ArrowLeft, ArrowRight, Star } from 'lucide-react';
import './pro.css';

type AuthScreenProps = {
  onPhoneVerified: (phone: string) => Promise<void> | void;
  onEmailSignup: (name: string, email: string, password: string) => Promise<void> | void;
  onEmailLogin: (email: string, password: string) => Promise<void> | void;
  error: string | null;
};

type Mode = 'login' | 'phone' | 'signup';

export default function AuthScreen({ onPhoneVerified, onEmailSignup, onEmailLogin, error }: AuthScreenProps) {
  const [mode, setMode] = useState<Mode>('phone');
  const [phoneStep, setPhoneStep] = useState<'number' | 'code'>('number');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [pending, setPending] = useState(false);
  const [localError, setLocalError] = useState('');

  const switchMode = (next: Mode) => {
    if (pending) return;
    setMode(next);
    setLocalError('');
  };

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLocalError('');
    if (pending) return;
    if (mode === 'phone') {
      if (phoneStep === 'number') {
        const digits = phone.replace(/\D/g, '');
        if (!/^\+?[\d\s().-]+$/.test(phone.trim()) || digits.length < 10 || digits.length > 15) {
          setLocalError('Enter a valid phone number with 10 to 15 digits.');
          return;
        }
        setPhoneStep('code');
        setCode('');
        return;
      }
      if (code.trim() !== '123456') {
        setLocalError('That code is not correct. Use 123456 for this preview.');
        return;
      }
    } else {
      if (mode === 'signup' && !name.trim()) {
        setLocalError('Please enter your name.');
        return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
        setLocalError('Enter a valid email address.');
        return;
      }
      if (password.length < 8) {
        setLocalError('Password must be at least 8 characters.');
        return;
      }
    }
    setPending(true);
    try {
      if (mode === 'phone') await onPhoneVerified(phone.trim());
      else if (mode === 'signup') await onEmailSignup(name.trim(), email.trim().toLowerCase(), password);
      else await onEmailLogin(email.trim().toLowerCase(), password);
    } catch (cause) {
      setLocalError(cause instanceof Error ? cause.message : 'Something went wrong. Please try again.');
    } finally {
      setPending(false);
    }
  }

  return (
    <main className="gs-pro gs-auth">
      <section className="gs-auth-stage" aria-label="Golden Star Pro">
        <div className="gs-brand"><span className="gs-brand-icon"><Star size={16} fill="currentColor" /></span> Golden Star Pro</div>
        <Star className="gs-auth-orbit-star" strokeWidth={.5} fill="currentColor" aria-hidden="true" />
        <div className="gs-auth-stage-copy">
          <p className="gs-kicker">A place for your people</p>
          <h1>Stay for<br />the <span>moment.</span></h1>
          <p>Stories, conversations, and the people who make your after-hours worth sharing.</p>
        </div>
        <div className="gs-auth-stage-foot"><span>Golden Star Pro / Your inner circle</span><span>Est. after dark</span></div>
      </section>

      <section className="gs-auth-side" aria-label="Sign in to Golden Star Pro">
        <div className="gs-auth-card">
          <div className="gs-auth-intro">
            <p className="gs-kicker">Welcome in</p>
            <h2>{mode === 'signup' ? 'Make it yours.' : phoneStep === 'code' && mode === 'phone' ? 'One last step.' : 'Good to see you.'}</h2>
            <p>{mode === 'signup' ? 'Create your space in the circle.' : phoneStep === 'code' && mode === 'phone' ? 'Enter the preview code to continue.' : 'Pick up right where the night left off.'}</p>
          </div>
          <div className="gs-auth-tabs" role="tablist" aria-label="Sign in method">
            <button type="button" role="tab" aria-selected={mode === 'login'} disabled={pending} onClick={() => switchMode('login')} data-testid="button-email-login-tab">Email login</button>
            <button type="button" role="tab" aria-selected={mode === 'phone'} disabled={pending} onClick={() => switchMode('phone')} data-testid="button-phone-tab">Phone</button>
            <button type="button" role="tab" aria-selected={mode === 'signup'} disabled={pending} onClick={() => switchMode('signup')} data-testid="button-signup-tab">Sign up</button>
          </div>
          <form className="gs-auth-form" onSubmit={submit} noValidate>
            {mode === 'phone' ? phoneStep === 'number' ? (
              <>
                <label className="gs-field">Phone number
                  <input type="tel" autoComplete="tel" inputMode="tel" placeholder="+91 98765 43210" value={phone} onChange={event => setPhone(event.target.value)} disabled={pending} data-testid="input-phone" />
                </label>
                <button className="gs-primary" type="submit" disabled={pending} data-testid="button-continue-phone">Continue with phone <ArrowRight size={16} /></button>
                <p className="gs-auth-note"><strong>Preview only.</strong> No SMS is sent. Continue to enter the mock verification code.</p>
              </>
            ) : (
              <>
                <button type="button" className="gs-quiet" onClick={() => { setPhoneStep('number'); setLocalError(''); }} disabled={pending} data-testid="button-edit-phone"><ArrowLeft size={15} /> Edit {phone}</button>
                <label className="gs-field">Verification code
                  <input className="gs-auth-code" type="text" inputMode="numeric" autoComplete="one-time-code" maxLength={6} placeholder="······" value={code} onChange={event => setCode(event.target.value.replace(/\D/g, '').slice(0, 6))} disabled={pending} data-testid="input-otp-code" />
                </label>
                <button className="gs-primary" type="submit" disabled={pending || code.length !== 6} data-testid="button-verify-phone">{pending ? 'Verifying…' : 'Verify & continue'} <ArrowRight size={16} /></button>
                <p className="gs-auth-note"><strong>Preview code: 123456.</strong> No SMS was sent to {phone}. Enter the code above to verify.</p>
              </>
            ) : (
              <>
                {mode === 'signup' && <label className="gs-field">Your name
                  <input type="text" autoComplete="name" maxLength={80} placeholder="What should we call you?" value={name} onChange={event => setName(event.target.value)} disabled={pending} data-testid="input-signup-name" />
                </label>}
                <label className="gs-field">Email address
                  <input type="email" autoComplete="email" placeholder="you@example.com" value={email} onChange={event => setEmail(event.target.value)} disabled={pending} data-testid="input-auth-email" />
                </label>
                <label className="gs-field">Password
                  <input type="password" autoComplete={mode === 'signup' ? 'new-password' : 'current-password'} minLength={8} placeholder={mode === 'signup' ? 'At least 8 characters' : 'Your password'} value={password} onChange={event => setPassword(event.target.value)} disabled={pending} data-testid="input-auth-password" />
                </label>
                <button className="gs-primary" type="submit" disabled={pending} data-testid="button-submit-auth">{pending ? 'Just a moment…' : mode === 'signup' ? 'Create account' : 'Log in'} <ArrowRight size={16} /></button>
              </>
            )}
            {(localError || error) && <p className="gs-auth-error" role="alert" data-testid="status-auth-error">{localError || error}</p>}
          </form>
        </div>
        <p className="gs-auth-end">Local preview: accounts stay in this browser. OTP does not send SMS, and chats do not reach other people.</p>
      </section>
    </main>
  );
}