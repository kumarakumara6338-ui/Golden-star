import { lazy, Suspense, useEffect, useRef, useState, type FormEvent } from 'react';
import type { Session } from '@supabase/supabase-js';
import { deleteUser as deleteFirebaseUser, onAuthStateChanged, signOut as signOutFirebase } from 'firebase/auth';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Heart, Home, Search, Clapperboard, UserRound, Bookmark, MessageCircle, Send, Plus, Volume2, VolumeX, ChevronLeft, ChevronRight, X, Star, Play, Pause, Trash2, Settings, Camera, ImagePlus, Phone, Video, PhoneOff, Menu, Music2, Smile } from 'lucide-react';
import { useLocation, Router as WouterRouter } from 'wouter';
import { languages, translate, type Language, type Key } from './i18n';
import { removeMedia, saveMedia, useMediaUrl } from './media';
import { deleteLocalAccount, getBlockedUsers, getPreferences, logout, setBlockedUsers, setPreferences } from './account';
import { type ChatMessage, type CurrentUser, type Preferences } from './pro-types';
import RealAuthScreen from './RealAuthScreen';
import { supabase, liveClient } from './live/supabase';
import { useLiveDirectory } from './live/useLiveDirectory';
import SettingsPage from './SettingsPage';
import ChatPage from './ChatPage';
import { EmojiGrid, SongLibrary, SongPicker, type SongTitle } from './MusicExtras';
import YouTubeSearch from './YouTubeSearch';
import type { YouTubeVideo } from './youtube';
import ReelsExperience from './ReelsExperience';
import PrivateHelper from './PrivateHelper';
import './private-helper.css';
import { deleteLocalSocialUser, useSocial } from './social';
import { FollowButton, SocialProfileDialog } from './SocialFeatures';
import { clearDemoUser, deleteDemoUser, readDemoUser, saveDemoUser, updateDemoUserName } from './demo-auth';
import { firebaseUserToCurrentUser, getFirebaseAuth } from './firebase-auth';
import { updateAuthenticatedName } from './auth-tokens';
import BrandLogo from './BrandLogo';
import { deleteAllOwnReels } from './reel-store';

const queryClient = new QueryClient();
const LiveSession = lazy(() => import('./live/LiveSession'));
const DemoLiveSession = lazy(() => import('./live/DemoLiveSession'));
let signedInUserId: string | null = null;
type Surface = 'home' | 'search' | 'reels' | 'likes' | 'chat' | 'profile' | 'settings' | 'songs' | 'music' | 'saved';
type Post = { id: number; creator: string; handle: string; initials: string; image: string; location: string; caption: string; likes: number; comments: number; created?: number; own?: boolean; mediaId?: string; mediaType?: 'image'|'video'; song?: SongTitle };
type Comment = { id: number; text: string };
type Profile = { name: string; handle: string; bio: string; photoId?: string };
type Data = { profile: Profile; userPosts: Post[]; liked: number[]; saved: number[]; reelLikes: number[]; comments: Record<string, Comment[]>; viewed: number[]; messages: Record<string, ChatMessage[]> };
const defaultData: Data = {
  profile: { name: 'Yara Sen', handle: '@yarasen', bio: 'Collecting the scenes between the scenes. South India / everywhere after 10pm.' },
  userPosts: [], liked: [2], saved: [1], reelLikes: [], comments: {}, viewed: [], messages: {},
};
const storageKey = 'golden-star-v1';
function loadData(user: CurrentUser): Data {
  try {
    const scopedKey = `${storageKey}:${user.id}`;
    const raw = localStorage.getItem(scopedKey);
    const parsed = JSON.parse(raw || 'null');
    if (parsed && Array.isArray(parsed.userPosts) && Array.isArray(parsed.liked) && parsed.profile?.name && parsed.comments && Array.isArray(parsed.viewed)) {
      return { ...defaultData, ...parsed, messages: parsed.messages && typeof parsed.messages === 'object' ? parsed.messages : {} };
    }
  } catch { /* An unavailable or invalid browser store starts a fresh local session. */ }
  return { ...defaultData, profile: { ...defaultData.profile, name: user.name, handle: `@${user.email?.split('@')[0] || user.phone || 'goldenstar'}` } };
}
function illustration(label: string, seed: number) {
  const palette = [['#f9dd63','#8a6515','#281705'],['#e7b52e','#572f16','#110d0a'],['#ffd700','#9e3e1c','#24130c'],['#c89a25','#241c10','#070707']][seed % 4];
  const safeLabel = label.replace(/[<>&"']/g, '').slice(0, 38);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 1100"><defs><linearGradient id="bg" x2="1" y2="1"><stop stop-color="${palette[2]}"/><stop offset=".52" stop-color="${palette[1]}"/><stop offset="1" stop-color="${palette[0]}"/></linearGradient><radialGradient id="glow" cx=".78" cy=".18" r=".72"><stop stop-color="#fff3ad" stop-opacity=".92"/><stop offset=".35" stop-color="${palette[0]}" stop-opacity=".28"/><stop offset="1" stop-color="${palette[0]}" stop-opacity="0"/></radialGradient><filter id="blur"><feGaussianBlur stdDeviation="34"/></filter></defs><rect width="900" height="1100" fill="url(#bg)"/><circle cx="730" cy="180" r="250" fill="url(#glow)" filter="url(#blur)"/><circle cx="225" cy="820" r="230" fill="${palette[0]}" opacity=".2" filter="url(#blur)"/><path d="M-80 800 C150 620 250 1060 520 760 S850 510 980 660 L980 1160 L-80 1160Z" fill="#080706" opacity=".62"/><path d="M-50 640 C150 490 350 710 570 490 S820 250 980 330" fill="none" stroke="#fff0a0" stroke-opacity=".26" stroke-width="3"/><g fill="#ffe99a" opacity=".68"><circle cx="140" cy="145" r="3"/><circle cx="655" cy="410" r="3"/><circle cx="792" cy="290" r="2"/><circle cx="744" cy="720" r="2"/></g><text x="58" y="1000" fill="#fff5c5" fill-opacity=".82" font-family="Arial,sans-serif" font-size="24" letter-spacing="4">${safeLabel.toUpperCase()}</text><text x="58" y="1042" fill="#fff5c5" fill-opacity=".46" font-family="Arial,sans-serif" font-size="13" letter-spacing="3">GOLDEN STAR / ${String(seed).padStart(2,'0')}</text></svg>`;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}
const portraits = [31,32,33,34,35,36,37].map((seed) => illustration('GOLDEN STAR', seed));
const storyNames = ['You','Mira','Kiran','Noor','Ar','Isha','Rey'];
const seededPosts: Post[] = [
  { id: 1, creator: 'Mira Rao', handle: '@mirarao.film', initials: 'MR', image: illustration('MIRA IN THE WILD',11), location: 'Bengaluru, KA', caption: 'The city was still awake when the final scene found its light.', likes: 1847, comments: 0 },
  { id: 2, creator: 'Arav K', handle: '@arav.afterdark', initials: 'AK', image: illustration('THE LIVE CUT',12), location: 'Live at Studio 7', caption: 'One take. No safety net. Thank you for staying up with us.', likes: 928, comments: 0 },
  { id: 3, creator: 'Nia / The Cut', handle: '@niathecut', initials: 'NT', image: illustration('AFTER HOURS',13), location: 'Chennai, TN', caption: 'A little gold goes a long way after midnight.', likes: 3210, comments: 0 },
];
const exploreItems = ['Mira in the wild','Behind the frame','After-hours edit','The live cut','New faces','Movement study','City after dark','Side B','Details matter'].map((label, index) => ({ label, image: illustration(label,90 + index), postId: seededPosts[index % 3].id }));
const reelData = [
  { creator: 'Blender Foundation', initials: 'BF', title: 'Sintel — trailer', description: 'Sintel © Blender Foundation, CC BY 3.0.', image: illustration('SINTEL',61), video: `${import.meta.env.BASE_URL}reels/sintel.webm`, likes: 842 },
  { creator: 'Blender Foundation', initials: 'BF', title: 'Big Buck Bunny — trailer', description: 'Big Buck Bunny © Blender Foundation, CC BY 3.0.', image: illustration('BIG BUCK BUNNY',62), video: `${import.meta.env.BASE_URL}reels/bunny.webm`, likes: 1204 },
  { creator: 'MDN Web Docs', initials: 'MD', title: 'Flowers in motion', description: 'Flower sample video, CC0.', image: illustration('FLOWERS',63), video: `${import.meta.env.BASE_URL}reels/flower.webm`, likes: 2318 },
];
const nav: { key: Surface; icon: typeof Home; label: Key }[] = [
  { key: 'home', icon: Home, label: 'home' }, { key: 'search', icon: Search, label: 'explore' },
  { key: 'reels', icon: Clapperboard, label: 'reels' }, { key: 'likes', icon: Heart, label: 'likes' },
  { key: 'chat', icon: MessageCircle, label: 'chat' },
  { key: 'profile', icon: UserRound, label: 'profile' },
];
const contacts = ['Mira', 'Kiran', 'Noor'];
function personKey(name: string) {
  return ({ 'Mira Rao': 'Mira', 'Arav K': 'Ar' } as Record<string, string>)[name] || name;
}
const localeMap: Record<Language,string> = { English:'en', Kannada:'kn', Tamil:'ta', Telugu:'te', Malayalam:'ml', Hindi:'hi' };
function Avatar({ initials, image, size = 'sm' }: { initials: string; image?: string; size?: 'sm'|'lg' }) {
  return <span className={`avatar avatar-${size}`}>{image ? <img src={image} alt="" /> : initials}</span>;
}
function AppShell({ user, onLogout, onUserChange }: { user:CurrentUser; onLogout:()=>void; onUserChange:(user:CurrentUser)=>void }) {
  const [path, setPath] = useLocation();
  const surface: Surface = path.startsWith('/search') ? 'search' : path.startsWith('/reels') ? 'reels' : path.startsWith('/likes') ? 'likes' : path.startsWith('/chat') ? 'chat' : path.startsWith('/settings') ? 'settings' : path.startsWith('/profile') ? 'profile' : path.startsWith('/songs') ? 'songs' : path.startsWith('/music') ? 'music' : path.startsWith('/saved') ? 'saved' : 'home';
  const [language, setLanguage] = useState<Language>(() => {
    try { const stored = localStorage.getItem('golden-star-language'); return languages.find((item) => item === stored) || 'English'; } catch { return 'English'; }
  });
  const t = (key: Key, values?: Record<string,string|number>) => translate(language,key,values);
  const surfaceTitle = surface === 'home' ? t('tonight') : surface === 'settings' ? t('settings') : surface === 'songs' ? 'All Songs' : surface === 'music' ? 'All Music' : surface === 'saved' ? 'Saved' : t(nav.find(item => item.key === surface)!.label);
  const [data, setData] = useState<Data>(() => loadData(user));
  const dataRef = useRef(data);
  const [blockedUsers, setBlocked] = useState<string[]>(() => getBlockedUsers(user.id));
  const social = useSocial(user.id);
  const [viewingProfile, setViewingProfile] = useState<string | null>(null);
  const demo = user.id.startsWith('demo-phone-');
  const firebase = user.authProvider === 'firebase' || user.id.startsWith('firebase-');
  const [preferences, setPrefs] = useState<Preferences>(() => getPreferences(user.id));
  const [notice, setNotice] = useState('');
  const [storyIndex, setStoryIndex] = useState<number|null>(null);
  const [liveRoom, setLiveRoom] = useState<{ id: string; name: string; roomProof?: string } | null>(null);
  const { liveUsers } = useLiveDirectory(demo || firebase);
  const [openComments, setOpenComments] = useState<number|null>(null);
  const [heartPost, setHeartPost] = useState<number|null>(null);
  const [query, setQuery] = useState('');
  const [chatShare, setChatShare] = useState<Pick<YouTubeVideo, 'id' | 'title'> | null>(null);
  const [dialog, setDialog] = useState<'create'|'edit'|null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [emojiOpen, setEmojiOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const [selectedTile, setSelectedTile] = useState<(typeof exploreItems)[number]|null>(null);
  const [draft, setDraft] = useState<{ caption:string; location:string; image:number; song:SongTitle|null }>({ caption:'', location:'', image:0, song:null });
  const [profileDraft, setProfileDraft] = useState<Profile>(data.profile);
  const [selectedFile, setSelectedFile] = useState<File|null>(null);
  const [filePreview, setFilePreview] = useState<string|null>(null);
  const [savingMedia, setSavingMedia] = useState(false);
  const [composingMusicBusy, setComposingMusicBusy] = useState(false);
  const [call, setCall] = useState<{kind:'video'|'audio'; name:string}|null>(null);
  const photoInput = useRef<HTMLInputElement>(null);
  const galleryInput = useRef<HTMLInputElement>(null);
  const profilePhoto = useMediaUrl(data.profile.photoId);
  const posts = [...data.userPosts, ...seededPosts].map((post) => post.own ? { ...post, creator:data.profile.name, handle:data.profile.handle, initials:data.profile.name.slice(0,2).toUpperCase() } : post)
    .filter(post => post.own || !blockedUsers.some(name => personKey(name) === personKey(post.creator)));
  const visibleExploreItems = exploreItems.filter(item => posts.some(post => post.id === item.postId));
  const match = path.match(/^\/post\/(\d+)$/);
  const ownedReelMatch = path.match(/^\/reels\/own\/([a-zA-Z0-9_-]+)$/);
  const unknownPath = !['/','/search','/reels','/likes','/chat','/settings','/profile','/songs','/music','/saved','/ai'].includes(path) && !match && !/^\/reels\/[0-2]$/.test(path) && !ownedReelMatch;
  const focusedPost = match ? posts.find((post) => post.id === Number(match[1])) : null;
  const flash = (message: string) => { setNotice(message); window.setTimeout(() => setNotice((current) => current === message ? '' : current), 3500); };
  const commit = (update: (current: Data) => Data): boolean => {
    if (signedInUserId !== user.id) return false;
    const next = update(dataRef.current);
    try {
      localStorage.setItem(`${storageKey}:${user.id}`, JSON.stringify(next));
      dataRef.current = next;
      setData(next);
      return true;
    } catch { flash(t('storageError')); return false; }
  };
  useEffect(() => { document.documentElement.lang = localeMap[language]; try { localStorage.setItem('golden-star-language', language); } catch { flash(t('storageError')); } }, [language]);
  useEffect(() => {
    const title = surface === 'home' ? 'Golden Star Pro' : `${surfaceTitle} · Golden Star Pro`;
    const description = `${t('tonight')} — ${t('topStories')}, ${t('explore')}, ${t('reels')}.`;
    document.title = title;
    document.querySelector('meta[name="description"]')?.setAttribute('content', description);
    document.querySelector('meta[property="og:description"]')?.setAttribute('content', description);
  }, [surface, language]);
  useEffect(() => { setMenuOpen(false); }, [path]);
  useEffect(() => {
    if (!menuOpen) return;
    const dismiss = (event: PointerEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) setMenuOpen(false);
    };
    const dismissOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setMenuOpen(false);
    };
    document.addEventListener('pointerdown', dismiss);
    document.addEventListener('keydown', dismissOnEscape);
    return () => { document.removeEventListener('pointerdown', dismiss); document.removeEventListener('keydown', dismissOnEscape); };
  }, [menuOpen]);
  useEffect(() => {
    if (storyIndex === null && !dialog && !selectedTile && !call && !emojiOpen) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { setStoryIndex(null); setDialog(null); setSelectedTile(null); setCall(null); setEmojiOpen(false); }
      if (storyIndex !== null && event.key === 'ArrowRight') advanceStory(1);
      if (storyIndex !== null && event.key === 'ArrowLeft') advanceStory(-1);
    };
    window.addEventListener('keydown',handler);
    return () => window.removeEventListener('keydown',handler);
  }, [storyIndex,dialog,selectedTile,call,emojiOpen]);
  useEffect(() => {
    if (!selectedFile) { setFilePreview(null); return; }
    const url = URL.createObjectURL(selectedFile);
    setFilePreview(url);
    return () => URL.revokeObjectURL(url);
  }, [selectedFile]);
  useEffect(() => { if (dialog !== 'create') setSelectedFile(null); }, [dialog]);
  useEffect(() => {
    const pending = Object.entries(data.messages).flatMap(([contact, list]) =>
      list.filter(message => message.status !== 'seen').map(message => ({ contact, message })));
    const timers = pending.map(({ contact, message }) => window.setTimeout(() => {
      if (signedInUserId !== user.id) return;
      commit(current => ({
        ...current,
        messages: {
          ...current.messages,
          [contact]: (current.messages[contact] || []).map(item =>
            item.id === message.id && item.status === message.status
              ? { ...item, status: message.status === 'delivered' ? 'seen' as const : 'delivered' as const }
              : item),
        },
      }));
    }, message.status === 'delivered' ? 1800 : 1100));
    return () => timers.forEach(clearTimeout);
  }, [data.messages, user.id]);
  function go(key: Surface) { setMenuOpen(false); setPath(key === 'home' ? '/' : `/${key}`); window.scrollTo(0,0); }
  function startPostWithSong(song: SongTitle) {
    setDraft(current => ({ ...current, song }));
    setMenuOpen(false);
    setDialog('create');
  }
  function addEmojiToPost(emoji: string) {
    setDraft(current => {
      const separator = current.caption && !/\s$/.test(current.caption) ? ' ' : '';
      return { ...current, caption: `${current.caption}${separator}${emoji}`.slice(0, 800) };
    });
    setEmojiOpen(false);
    setMenuOpen(false);
    setDialog('create');
  }
  function advanceStory(direction: number) {
    if (storyIndex === null) return;
    let next = (storyIndex + direction + storyNames.length) % storyNames.length;
    for (let count = 0; count < storyNames.length && next !== 0 && isBlocked(storyNames[next]); count++) {
      next = (next + direction + storyNames.length) % storyNames.length;
    }
    setStoryIndex(next);
    commit((current) => ({ ...current, viewed: [...new Set([...current.viewed,next])] }));
  }
  function openStory(index: number) {
    setStoryIndex(index);
    commit((current) => ({ ...current, viewed: [...new Set([...current.viewed,index])] }));
  }
  function like(id: number, force = false) {
    commit((current) => ({ ...current, liked: current.liked.includes(id) ? (force ? current.liked : current.liked.filter((value) => value !== id)) : [...current.liked,id] }));
    if (force) { setHeartPost(id); window.setTimeout(() => setHeartPost((value) => value === id ? null : value), 850); }
  }
  function save(id: number) {
    const currentlySaved = data.saved.includes(id);
    commit((current) => ({ ...current, saved: currentlySaved ? current.saved.filter((value) => value !== id) : [...current.saved,id] }));
    flash(t(currentlySaved ? 'removed' : 'saved'));
  }
  function addComment(id: number, text: string) {
    const value = text.trim();
    if (!value) return;
    commit((current) => ({ ...current, comments: { ...current.comments, [id]: [...(current.comments[id] || []), { id: Date.now(), text:value }] } }));
  }
  async function share(url: string, title: string) {
    try {
      if (navigator.share) { await navigator.share({ title, url }); flash(t('shared')); return true; }
      if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
      await navigator.clipboard.writeText(url);
      flash(t('copied'));
      return true;
    } catch (error) {
      if ((error as Error).name !== 'AbortError') flash(t('shareFailed'));
      return false;
    }
  }
  const sharePost = async (post: Post) => {
    const shared = await share(new URL(`${import.meta.env.BASE_URL}post/${post.id}`,window.location.origin).href,post.caption);
    if (shared && post.own) window.setTimeout(() => flash(t('linkOnly')), 1200);
  };
  async function changePhoto(file?: File) {
    if (!file) return;
    if (!file.type.startsWith('image/') || file.size > 10 * 1024 * 1024) { flash(t('photoLimit')); return; }
    setSavingMedia(true);
    try {
      const id = await saveMedia(file);
      const previous = data.profile.photoId;
      if (!commit(current => ({ ...current, profile: { ...current.profile, photoId:id } }))) { await removeMedia(id); return; }
      if (previous) void removeMedia(previous).catch(() => {});
      flash(t('photoSaved'));
    } catch { flash(t('mediaSaveError')); }
    finally { setSavingMedia(false); }
  }
  function selectGalleryFile(file?: File) {
    if (!file) return;
    if (!(file.type.startsWith('image/') || file.type.startsWith('video/')) || file.size > 25 * 1024 * 1024) { flash(t('mediaLimit')); return; }
    setSelectedFile(file);
  }
  async function createPost(event: FormEvent) {
    event.preventDefault();
    if (!draft.caption.trim() || savingMedia || composingMusicBusy) { flash(t('required')); return; }
    setSavingMedia(true);
    try {
      const mediaId = selectedFile ? await saveMedia(selectedFile) : undefined;
      const now = Date.now();
      const post: Post = { id:now, own:true, creator:data.profile.name, handle:data.profile.handle, initials:data.profile.name.slice(0,2).toUpperCase(), image:exploreItems[draft.image].image, location:draft.location.trim(), caption:draft.caption.trim(), likes:0, comments:0, created:now, mediaId, mediaType:selectedFile?.type.startsWith('video/') ? 'video' : 'image', ...(draft.song ? { song:draft.song } : {}) };
      if (!commit((current) => ({ ...current, userPosts:[post,...current.userPosts] }))) { if (mediaId) await removeMedia(mediaId); return; }
      setDraft({ caption:'',location:'',image:0,song:null }); setSelectedFile(null); setDialog(null); go('home'); flash(t('postCreated'));
    } catch { flash(t('mediaSaveError')); }
    finally { setSavingMedia(false); }
  }
  async function editProfile(event: FormEvent) {
    event.preventDefault();
    const name = profileDraft.name.trim(), handle = profileDraft.handle.trim().replace(/^@*/,'@'), bio = profileDraft.bio.trim();
    if (!name || handle.length < 2) { flash(t('required')); return; }
    if (commit((current) => ({ ...current, profile:{ ...current.profile, name, handle, bio } }))) {
      try {
        if (demo) updateDemoUserName(user.id, name);
        else await updateAuthenticatedName(name);
        onUserChange({ ...user, name });
      } catch { flash('Profile saved here, but account name could not sync.'); }
      setDialog(null); flash(t('profileUpdated'));
    }
  }
  function deletePost(id: number) {
    if (!window.confirm(t('deleteConfirm'))) return;
    const mediaId = data.userPosts.find(post => post.id === id)?.mediaId;
    const removed = commit((current) => ({ ...current, userPosts:current.userPosts.filter((post) => post.id !== id), liked:current.liked.filter((value) => value !== id), saved:current.saved.filter((value) => value !== id) }));
    if (!removed) return;
    if (mediaId) void removeMedia(mediaId).catch(() => {});
    if (focusedPost) go('profile');
    flash(t('deleted'));
  }
  function isBlocked(name: string) { return blockedUsers.some(blocked => personKey(blocked) === personKey(name)); }
  function blockUser(name: string) {
    if (isBlocked(name)) return;
    try {
      const next = [...blockedUsers, personKey(name)];
      setBlockedUsers(user.id, next);
      setBlocked(next);
      if (call?.name === name) setCall(null);
      if (storyIndex !== null && personKey(storyNames[storyIndex]) === personKey(name)) setStoryIndex(null);
      flash('Blocked in this browser. Cross-device post access is not enforced in the demo.');
    } catch { flash(t('storageError')); }
  }
  function unblockUser(name: string) {
    if (!isBlocked(name)) return;
    try {
      const next = blockedUsers.filter(item => personKey(item) !== personKey(name));
      setBlockedUsers(user.id, next);
      setBlocked(next);
      flash('User Unblocked');
    } catch { flash(t('storageError')); }
  }
  function sendChat(contact: string, text: string, replyId?: number) {
    if (isBlocked(contact)) { flash('Unblock this user before messaging.'); return; }
    const value = text.trim();
    if (!value) return;
    const reply = dataRef.current.messages[contact]?.find(item => item.id === replyId);
    const message: ChatMessage = { id: Date.now() + Math.random(), text: value, createdAt: Date.now(), status: 'sent', ...(reply ? { replyTo: { id:reply.id, text:reply.text || reply.attachmentName || 'Attachment' } } : {}) };
    commit(current => ({ ...current, messages: { ...current.messages, [contact]: [...(current.messages[contact] || []), message] } }));
  }
  async function attachChat(contact: string, file: File, replyId?: number) {
    if (isBlocked(contact)) { flash('Unblock this user before messaging.'); return; }
    if (file.size > 25 * 1024 * 1024 || !file.size) { flash('Choose a file under 25 MB.'); return; }
    try {
      const id = await saveMedia(file);
      if (signedInUserId !== user.id || isBlocked(contact)) { await removeMedia(id); return; }
      const reply = dataRef.current.messages[contact]?.find(item => item.id === replyId);
      const message: ChatMessage = { id:Date.now() + Math.random(), text:'', createdAt:Date.now(), status:'sent', attachmentId:id, attachmentName:file.name, attachmentType:file.type, ...(reply ? { replyTo: { id:reply.id, text:reply.text || reply.attachmentName || 'Attachment' } } : {}) };
      if (!commit(current => ({ ...current, messages: { ...current.messages, [contact]: [...(current.messages[contact] || []), message] } }))) await removeMedia(id);
    } catch { flash(t('mediaSaveError')); }
  }
  function deleteChatMessages(contact: string, ids: number[]) {
    if (!ids.length || !window.confirm(`Delete ${ids.length} message${ids.length === 1 ? '' : 's'} from this browser? This cannot be undone.`)) return;
    const deleted = (dataRef.current.messages[contact] || []).filter(message => ids.includes(message.id));
    if (!commit(current => ({ ...current, messages: { ...current.messages, [contact]: (current.messages[contact] || []).filter(message => !ids.includes(message.id)) } }))) return;
    const stillUsed = new Set(Object.values(dataRef.current.messages).flat().map(message => message.attachmentId));
    for (const id of new Set(deleted.map(message => message.attachmentId).filter((id):id is string=>!!id))) {
      if (!stillUsed.has(id)) void removeMedia(id).catch(() => flash('Could not remove a local attachment.'));
    }
    flash('Message deleted');
  }
  function forwardChat(source: string, ids: number[], target: string) {
    if (isBlocked(target)) { flash('Unblock this user before messaging.'); return; }
    const selected = (dataRef.current.messages[source] || []).filter(message => ids.includes(message.id));
    if (!selected.length) return;
    const forwarded = selected.map((message,index):ChatMessage => ({ ...message, id:Date.now() + index + Math.random(), createdAt:Date.now(), status:'sent', forwarded:true, replyTo:undefined }));
    if (commit(current => ({ ...current, messages: { ...current.messages, [target]: [...(current.messages[target] || []), ...forwarded] } }))) flash('Forwarded');
  }
  function updatePreferences(next: Preferences) {
    try { setPreferences(user.id,next); setPrefs(next); }
    catch { flash(t('storageError')); }
  }
  async function updateName(name: string) {
    try {
      if (demo) updateDemoUserName(user.id, name.trim());
      else await updateAuthenticatedName(name);
      if (commit(current => ({ ...current, profile:{ ...current.profile, name } }))) {
        onUserChange({ ...user, name });
        flash('Name updated');
      }
    } catch { flash('Could not update your account name.'); }
  }
  function clearChats() {
    const ids = new Set(Object.values(dataRef.current.messages).flat().map(message => message.attachmentId).filter((id):id is string=>!!id));
    if (commit(current => ({ ...current, messages:{} }))) {
      for (const id of ids) void removeMedia(id).catch(() => flash('Could not remove a local attachment.'));
      flash('Chats cleared');
    }
  }
  async function clearCache() {
    try {
      queryClient.clear();
      for (const key of Object.keys(sessionStorage)) if (key.startsWith('golden-star')) sessionStorage.removeItem(key);
      if ('caches' in window) for (const key of await caches.keys()) if (key.startsWith('golden-star')) await caches.delete(key);
      flash('Temporary app cache cleared. Saved posts and chats are kept.');
    } catch { flash('Could not clear temporary cache in this browser.'); }
  }
  async function deleteAccount() {
    const ids = new Set([
      dataRef.current.profile.photoId,
      ...dataRef.current.userPosts.map(post => post.mediaId),
      ...Object.values(dataRef.current.messages).flat().map(message => message.attachmentId),
    ].filter((id):id is string=>!!id));
    try {
      if (firebase) {
        const firebaseIdentity = getFirebaseAuth()?.currentUser;
        if (!firebaseIdentity) throw new Error('Sign in again before deleting your Firebase account.');
        await deleteFirebaseUser(firebaseIdentity);
      } else if (!demo) {
        const { error: cause } = await liveClient().rpc('delete_my_account');
        if (cause) throw cause;
      } else {
        deleteDemoUser(user.id);
      }
      await deleteAllOwnReels(user.id);
      deleteLocalSocialUser(user.id);
      for (const key of Object.keys(localStorage)) {
        if ((key.startsWith('golden-star') || key.startsWith('gs-')) && key.includes(user.id)) localStorage.removeItem(key);
      }
      deleteLocalAccount(user.id);
      for (const id of ids) void removeMedia(id).catch(() => flash('Could not remove local media.'));
      setPath('/');
      onLogout();
    } catch (cause) { flash(firebase ? 'Could not delete your Firebase account or local data. Sign in again and retry.' : cause instanceof Error ? cause.message : 'Could not delete your account.'); }
  }
  const card = (post: Post, index: number) => <PostCard key={post.id} post={post} index={index} t={t} language={language} liked={data.liked.includes(post.id)} saved={data.saved.includes(post.id)} heart={heartPost === post.id} commentList={data.comments[post.id] || []} commentsOpen={openComments === post.id} onLike={() => like(post.id)} onDouble={() => like(post.id,true)} onSave={() => save(post.id)} onComments={() => setOpenComments(openComments === post.id ? null : post.id)} onComment={(text) => addComment(post.id,text)} onShare={() => sharePost(post)} onDelete={() => deletePost(post.id)} onProfile={() => post.own ? go('profile') : setViewingProfile(post.creator)} following={social.isFollowing(personKey(post.creator))} onFollow={() => social.toggleFollow(personKey(post.creator))} />;
  return <div className={`app-shell ${preferences.darkMode ? '' : 'app-light'} app-theme-${preferences.theme}`}><input ref={photoInput} className="sr-only" type="file" accept="image/*" aria-label={t('changePhoto')} onChange={event => { void changePhoto(event.target.files?.[0]); event.target.value=''; }} /><div className="app-layout">
    <aside className="desktop-rail" aria-label={t('home')}><div className="brand"><span className="brand-mark"><BrandLogo size={15} /></span> Golden Star Pro</div><div className="brand-note">{t('tagline')}</div>
      <nav className="nav-stack">{nav.map(({ key,icon:Icon,label }) => <NavButton key={key} Icon={Icon} active={surface === key} label={t(label)} onClick={() => go(key)} />)}</nav>
      <div className="rail-foot"><button className="follow-button" onClick={() => setDialog('create')}><Plus size={15} /> {t('createPost')}</button><div className="rail-user"><Avatar initials={data.profile.name.slice(0,2)} image={profilePhoto || illustration('GOLDEN STAR',99)} /><div><strong>{data.profile.name}</strong><small>{data.profile.handle}</small></div></div></div>
    </aside>
    <main className="main-column">{surface !== 'settings' && <header className="topbar"><div className="mobile-brand"><span className="brand-mark"><BrandLogo size={12} /></span> Golden Star Pro</div><div className="topbar-title">{surfaceTitle}</div><div className="topbar-actions">
      <select className="language-select" aria-label={t('chooseLanguage')} value={language} onChange={(event) => setLanguage(event.target.value as Language)}>{languages.map((name,index) => <option value={name} key={name}>{['English','ಕನ್ನಡ','தமிழ்','తెలుగు','മലയാളം','हिन्दी'][index]}</option>)}</select>
      <button className="icon-button" title={t('createPost')} aria-label={t('createPost')} onClick={() => setDialog('create')}><Plus size={19} /></button>
      <button className="icon-button" aria-label={t('profile')} onClick={() => go('profile')}><Avatar initials={data.profile.name.slice(0,2)} image={profilePhoto || undefined} /></button>
      <div className="header-menu-anchor" ref={menuRef}>
        <button type="button" className="icon-button" aria-label="Open menu" title="Menu" aria-haspopup="menu" aria-expanded={menuOpen} onClick={() => setMenuOpen(open => !open)}><Menu size={20} /></button>
        {menuOpen && <div className="header-menu" role="menu" aria-label="More options">
          <button type="button" role="menuitem" onClick={() => go('songs')}><Music2 size={17} />All Songs</button>
          <button type="button" role="menuitem" onClick={() => go('music')}><Play size={17} />All Music</button>
          <button type="button" role="menuitem" onClick={() => { setMenuOpen(false); setEmojiOpen(true); }}><Smile size={17} />Emoji Picker</button>
          <button type="button" role="menuitem" onClick={() => go('saved')}><Bookmark size={17} />Saved</button>
          <button type="button" role="menuitem" onClick={() => go('settings')}><Settings size={17} />Settings</button>
        </div>}
      </div>
    </div></header>}
    <div className="content">{unknownPath ? <div className="empty-state"><p>{t('pageNotFound')}</p><button className="follow-button" onClick={() => go('home')}>{t('backHome')}</button></div> : match ? focusedPost ? <div className="feed"><button className="text-button" onClick={() => go('home')}>{t('backHome')}</button>{card(focusedPost,0)}<p className="local-note">{t('linkOnly')}</p></div> : <div className="empty-state"><p>{t('notFound')}</p><button className="follow-button" onClick={() => go('home')}>{t('backHome')}</button></div> :
      surface === 'home' ? <><section aria-label={t('topStories')}><div className="feed-intro"><div><div className="eyebrow">{t('innerCircle')}</div><h1 className="page-heading">{t('topStories')}</h1><p>{t('fresh')}</p></div><span className="sort-label">{t('liveNow')}</span></div><div className="story-strip">
        {liveUsers.filter(live => live.user_id === user.id || !isBlocked(live.display_name || 'Creator')).map(live => <div key={live.user_id} className="flex shrink-0 flex-col items-center gap-1"><button className="story story-live" onClick={() => setLiveRoom({ id: live.user_id, name: live.display_name || 'Creator', roomProof: live.roomProof })} aria-label={live.user_id === user.id ? 'Return to your live broadcast' : `Watch ${live.display_name || 'creator'} live`} data-testid={`story-live-${live.user_id}`}><span className="story-ring"><Avatar initials={(live.display_name || 'GS').slice(0,2).toUpperCase()} /></span><span className="story-name">{live.user_id === user.id ? 'You' : live.display_name || 'Creator'}</span><span className="story-live-label">LIVE</span></button>{live.user_id !== user.id && <><FollowButton name={personKey(live.display_name || 'Creator')} following={social.isFollowing(personKey(live.display_name || 'Creator'))} onToggle={social.toggleFollow} /><button className="text-xs text-[#cbb874]" aria-label={`View ${live.display_name || 'Creator'} profile`} onClick={() => setViewingProfile(live.display_name || 'Creator')}>Profile</button></>}</div>)}
        {!liveUsers.some(live => live.user_id === user.id) && <button className="story story-add" onClick={() => setLiveRoom({ id: user.id, name: data.profile.name })} aria-label="Go live from your phone" data-testid="button-go-live"><span className="story-ring"><Video size={24} /></span><span className="story-name">Go Live</span></button>}
        {storyNames.map((name,index) => index !== 0 && isBlocked(name) ? null : <div key={name} className="flex shrink-0 flex-col items-center gap-1"><button className={`story ${data.viewed.includes(index) ? 'viewed' : ''}`} onClick={() => openStory(index)} aria-label={t('openStory',{ name:index === 0 ? t('you') : name })}><span className="story-ring"><Avatar initials={name.slice(0,2)} image={portraits[index]} />{index === 0 && <span className="story-plus"><Plus size={13} /></span>}</span><span className="story-name">{index === 0 ? t('you') : name}</span></button>{index !== 0 && <FollowButton name={name} following={social.isFollowing(name)} onToggle={social.toggleFollow} />}</div>)}
      </div></section><section className="feed" aria-label={t('yourFeed')}>{posts.map(card)}</section></> :
      surface === 'search' ? <>
        <div className="eyebrow">{t('find')}</div>
        <h1 className="page-heading">{t('explore')} <span>{t('afterDark')}</span></h1>
        <div className="search-panel"><Search size={18} /><input className="search-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t('searchPrompt')} aria-label={t('searchPrompt')} data-testid="input-explore-search" /></div>
        <YouTubeSearch query={query} onChat={video => { setChatShare({ id:video.id, title:video.title }); go('chat'); }} />
        {query.trim() && posts.some((post) => `${post.creator} ${post.handle} ${post.caption} ${post.location}`.toLowerCase().includes(query.toLowerCase())) && <div className="search-results section-card"><div className="eyebrow">{t('results',{query})}</div>{posts.filter((post) => `${post.creator} ${post.handle} ${post.caption} ${post.location}`.toLowerCase().includes(query.toLowerCase())).map((post) => <button className="result-row" key={post.id} onClick={() => setPath(`/post/${post.id}`)}><Avatar initials={post.initials} image={post.image} /><span><strong>{post.creator}</strong><small>{post.caption}</small></span><ChevronRight size={16} /></button>)}</div>}
        <div className="grid-heading"><h2>{t('watching')}</h2><span>{t('frames',{count:visibleExploreItems.filter((item) => item.label.toLowerCase().includes(query.toLowerCase())).length})}</span></div>
        <div className="explore-grid">{visibleExploreItems.filter((item) => item.label.toLowerCase().includes(query.toLowerCase())).map((item) => <button className="explore-tile" key={item.label} aria-label={t('openFrame',{name:item.label})} onClick={() => setSelectedTile(item)}><img src={item.image} alt="" /><span className="tile-overlay">{item.label}</span></button>)}</div>
      </> :
      surface === 'reels' ? <><div className="eyebrow">{t('vertical')}</div><h1 className="page-heading reels-heading">{t('reels')} <span>{t('inMotion')}</span></h1><ReelsExperience t={t} userId={user.id} userName={data.profile.name} onOwnProfile={() => go('profile')} isBlocked={isBlocked} blockedUsers={blockedUsers} onProfile={setViewingProfile} isFollowing={social.isFollowing} onFollow={social.toggleFollow} initialReelId={ownedReelMatch?.[1]} initialIndex={Number(path.match(/^\/reels\/([0-2])$/)?.[1] || 0)} liked={data.reelLikes} onLike={(index) => commit((current) => ({ ...current, reelLikes:current.reelLikes.includes(index) ? current.reelLikes.filter((value) => value !== index) : [...current.reelLikes,index] }))} onShare={(index) => share(new URL(`${import.meta.env.BASE_URL}reels/${index}`,window.location.origin).href,reelData[index]?.title || 'Golden Star Pro reel')} /></> :
      surface === 'likes' ? <><div className="eyebrow">{t('likes')}</div><h1 className="page-heading">{t('likedMoments')}</h1>{data.liked.some((id) => posts.some((post) => post.id === id)) ? <div className="feed top-gap">{posts.filter((post) => data.liked.includes(post.id)).map(card)}</div> : <div className="section-card empty-state top-gap"><Heart size={34} /><h2>{t('firstScene')}</h2><p>{t('likeHint')}</p></div>}</> :
      surface === 'songs' ? <><div className="eyebrow">Golden Star Pro / soundtrack</div><h1 className="page-heading">All Songs</h1><p className="music-page-note">Search a live catalog. Reel-safe tracks are uploader-declared CC0/Public domain; review each source. Posts keep the song title only.</p><SongLibrary onChoose={startPostWithSong} /></> :
      surface === 'music' ? <><div className="eyebrow">Golden Star Pro / your collection</div><h1 className="page-heading">All Music</h1><p className="music-page-note">Posts with a song attached appear here.</p>{posts.some(post => post.song) ? <div className="feed music-view-feed">{posts.filter(post => post.song).map(card)}</div> : <div className="section-card empty-state top-gap"><Music2 size={32} /><h2>No music posts yet</h2><p>Pick a song and share your first post with music.</p><button className="follow-button" onClick={() => go('songs')}>Browse songs</button></div>}</> :
      surface === 'saved' ? <><div className="eyebrow">Golden Star Pro / your collection</div><h1 className="page-heading">Saved</h1>{posts.some(post => data.saved.includes(post.id)) ? <div className="feed top-gap">{posts.filter(post => data.saved.includes(post.id)).map(card)}</div> : <div className="section-card empty-state top-gap"><Bookmark size={32} /><h2>No saved posts yet</h2><p>Use the bookmark on a post to keep it here.</p><button className="follow-button" onClick={() => go('home')}>Explore the feed</button></div>}</> :
      surface === 'chat' ? <ChatPage contacts={contacts} messages={data.messages} blockedUsers={blockedUsers} onSend={sendChat} onAttach={attachChat} onDelete={deleteChatMessages} onForward={forwardChat} onBlock={blockUser} onUnblock={unblockUser} onCall={(kind,name) => isBlocked(name) ? flash('Unblock this user before calling.') : setCall({kind,name})} onToast={flash} incomingShare={chatShare} onShareConsumed={() => setChatShare(null)} /> :
      surface === 'settings' ? <SettingsPage user={user} profile={data.profile} photoUrl={profilePhoto} blockedUsers={blockedUsers} preferences={preferences} language={language} onLanguage={setLanguage} onPreferences={updatePreferences} onNameChange={updateName} onPhotoChange={() => photoInput.current?.click()} onUnblock={unblockUser} onClearChats={clearChats} onClearCache={() => { void clearCache(); }} onLogout={() => { logout(); setPath('/'); onLogout(); }} onDelete={deleteAccount} onShare={() => { void share(new URL(import.meta.env.BASE_URL,window.location.origin).href,'Golden Star'); }} onBack={() => go('profile')} /> :
      <><div className="eyebrow">{t('yourHour')}</div><h1 className="page-heading">{t('profileNotes')}</h1>
        <section className="section-card top-gap">
          <div className="profile-hero">
            <div className="profile-photo-wrap"><Avatar initials={data.profile.name.slice(0,2)} image={profilePhoto || illustration('GOLDEN STAR',99)} size="lg" /><button type="button" className="photo-change" disabled={savingMedia} onClick={() => photoInput.current?.click()}><Camera size={14} />{t('changePhoto')}</button></div>
            <div className="profile-copy"><h2>{data.profile.name}</h2><p>{data.profile.handle}</p>{demo && <small className="text-[#bca66b]">Phone OTP test account</small>}<div className="profile-stats"><div><strong>{data.userPosts.length}</strong><span>{t('posts')}</span></div><div><strong>{data.liked.length}</strong><span>{t('likes')}</span></div><div><strong>{social.followersCount}</strong><span>Followers</span></div><div><strong>{social.following.length}</strong><span>Following</span></div></div></div>
            <div className="profile-buttons"><button type="button" className="profile-settings" aria-label={t('settings')} title={t('settings')} onClick={() => go('settings')}><Settings size={20} /></button><button type="button" className="follow-button" onClick={() => { setProfileDraft(data.profile); setDialog('edit'); }}>{t('editProfile')}</button></div>
          </div><div className="profile-bio">{data.profile.bio}</div>
        </section><p className="local-note">{t('browserNote')}</p><div className="grid-heading"><h2>{t('recent')}</h2><span>{t('frames',{count:data.userPosts.length})}</span></div>{data.userPosts.length ? <div className="explore-grid">{data.userPosts.map(post => <ProfileMediaTile key={post.id} post={post} onClick={() => setPath(`/post/${post.id}`)} label={t('goToPost')} unavailable={t('mediaUnavailable')} />)}</div> : <div className="empty-state section-card"><p>{t('noPosts')}</p><button className="follow-button" onClick={() => setDialog('create')}>{t('createPost')}</button></div>}</>
    }</div></main></div>
    <nav className="bottom-nav" aria-label={t('home')}>{nav.map(({key,icon:Icon,label}) => <NavButton key={key} Icon={Icon} active={surface === key} label={t(label)} onClick={() => go(key)} />)}</nav>
    {notice && <div className="app-toast" role="status">{notice}</div>}
    {social.storageError && <p role="alert" className="app-toast">{social.storageError}</p>}
    {viewingProfile && <SocialProfileDialog key={viewingProfile} name={viewingProfile} following={social.isFollowing(personKey(viewingProfile))} onFollow={() => social.toggleFollow(personKey(viewingProfile))} blocked={isBlocked(viewingProfile)} onBlock={() => isBlocked(viewingProfile) ? unblockUser(viewingProfile) : blockUser(viewingProfile)} onReport={reason => social.reportUser(personKey(viewingProfile), reason)} onClose={() => setViewingProfile(null)} />}
    {!liveRoom && <PrivateHelper key={user.id} />}
    {liveRoom && <div className="live-modal" role="dialog" aria-modal="true" aria-label={`${liveRoom.name} live`}><Suspense fallback={<p className="empty-state" role="status">Connecting to live video…</p>}>{demo && liveRoom.id === user.id ? <DemoLiveSession user={user} onLeave={() => setLiveRoom(null)} /> : demo ? <div className="empty-state"><p>Sign in with a real email or Firebase account to watch a shared live broadcast. Phone OTP demo accounts only support a local camera preview.</p><button className="follow-button" onClick={() => setLiveRoom(null)}>Close</button></div> : <LiveSession key={liveRoom.id} user={user} displayName={data.profile.name} hostId={liveRoom.id} hostName={liveRoom.name} roomProof={liveRoom.roomProof} onLeave={() => setLiveRoom(null)} />}</Suspense></div>}
    {storyIndex !== null && <div className="story-modal" role="dialog" aria-modal="true" aria-label={t('openStory',{name:storyIndex === 0 ? t('you') : storyNames[storyIndex]})} onClick={() => setStoryIndex(null)}><div className="story-viewer" onClick={(event) => event.stopPropagation()}><img src={portraits[storyIndex]} alt="" /><div className="story-viewer-head"><button className="font-semibold text-white" onClick={() => storyIndex === 0 ? (setStoryIndex(null), go('profile')) : setViewingProfile(storyNames[storyIndex])} aria-label={`View ${storyIndex === 0 ? 'your' : storyNames[storyIndex]} profile`}>{storyIndex === 0 ? t('you') : storyNames[storyIndex]}</button>{storyIndex !== 0 && <FollowButton name={storyNames[storyIndex]} following={social.isFollowing(storyNames[storyIndex])} onToggle={social.toggleFollow} />}<button className="close-button" aria-label={t('closeStory')} onClick={() => setStoryIndex(null)}><X size={18} /></button></div><div className="story-viewer-foot"><div className="eyebrow">Golden Star / 00{storyIndex+1}</div><h2>{t('storyTitle')}</h2><p>{t('storyNote')}</p></div><div className="story-controls"><button aria-label={t('previousStory')} onClick={() => advanceStory(-1)}><ChevronLeft /></button><button aria-label={t('nextStory')} onClick={() => advanceStory(1)}><ChevronRight /></button></div></div></div>}
    {selectedTile && <div className="story-modal" role="dialog" aria-modal="true" aria-label={selectedTile.label} onClick={() => setSelectedTile(null)}><div className="frame-dialog section-card" onClick={(event) => event.stopPropagation()}><button className="close-button modal-close" aria-label={t('close')} onClick={() => setSelectedTile(null)}><X size={18} /></button><img src={selectedTile.image} alt={selectedTile.label} /><h2>{selectedTile.label}</h2><button className="follow-button" onClick={() => { setPath(`/post/${selectedTile.postId}`); setSelectedTile(null); }}>{t('goToPost')}</button></div></div>}
    {emojiOpen && <div className="story-modal" role="dialog" aria-modal="true" aria-label="Emoji Picker" onClick={() => setEmojiOpen(false)}><div className="music-emoji-dialog section-card" onClick={event => event.stopPropagation()}><div className="dialog-head"><h2>Emoji Picker</h2><button type="button" className="close-button" aria-label="Close emoji picker" onClick={() => setEmojiOpen(false)}><X size={18} /></button></div><p>Choose an emoji to add it to a new post.</p><EmojiGrid onPick={addEmojiToPost} /></div></div>}
    {dialog && <div className="story-modal" role="dialog" aria-modal="true" aria-label={t(dialog === 'create' ? 'createPost' : 'editProfile')} onClick={() => setDialog(null)}><form className="edit-dialog section-card" onSubmit={dialog === 'create' ? createPost : editProfile} onClick={(event) => event.stopPropagation()}><div className="dialog-head"><h2>{t(dialog === 'create' ? 'createPost' : 'editProfile')}</h2><button type="button" className="close-button" aria-label={t('close')} onClick={() => setDialog(null)}><X size={18} /></button></div>{dialog === 'create' ? <>
      <label>{t('caption')}<textarea required maxLength={800} value={draft.caption} onChange={(event) => setDraft({...draft,caption:event.target.value})} placeholder={t('caption')} /></label>
      <label>{t('location')}<input maxLength={80} value={draft.location} onChange={(event) => setDraft({...draft,location:event.target.value})} placeholder={t('location')} /></label>
       <SongPicker onBusyChange={setComposingMusicBusy} value={draft.song} onChange={song => setDraft(current => ({ ...current, song }))} />
       <EmojiGrid onPick={emoji => setDraft(current => ({ ...current, caption:`${current.caption}${current.caption && !/\s$/.test(current.caption) ? ' ' : ''}${emoji}`.slice(0,800) }))} />
       <label>{t('selectImage')}<select value={draft.image} onChange={(event) => setDraft({...draft,image:Number(event.target.value)})}>{exploreItems.map((item,index) => <option key={item.label} value={index}>{item.label}</option>)}</select></label>
       <button type="button" className="gallery-button" onClick={() => galleryInput.current?.click()}><ImagePlus size={19} />{t('gallery')}</button>
       <input ref={galleryInput} className="sr-only" type="file" accept="image/*,video/*" aria-label={t('gallery')} onChange={event => { selectGalleryFile(event.target.files?.[0]); event.target.value=''; }} />
       {selectedFile && filePreview ? <div className="selected-media">{selectedFile.type.startsWith('video/') ? <video controls playsInline src={filePreview} /> : <img src={filePreview} alt={selectedFile.name} />}<span>{selectedFile.name}</span><button type="button" onClick={() => setSelectedFile(null)} aria-label={t('removeSelection')}><X size={16} /></button></div> : <img className="draft-preview" src={exploreItems[draft.image].image} alt={exploreItems[draft.image].label} />}
    </> : <><label>{t('name')}<input required maxLength={70} value={profileDraft.name} onChange={(event) => setProfileDraft({...profileDraft,name:event.target.value})} /></label><label>{t('handle')}<input required maxLength={30} value={profileDraft.handle} onChange={(event) => setProfileDraft({...profileDraft,handle:event.target.value})} /></label><label>{t('bio')}<textarea maxLength={300} value={profileDraft.bio} onChange={(event) => setProfileDraft({...profileDraft,bio:event.target.value})} /></label></>}<p className="local-note">{t('browserNote')}</p><div className="dialog-actions"><button type="button" className="text-button" onClick={() => setDialog(null)}>{t('cancel')}</button><button type="submit" className="follow-button" disabled={savingMedia || (dialog === 'create' && composingMusicBusy)}>{savingMedia ? t('saving') : t(dialog === 'create' ? 'post' : 'saveChanges')}</button></div></form></div>}
    {call && <div className="story-modal call-overlay" role="dialog" aria-modal="true" aria-label={t(call.kind === 'video' ? 'videoCall' : 'audioCall')}><div className="call-screen section-card"><div className="eyebrow">Golden Star / {t('chat')}</div><div className="call-avatar"><Avatar initials={call.name.slice(0,2)} image={portraits[contacts.indexOf(call.name)+1]} size="lg" /></div><h2>{call.name}</h2><p className="call-status">{t('calling')}</p><p className="local-note">{t('callPreview')}</p><div className="call-kind">{call.kind === 'video' ? <Video size={21} /> : <Phone size={21} />}{t(call.kind === 'video' ? 'videoCall' : 'audioCall')}</div><button type="button" className="hangup-button" onClick={() => setCall(null)}><PhoneOff size={19} />{t('endCall')}</button></div></div>}
  </div>;
}
function NavButton({ Icon, active, label, onClick }: { Icon: typeof Home; active:boolean; label:string; onClick:()=>void }) {
  return <button className={`nav-item ${active ? 'active' : ''}`} aria-current={active ? 'page' : undefined} onClick={onClick}><Icon size={19} strokeWidth={active ? 2.3 : 1.7} /><span>{label}</span></button>;
}
function ProfileMediaTile({ post, onClick, label, unavailable }: { post:Post; onClick:()=>void; label:string; unavailable:string }) {
  const mediaUrl = useMediaUrl(post.mediaId);
  return <button className="explore-tile" onClick={onClick} aria-label={`${label}: ${post.caption}`}>
    {post.mediaType === 'video' && mediaUrl ? <video src={mediaUrl} preload="metadata" muted playsInline /> : <img src={mediaUrl || post.image} alt="" />}
    <span className="tile-overlay">{mediaUrl === null && post.mediaId ? unavailable : post.caption}</span>
  </button>;
}
function PostCard({post,index,t,language,liked,saved,heart,commentList,commentsOpen,onLike,onDouble,onSave,onComments,onComment,onShare,onDelete,onProfile,following,onFollow}: {
  post:Post; index:number; t:(key:Key,values?:Record<string,string|number>)=>string; language:Language; liked:boolean; saved:boolean; heart:boolean; commentList:Comment[]; commentsOpen:boolean;
  onLike:()=>void; onDouble:()=>void; onSave:()=>void; onComments:()=>void; onComment:(text:string)=>void; onShare:()=>void; onDelete:()=>void; onProfile:()=>void; following:boolean; onFollow:()=>void;
}) {
  const [comment,setComment] = useState('');
  const [playbackError,setPlaybackError] = useState(false);
  const lastTap = useRef(0);
  const mediaUrl = useMediaUrl(post.mediaId);
  const submit = (event:FormEvent) => { event.preventDefault(); if (comment.trim()) { onComment(comment); setComment(''); } };
  return <article className="post-card" style={{animationDelay:`${index * 70}ms`}}><header className="post-head"><button onClick={onProfile} aria-label={`View ${post.creator} profile`}><Avatar initials={post.initials} image={illustration('GOLDEN STAR',150 + post.id % 17)} /></button><div className="post-author"><button onClick={onProfile} className="text-left" aria-label={`Open ${post.creator} profile`}><strong>{post.creator}</strong></button><span>{post.handle}{post.location && ` · ${post.location}`}</span></div>{!post.own && <FollowButton name={post.creator} following={following} onToggle={onFollow} />}{post.own && <button className="more-button" title={t('deletePost')} aria-label={t('deletePost')} onClick={onDelete}><Trash2 size={17} /></button>}</header>
    <div className="post-image-wrap" role={post.mediaType === 'video' ? undefined : 'button'} tabIndex={post.mediaType === 'video' ? undefined : 0} aria-label={post.mediaType === 'video' ? undefined : t('likePost')} onDoubleClick={post.mediaType === 'video' ? undefined : onDouble} onTouchEnd={post.mediaType === 'video' ? undefined : () => { const now = Date.now(); if (now - lastTap.current < 320) { onDouble(); lastTap.current = 0; } else lastTap.current = now; }} onKeyDown={post.mediaType === 'video' ? undefined : (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); onDouble(); } }}>
      {post.mediaType === 'video' && mediaUrl ? <video className="post-image" src={mediaUrl} controls preload="metadata" playsInline aria-label={post.caption} onError={() => setPlaybackError(true)} /> : <img className="post-image" src={mediaUrl || post.image} alt={post.caption} />}
      {post.mediaId && mediaUrl === null && <div className="media-missing" role="alert">{t('mediaUnavailable')}</div>}
      {playbackError && <div className="media-missing" role="alert">{t('mediaError')}</div>}
      {post.mediaType !== 'video' && <div className="image-shade" />}{heart && <span className="heart-animation"><Heart size={92} fill="currentColor" /></span>}
    </div>
    <div className="post-meta"><div className="post-actions"><button className={`post-action ${liked ? 'liked' : ''}`} aria-label={t(liked ? 'unlikePost' : 'likePost')} onClick={onLike}><Heart size={21} fill={liked ? 'currentColor' : 'none'} /><span>{post.likes + Number(liked)}</span></button><button className="post-action" aria-label={t('comments')} onClick={onComments}><MessageCircle size={20} /><span>{post.comments + commentList.length}</span></button><button className="post-action" aria-label={t('sharePost')} onClick={onShare}><Send size={19} /></button><button className={`post-action saved ${saved ? 'saved' : ''}`} aria-label={t(saved ? 'unsavePost' : 'savePost')} onClick={onSave}><Bookmark size={20} fill={saved ? 'currentColor' : 'none'} /></button></div><div className="likes-line">{t('appreciations',{count:(post.likes + Number(liked)).toLocaleString(localeMap[language])})}</div>{post.song && <span className="music-post-label"><Music2 size={13} /> {post.song}</span>}<p className="caption"><strong>{post.handle}</strong> {post.caption}</p>{post.created && <span className="timestamp">{new Intl.DateTimeFormat(localeMap[language],{dateStyle:'medium'}).format(post.created)}</span>}{commentsOpen && <div className="comments-panel">{commentList.length ? commentList.map((entry) => <p className="comment-entry" key={entry.id}><strong>{post.own ? t('you') : t('you')}</strong> {entry.text}</p>) : <p className="local-note">{t('noComments')}</p>}<form className="comment-box" onSubmit={submit}><MessageCircle size={16} color="#80796c" /><input value={comment} onChange={(event) => setComment(event.target.value)} placeholder={t('commentPrompt')} aria-label={t('writeComment')} maxLength={500} /><button className="comment-submit" type="submit" disabled={!comment.trim()}>{t('post')}</button></form></div>}</div>
  </article>;
}
function Router({ user, onLogout, onUserChange }: { user:CurrentUser; onLogout:()=>void; onUserChange:(value:CurrentUser)=>void }) {
  const [path] = useLocation();
  return <ErrorBoundary resetKey={path}><AppShell key={user.id} user={user} onLogout={onLogout} onUserChange={onUserChange} /></ErrorBoundary>;
}
export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [demoUser, setDemoUser] = useState<CurrentUser | null>(() => readDemoUser());
  const [firebaseUser, setFirebaseUser] = useState<CurrentUser | null>(null);
  const [firebaseReady, setFirebaseReady] = useState(false);
  const [firebaseSessionError, setFirebaseSessionError] = useState('');
  const [signingOut, setSigningOut] = useState(false);
  const [logoutError, setLogoutError] = useState('');
  const [recovering, setRecovering] = useState(false);
  const [authReady, setAuthReady] = useState(false);
  async function logoutAllAccounts() {
    setSigningOut(true);
    setLogoutError('');
    try {
      const auth = getFirebaseAuth();
      if (auth?.currentUser) await signOutFirebase(auth);
      if (supabase) {
        const { error } = await supabase.auth.signOut();
        if (error) throw error;
      }
      clearDemoUser();
      signedInUserId = null;
      setDemoUser(null);
      setFirebaseUser(null);
      setSession(null);
      setRecovering(false);
      queryClient.clear();
      setSigningOut(false);
    } catch {
      setLogoutError('Sign-out could not finish. Your account screens remain hidden. Check your connection and retry.');
    }
  }
  useEffect(() => {
    const auth = getFirebaseAuth();
    if (!auth) { setFirebaseReady(true); return; }
    let active = true;
    let revision = 0;
    const unsubscribe = onAuthStateChanged(auth, identity => {
      const current = ++revision;
      if (!identity) {
        if (active) { setFirebaseUser(null); setFirebaseReady(true); }
        return;
      }
      void firebaseUserToCurrentUser(identity).then(next => {
        if (!active || current !== revision) return;
        clearDemoUser();
        setDemoUser(null);
        setFirebaseUser(next);
        setFirebaseSessionError('');
        setFirebaseReady(true);
      }).catch(() => {
        if (!active || current !== revision) return;
        setFirebaseUser(null);
        setFirebaseSessionError('Could not restore your Firebase session. Sign in again.');
        setFirebaseReady(true);
      });
    }, () => {
      if (!active) return;
      setFirebaseSessionError('Firebase session checking failed. Existing email login is still available.');
      setFirebaseReady(true);
    });
    return () => { active = false; revision++; unsubscribe(); };
  }, []);
  useEffect(() => {
    if (!supabase) { signedInUserId = readDemoUser()?.id || null; setAuthReady(true); return; }
    let receivedAuthEvent = false;
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, next) => {
      receivedAuthEvent = true;
      if (event === 'PASSWORD_RECOVERY') {
        setRecovering(true);
        const firebaseAuth = getFirebaseAuth();
        if (firebaseAuth?.currentUser) void signOutFirebase(firebaseAuth).catch(() => setFirebaseSessionError('Sign out of Firebase before completing existing email recovery.'));
      }
      signedInUserId = next?.user.id || readDemoUser()?.id || null;
      if (next) { clearDemoUser(); setDemoUser(null); }
      setSession(next);
      setAuthReady(true);
    });
    void supabase.auth.getSession().then(({ data }) => {
      if (receivedAuthEvent) return;
      signedInUserId = data.session?.user.id || readDemoUser()?.id || null;
      if (data.session) { clearDemoUser(); setDemoUser(null); }
      setSession(data.session);
      setAuthReady(true);
    }).catch(() => {
      if (!receivedAuthEvent) setAuthReady(true);
    });
    return () => subscription.unsubscribe();
  }, []);
  const identity = session?.user;
  const user: CurrentUser | null = firebaseUser || (identity ? {
    id: identity.id,
    name: typeof identity.user_metadata?.full_name === 'string' ? identity.user_metadata.full_name : identity.email?.split('@')[0] || 'Creator',
    email: identity.email,
    authProvider: 'supabase',
  } : demoUser);
  signedInUserId = signingOut ? null : user?.id || null;
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
    {signingOut ? <div className="empty-state"><p role={logoutError ? 'alert' : 'status'}>{logoutError || 'Signing out of all accounts…'}</p>{logoutError && <button className="follow-button" onClick={() => void logoutAllAccounts()}>Retry sign out</button>}</div> :
      !authReady || !firebaseReady ? <div className="empty-state" role="status">Checking your session…</div> :
      user && !recovering ? <Router key={user.id} user={user} onUserChange={next => {
        if (next.id.startsWith('demo-phone-')) { saveDemoUser(next); setDemoUser(next); }
        else if (next.authProvider === 'firebase' || next.id.startsWith('firebase-')) setFirebaseUser(next);
        else setSession(previous => previous ? { ...previous, user: { ...previous.user, user_metadata: { ...previous.user.user_metadata, full_name: next.name } } } : previous);
      }} onLogout={() => void logoutAllAccounts()} /> :
      <>{firebaseSessionError && <p className="m-4 rounded-lg border border-amber-300/30 bg-black p-3 text-sm text-amber-100" role="alert">{firebaseSessionError}</p>}<RealAuthScreen recoveryMode={recovering} onRecoveryComplete={() => setRecovering(false)} onDemoLogin={next => {
        saveDemoUser(next); signedInUserId = next.id; setDemoUser(next); setRecovering(false);
      }} /></>}
  </WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}