export type LocalLanguage = 'en' | 'kn' | 'hi' | 'ta' | 'te' | 'ml';

type Topic = 'task' | 'withdraw' | 'refer' | 'default';

// User-supplied FAQ copy, not a connection to a rewards or payment system.
const knowledge: Record<Topic, Record<LocalLanguage, string>> = {
  task: {
    kn: 'ದಿನಕ್ಕೆ 10 ಟಾಸ್ಕ್ ಮಾಡಿ ₹100',
    en: 'Do 10 tasks daily and earn ₹100',
    hi: 'रोज 10 टास्क करके ₹100 कमाएं',
    ta: 'தினமும் 10 பணிகள் ₹100',
    te: 'రోజూ 10 టాస్క్‌లు ₹100',
    ml: 'ദിവസവും 10 ടാസ്ക് ₹100',
  },
  withdraw: {
    kn: 'ಕನಿಷ್ಠ ₹100 Withdraw, 24 ಗಂಟೆಯಲ್ಲಿ',
    en: 'Minimum ₹100 withdraw, comes in 24 hours',
    hi: 'न्यूनतम ₹100 निकासी 24 घंटे में',
    ta: 'குறைந்தபட்சம் ₹100',
    te: 'కనీసం ₹100 విత్‌డ్రా',
    ml: 'കുറഞ്ഞത് ₹100',
  },
  refer: {
    kn: '1 ರೆಫರ್ ಗೆ ₹20',
    en: 'You get ₹20 per referral',
    hi: 'हर रेफर पर ₹20',
    ta: 'ஒரு ரெஃபருக்கு ₹20',
    te: '1 రెఫర్ కి ₹20',
    ml: '1 റഫറിന് ₹20',
  },
  default: {
    kn: 'ಈ ವಿಷಯಕ್ಕೆ ಹೊಂದುವ ಪೂರ್ವನಿಗದಿತ ಉತ್ತರ ನನ್ನ ಬಳಿ ಇಲ್ಲ. ಆ್ಯಪ್‌ನ ಮಾಹಿತಿಯನ್ನು ಪರಿಶೀಲಿಸಿ.',
    en: 'I do not have a preset answer for this topic. Please check the information in the app.',
    hi: 'इस विषय के लिए मेरे पास पहले से तय उत्तर नहीं है। कृपया ऐप की जानकारी देखें।',
    ta: 'இந்தத் தலைப்புக்கு என்னிடம் முன்கூட்டிய பதில் இல்லை. செயலியின் தகவலைப் பார்க்கவும்.',
    te: 'ఈ విషయానికి నా దగ్గర ముందుగా సిద్ధం చేసిన సమాధానం లేదు. యాప్‌లోని సమాచారాన్ని చూడండి.',
    ml: 'ഈ വിഷയത്തിന് എനിക്ക് മുൻകൂട്ടി തയ്യാറാക്കിയ ഉത്തരമില്ല. ആപ്പിലെ വിവരങ്ങൾ പരിശോധിക്കുക.',
  },
};

const unverified: Record<LocalLanguage, string> = {
  en: 'Preset information only; rewards and payout timing are not verified. Check current app terms.',
  kn: 'ಇದು ಪೂರ್ವನಿಗದಿತ ಮಾಹಿತಿ ಮಾತ್ರ; ಬಹುಮಾನಗಳು ಮತ್ತು ಪಾವತಿ ಸಮಯ ಪರಿಶೀಲಿಸಲಾಗಿಲ್ಲ. ಆ್ಯಪ್‌ನ ಪ್ರಸ್ತುತ ನಿಯಮಗಳನ್ನು ಪರಿಶೀಲಿಸಿ.',
  hi: 'यह केवल पहले से तय जानकारी है; इनाम और भुगतान का समय सत्यापित नहीं है। ऐप की मौजूदा शर्तें देखें।',
  ta: 'இது முன்கூட்டிய தகவல் மட்டுமே; வெகுமதிகளும் பணம் வழங்கும் நேரமும் சரிபார்க்கப்படவில்லை. தற்போதைய விதிகளைப் பார்க்கவும்.',
  te: 'ఇది ముందుగా సిద్ధం చేసిన సమాచారం మాత్రమే; బహుమతులు, చెల్లింపు సమయం ధృవీకరించబడలేదు. ప్రస్తుత యాప్ నిబంధనలు చూడండి.',
  ml: 'ഇത് മുൻകൂട്ടി തയ്യാറാക്കിയ വിവരം മാത്രം; പ്രതിഫലവും പണം ലഭിക്കുന്ന സമയവും സ്ഥിരീകരിച്ചിട്ടില്ല. നിലവിലെ നിബന്ധനകൾ പരിശോധിക്കുക.',
};

const keywords: Record<Exclude<Topic, 'default'>, string[]> = {
  task: ['task', 'ಟಾಸ್ಕ್', 'ಕೆಲಸ', 'टास्क', 'कार्य', 'பணி', 'பணிகள்', 'டாஸ்க்', 'టాస్క్', 'పని', 'ടാസ്ക്', 'ജോലി'],
  withdraw: ['withdraw', 'payout', 'ವಿತ್', 'ಹಿಂಪಡೆ', 'निकासी', 'निकाल', 'வித்ட்ரா', 'திரும்பப்', 'வித்டிரா', 'విత్', 'ఉపసంహ', 'പിൻവലി', 'പിന്‍വലി', 'വിത്ത്'],
  refer: ['refer', 'ರೆಫರ್', 'ಶಿಫಾರಸು', 'रेफर', 'रेफ़र', 'ரெஃபர்', 'பரிந்துரை', 'రెఫర్', 'సిఫార్సు', 'റഫർ', 'റഫറ', 'റെഫർ'],
};

export function detectLocalLanguage(text: string): LocalLanguage {
  if (/[\u0c80-\u0cff]/u.test(text)) return 'kn';
  if (/[\u0900-\u097f]/u.test(text)) return 'hi';
  if (/[\u0b80-\u0bff]/u.test(text)) return 'ta';
  if (/[\u0c00-\u0c7f]/u.test(text)) return 'te';
  if (/[\u0d00-\u0d7f]/u.test(text)) return 'ml';
  return 'en';
}

export function getLocalAnswer(text: string, language: LocalLanguage): string {
  const question = text.toLowerCase();
  const topic = (Object.keys(keywords) as Exclude<Topic, 'default'>[])
    .find(key => keywords[key].some(word => question.includes(word))) ?? 'default';
  const answer = knowledge[topic][language];
  return topic === 'default' ? answer : `${answer}\n\n${unverified[language]}`;
}