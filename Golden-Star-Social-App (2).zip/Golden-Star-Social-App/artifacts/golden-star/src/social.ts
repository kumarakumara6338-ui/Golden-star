import { useCallback, useEffect, useMemo, useState } from 'react';

export type SocialReport = {
  name: string;
  reason: string;
  createdAt: number;
};

type UserSocialData = {
  following: string[];
  reports: SocialReport[];
};

type SocialStore = Record<string, UserSocialData>;

const storageKey = 'golden-star-social-test-v1';
const changedEvent = 'golden-star-social-changed';
const accountsKey = 'golden-star-accounts';
const currentUserKey = 'currentUser';

function normalizeName(name: string): string {
  return name.trim().toLocaleLowerCase();
}

function cleanNames(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  const names = new Map<string, string>();
  for (const item of value) {
    if (typeof item !== 'string') continue;
    const name = item.trim();
    const key = normalizeName(name);
    if (key && !names.has(key)) names.set(key, name);
  }
  return [...names.values()];
}

function cleanReports(value: unknown): SocialReport[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap((item): SocialReport[] => {
    if (!item || typeof item !== 'object') return [];
    const report = item as Partial<SocialReport>;
    if (typeof report.name !== 'string' || !report.name.trim() ||
        typeof report.reason !== 'string' || !report.reason.trim() ||
        typeof report.createdAt !== 'number' || !Number.isFinite(report.createdAt)) return [];
    return [{ name: report.name.trim(), reason: report.reason.trim(), createdAt: report.createdAt }];
  });
}

function cleanStore(parsed: unknown): SocialStore {
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return {};
  return Object.fromEntries(Object.entries(parsed).flatMap(([id, value]) => {
    if (!id || !value || typeof value !== 'object' || Array.isArray(value)) return [];
    const data = value as Partial<UserSocialData>;
    return [[id, { following: cleanNames(data.following), reports: cleanReports(data.reports) }]];
  }));
}

function readStore(): SocialStore {
  if (typeof window === 'undefined') return {};
  try {
    const parsed: unknown = JSON.parse(window.localStorage.getItem(storageKey) || '{}');
    return cleanStore(parsed);
  } catch {
    return {};
  }
}

export function deleteLocalSocialUser(userId: string): void {
  if (typeof window === 'undefined' || !userId) return;
  try {
    const raw = window.localStorage.getItem(storageKey);
    if (raw === null) return;
    const store = cleanStore(JSON.parse(raw));
    if (!Object.prototype.hasOwnProperty.call(store, userId)) return;
    delete store[userId];
    if (Object.keys(store).length === 0) window.localStorage.removeItem(storageKey);
    else window.localStorage.setItem(storageKey, JSON.stringify(store));
    window.dispatchEvent(new Event(changedEvent));
  } catch {
    throw new Error('Could not delete this account’s local social data.');
  }
}

function readUserData(userId: string): UserSocialData {
  return readStore()[userId] || { following: [], reports: [] };
}

function accountName(userId: string): string | null {
  if (typeof window === 'undefined') return null;
  try {
    const accounts: unknown = JSON.parse(window.localStorage.getItem(accountsKey) || '[]');
    if (Array.isArray(accounts)) {
      const account = accounts.find(item => item && typeof item === 'object' && item.id === userId && typeof item.name === 'string');
      if (account) return (account as { name: string }).name;
    }
    const current: unknown = JSON.parse(window.localStorage.getItem(currentUserKey) || 'null');
    if (current && typeof current === 'object' && 'id' in current && current.id === userId &&
        'name' in current && typeof current.name === 'string') return current.name;
  } catch {
    return null;
  }
  return null;
}

function localFollowerCount(name: string, excludeUserId?: string): number {
  const target = normalizeName(name);
  if (!target) return 0;
  return Object.entries(readStore()).reduce((count, [id, data]) => {
    if (id === excludeUserId || !data.following.some(item => normalizeName(item) === target)) return count;
    return count + 1;
  }, 0);
}

function localFollowingCount(name: string): number {
  if (typeof window === 'undefined') return 0;
  try {
    const accounts: unknown = JSON.parse(window.localStorage.getItem(accountsKey) || '[]');
    if (!Array.isArray(accounts)) return 0;
    const matchingIds = accounts
      .filter(item => item && typeof item === 'object' && typeof item.id === 'string' &&
        typeof item.name === 'string' && normalizeName(item.name) === normalizeName(name))
      .map(item => (item as { id: string }).id);
    return matchingIds.reduce((total, id) => total + (readStore()[id]?.following.length || 0), 0);
  } catch {
    return 0;
  }
}

export function useSocial(userId: string) {
  const [data, setData] = useState<UserSocialData>(() => readUserData(userId));
  const [storageError, setStorageError] = useState('');

  useEffect(() => {
    setData(readUserData(userId));
    const refresh = () => setData(readUserData(userId));
    window.addEventListener('storage', refresh);
    window.addEventListener(changedEvent, refresh);
    return () => {
      window.removeEventListener('storage', refresh);
      window.removeEventListener(changedEvent, refresh);
    };
  }, [userId]);

  const updateData = useCallback((update: (current: UserSocialData) => UserSocialData): boolean => {
    try {
      const store = readStore();
      const next = update(store[userId] || { following: [], reports: [] });
      store[userId] = next;
      window.localStorage.setItem(storageKey, JSON.stringify(store));
      setData(next);
      setStorageError('');
      window.dispatchEvent(new Event(changedEvent));
      return true;
    } catch {
      setStorageError('Social changes could not be saved on this device.');
      return false;
    }
  }, [userId]);

  const toggleFollow = useCallback((name: string) => {
    const displayName = name.trim();
    const target = normalizeName(displayName);
    if (!target) return;
    updateData(current => {
      const found = current.following.some(item => normalizeName(item) === target);
      return {
        ...current,
        following: found
          ? current.following.filter(item => normalizeName(item) !== target)
          : [...current.following, displayName],
      };
    });
  }, [updateData]);

  const isFollowing = useCallback((name: string) => {
    const target = normalizeName(name);
    return !!target && data.following.some(item => normalizeName(item) === target);
  }, [data.following]);

  const reportUser = useCallback((name: string, reason: string) => {
    const displayName = name.trim();
    const reportReason = reason.trim();
    if (!displayName || !reportReason) return;
    const saved = updateData(current => ({
      ...current,
      reports: [...current.reports, { name: displayName, reason: reportReason, createdAt: Date.now() }],
    }));
    if (!saved) throw new Error('Could not save the report on this device.');
  }, [updateData]);

  const followersCount = useMemo(() => {
    const name = accountName(userId);
    return name ? localFollowerCount(name, userId) : 0;
  }, [data.following, userId]);

  return {
    following: data.following,
    toggleFollow,
    isFollowing,
    followersCount,
    reports: data.reports,
    reportUser,
    storageError,
  };
}

/** Local-only relationship counts for a profile dialog; these are never remote estimates. */
export function getLocalSocialCounts(name: string, currentFollow = false): { followers: number; following: number } {
  return {
    followers: Math.max(localFollowerCount(name), currentFollow ? 1 : 0),
    following: localFollowingCount(name),
  };
}