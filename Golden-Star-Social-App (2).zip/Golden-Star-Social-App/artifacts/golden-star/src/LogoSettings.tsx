import { useRef, useState, useSyncExternalStore, type ChangeEvent } from 'react';
import { RotateCcw, Star } from 'lucide-react';
import { useMediaUrl } from './media';
import { getAppLogoId, resetAppLogo, saveAppLogo, subscribeToAppLogo } from './logo-store';

const maxLogoBytes = 2 * 1024 * 1024;

function matchesRasterSignature(file: File, bytes: Uint8Array): boolean {
  if (file.type === 'image/png') {
    return bytes.length >= 8 &&
      bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47 &&
      bytes[4] === 0x0d && bytes[5] === 0x0a && bytes[6] === 0x1a && bytes[7] === 0x0a;
  }
  if (file.type === 'image/jpeg') {
    return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  }
  if (file.type === 'image/webp') {
    return bytes.length >= 12 &&
      bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46 &&
      bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50;
  }
  return false;
}

async function validateLogoFile(file: File): Promise<void> {
  if (file.size > maxLogoBytes) {
    throw new Error('Choose an image that is 2 MB or smaller.');
  }
  if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
    throw new Error('Choose a PNG, JPEG, or WebP image. SVG files are not supported.');
  }

  const header = new Uint8Array(await file.slice(0, 12).arrayBuffer());
  if (!matchesRasterSignature(file, header)) {
    throw new Error('The selected file is not a valid PNG, JPEG, or WebP image.');
  }

  try {
    if (typeof createImageBitmap === 'function') {
      const bitmap = await createImageBitmap(file);
      try {
        if (bitmap.width <= 0 || bitmap.height <= 0) throw new Error();
      } finally {
        bitmap.close();
      }
      return;
    }

    const objectUrl = URL.createObjectURL(file);
    try {
      const image = new Image();
      image.src = objectUrl;
      await image.decode();
      if (image.naturalWidth <= 0 || image.naturalHeight <= 0) throw new Error();
    } finally {
      URL.revokeObjectURL(objectUrl);
    }
  } catch {
    throw new Error('That image could not be decoded. Choose a valid PNG, JPEG, or WebP image.');
  }
}

export function LogoSettings() {
  const inputRef = useRef<HTMLInputElement>(null);
  const logoId = useSyncExternalStore(subscribeToAppLogo, getAppLogoId, () => null);
  const logoUrl = useMediaUrl(logoId ?? undefined);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  async function onFileChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.currentTarget.files?.[0];
    event.currentTarget.value = '';
    if (!file) return;

    setPending(true);
    setError('');
    setNotice('');
    try {
      await validateLogoFile(file);
      await saveAppLogo(file);
      setNotice('The app logo is saved on this device.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'The app logo could not be saved.');
    } finally {
      setPending(false);
    }
  }

  async function onReset() {
    setPending(true);
    setError('');
    setNotice('');
    try {
      await resetAppLogo();
      setNotice('The default star logo has been restored.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'The app logo could not be reset.');
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="gs-settings-panel" data-testid="settings-app-logo">
      <div className="gs-settings-row">
        <div className="gs-settings-row-copy">
          <label htmlFor="golden-star-logo-input" style={{ display: 'block', color: 'var(--pro-ink)', fontSize: 13, fontWeight: 700 }}>
            App logo on this device
          </label>
          <small>Choose a PNG, JPEG, or WebP image up to 2 MB. The displayed name remains Golden Star Pro.</small>
        </div>
        <div role="img" aria-label={logoUrl ? 'Current app logo' : 'Default star app logo'} style={{ width: 56, height: 56, flex: 'none', display: 'grid', placeItems: 'center', overflow: 'hidden', border: '1px solid var(--pro-line)', borderRadius: 12, background: 'var(--pro-raised)', color: 'var(--pro-gold-soft)' }}>
          {logoUrl
            ? <img src={logoUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
            : <Star size={22} fill="currentColor" aria-hidden="true" />}
        </div>
      </div>
      <div className="gs-settings-row" style={{ justifyContent: 'flex-start', flexWrap: 'wrap' }}>
        <input
          ref={inputRef}
          id="golden-star-logo-input"
          type="file"
          accept="image/png,image/jpeg,image/webp"
          aria-label="App logo on this device"
          disabled={pending}
          onChange={onFileChange}
          style={{ position: 'absolute', width: 1, height: 1, padding: 0, margin: -1, overflow: 'hidden', clip: 'rect(0, 0, 0, 0)', whiteSpace: 'nowrap', border: 0 }}
        />
        <button type="button" className="gs-settings-action" disabled={pending} onClick={() => inputRef.current?.click()}>
          {pending ? 'Saving…' : logoId ? 'Update logo' : 'Upload logo'}
        </button>
        <button type="button" className="gs-settings-action" disabled={pending || !logoId} onClick={() => { void onReset(); }}>
          <RotateCcw size={13} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 5 }} />
          Reset logo
        </button>
      </div>
      {error && <p className="gs-settings-details" role="alert" style={{ margin: 0 }}>{error}</p>}
      {notice && <p className="gs-settings-details" role="status" style={{ margin: 0 }}>{notice}</p>}
    </div>
  );
}

export default LogoSettings;