import { removeMedia, saveMedia } from './media';

const logoStorageKey = 'golden-star-brand-logo-id';

type Listener = () => void;

const listeners = new Set<Listener>();
let logoIdSnapshot: string | null | undefined;

function readLogoId(): string | null {
  try {
    return window.localStorage.getItem(logoStorageKey) || null;
  } catch {
    return null;
  }
}

export function getAppLogoId(): string | null {
  if (logoIdSnapshot === undefined) {
    logoIdSnapshot = typeof window === 'undefined' ? null : readLogoId();
  }
  return logoIdSnapshot;
}

function publishLogoId(id: string | null): void {
  logoIdSnapshot = id;
  listeners.forEach(listener => {
    try {
      listener();
    } catch {
      // A subscriber must not prevent other views from observing the saved logo.
    }
  });
}

function onStorage(event: StorageEvent): void {
  if (event.key !== logoStorageKey && event.key !== null) return;
  logoIdSnapshot = event.key === logoStorageKey
    ? event.newValue || null
    : readLogoId();
  listeners.forEach(listener => {
    try {
      listener();
    } catch {
      // Keep storage synchronization isolated from individual subscribers.
    }
  });
}

export function subscribeToAppLogo(listener: Listener): () => void {
  listeners.add(listener);
  if (listeners.size === 1 && typeof window !== 'undefined') {
    window.addEventListener('storage', onStorage);
  }
  return () => {
    listeners.delete(listener);
    if (listeners.size === 0 && typeof window !== 'undefined') {
      window.removeEventListener('storage', onStorage);
    }
  };
}

function readLogoIdForWrite(): string | null {
  try {
    return window.localStorage.getItem(logoStorageKey) || null;
  } catch {
    throw new Error('Browser storage is unavailable. Allow local storage to save or reset the app logo.');
  }
}

export async function saveAppLogo(file: File): Promise<void> {
  const previousId = readLogoIdForWrite();
  const nextId = await saveMedia(file);

  try {
    window.localStorage.setItem(logoStorageKey, nextId);
  } catch {
    try {
      await removeMedia(nextId);
    } catch {
      throw new Error('Browser storage is unavailable. The logo was not changed, and its temporary image could not be removed.');
    }
    throw new Error('Browser storage is unavailable. The app logo was not changed.');
  }

  publishLogoId(nextId);
  if (previousId && previousId !== nextId) {
    try {
      await removeMedia(previousId);
    } catch {
      throw new Error('The app logo was updated, but the previous logo file could not be removed from this device.');
    }
  }
}

export async function resetAppLogo(): Promise<void> {
  const previousId = readLogoIdForWrite();
  try {
    window.localStorage.removeItem(logoStorageKey);
  } catch {
    throw new Error('Browser storage is unavailable. The app logo could not be reset.');
  }

  publishLogoId(null);
  if (previousId) {
    try {
      await removeMedia(previousId);
    } catch {
      throw new Error('The app logo was reset, but its saved image could not be removed from this device.');
    }
  }
}