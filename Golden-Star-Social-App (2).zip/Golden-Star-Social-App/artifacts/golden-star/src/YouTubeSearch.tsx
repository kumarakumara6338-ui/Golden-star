import { useEffect, useRef, useState, type FormEvent } from 'react';
import { searchYouTube } from '@workspace/api-client-react';
import YouTubeResults from './youtube/YouTubeResults';
import { youtubeThumbnail, youtubeVideoId, type YouTubeVideo } from './youtube';
import './youtube-search.css';

function songQuery(query: string): string {
  if (/[\u0C80-\u0CFF]/u.test(query)) return `${query} Kannada song`;
  if (/[\u0900-\u097F]/u.test(query)) return `${query} Hindi song`;
  return /\b(song|songs|music|lyrics|video)\b/i.test(query) ? query : `${query} song`;
}

function searchErrorMessage(cause: unknown): string {
  if (!cause || typeof cause !== 'object') return 'YouTube search is temporarily unavailable. Please try again shortly.';

  const error = cause as { status?: unknown; data?: unknown };
  const status = typeof error.status === 'number' ? error.status : undefined;
  const detail = error.data && typeof error.data === 'object' && 'error' in error.data
    ? (error.data as { error?: unknown }).error
    : undefined;
  const backendMessage = typeof detail === 'string' ? detail : '';

  if (status === 429) return 'Too many searches. Please try again shortly.';
  if (status === 401) return 'Your sign-in could not be verified. Please sign in again.';
  if (status === 400) return 'Please try a shorter song or artist search.';
  if (/quota.*temporarily exhausted/i.test(backendMessage)) {
    return 'YouTube search quota is temporarily exhausted. Please try again later.';
  }
  if (/not configured/i.test(backendMessage)) {
    return 'YouTube search is not configured correctly. Please try again later.';
  }
  return 'YouTube search is temporarily unavailable. Please try again shortly.';
}

export default function YouTubeSearch({ query, onChat }: { query: string; onChat: (video: YouTubeVideo) => void }) {
  const [videos, setVideos] = useState<YouTubeVideo[]>([]);
  const [nextPage, setNextPage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [link, setLink] = useState('');
  const [linkError, setLinkError] = useState('');
  const [pasted, setPasted] = useState<YouTubeVideo | null>(null);
  const [selected, setSelected] = useState<YouTubeVideo | null>(null);
  const controller = useRef<AbortController | null>(null);
  const requestId = useRef(0);
  const cleanQuery = query.trim();

  async function search(term: string, pageToken?: string) {
    controller.current?.abort();
    const abort = new AbortController();
    controller.current = abort;
    const id = ++requestId.current;
    setLoading(true);
    setError(null);
    try {
      const data = await searchYouTube(
        { q: songQuery(term), ...(pageToken ? { pageToken } : {}) },
        { signal: abort.signal, credentials: 'include' },
      );
      if (id !== requestId.current) return;
      const found = data.items;
      setVideos(current => pageToken ? [...current, ...found.filter(video => !current.some(item => item.id === video.id))] : found);
      setNextPage(pageToken && !found.some(video => !videos.some(item => item.id === video.id)) ? null : data.nextPageToken || null);
    } catch (cause) {
      if (abort.signal.aborted || id !== requestId.current) return;
      setError(searchErrorMessage(cause));
      if (!pageToken) setVideos([]);
      setNextPage(null);
    } finally {
      if (id === requestId.current) setLoading(false);
    }
  }

  useEffect(() => {
    controller.current?.abort();
    requestId.current += 1;
    setVideos([]);
    setNextPage(null);
    setError(null);
    setLoading(Boolean(cleanQuery));
    if (!cleanQuery) return;
    const timer = window.setTimeout(() => { void search(cleanQuery); }, 300);
    return () => { window.clearTimeout(timer); controller.current?.abort(); requestId.current += 1; };
  }, [cleanQuery]);

  function openPasted(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const id = youtubeVideoId(link);
    if (!id) {
      setLinkError('Paste a YouTube video link (watch, Shorts, Live, or youtu.be).');
      return;
    }
    const video = { id, title: 'YouTube video', channel: 'Shared from a link', thumbnail: youtubeThumbnail(id) };
    setPasted(video);
    setSelected(video);
    setLinkError('');
    setLink('');
  }

  const results = pasted && !videos.some(video => video.id === pasted.id) ? [pasted, ...videos] : videos;
  return <section className="youtube-search-section" aria-label="YouTube songs">
    <div className="youtube-search-heading"><div className="eyebrow">LIVE DISCOVERY</div><h2>YouTube songs</h2><p>Search any song or artist above to discover videos on YouTube.</p></div>
    <form className="youtube-link-form" onSubmit={openPasted}>
      <label htmlFor="youtube-link">Paste a YouTube video link</label>
      <div><input id="youtube-link" data-testid="input-youtube-link" type="url" value={link} onChange={event => { setLink(event.target.value); setLinkError(''); }} placeholder="https://www.youtube.com/watch?v=…" /><button type="submit" data-testid="button-open-youtube-link">Play link</button></div>
      {linkError && <p className="youtube-link-error" role="alert">{linkError}</p>}
    </form>
    <YouTubeResults videos={results} selected={selected} loading={loading} error={error} query={cleanQuery} hasMore={!!nextPage} onPlay={setSelected} onChat={onChat} onMore={() => { if (nextPage && !loading) void search(cleanQuery, nextPage); }} onClose={() => setSelected(null)} />
  </section>;
}