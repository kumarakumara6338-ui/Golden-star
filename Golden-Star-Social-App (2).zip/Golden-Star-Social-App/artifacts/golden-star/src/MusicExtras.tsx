import { useState } from 'react';
import { Music2, Sparkles } from 'lucide-react';
import './music-extras.css';

import MusicCatalog, { type MusicTrack } from './MusicCatalog';
export type SongTitle = string;

export const postEmojis = ['😀', '😍', '🥰', '😂', '😊', '😎', '🥳', '🤩', '❤️', '💛', '🔥', '✨', '🌟', '🎉', '🌸', '🫶', '🎶', '🎵', '💫', '👏', '🙌', '💃', '🎬', '🎤'];

export function SongPicker({ value, onChange, onBusyChange }: { value: SongTitle | null; onChange: (song: SongTitle | null) => void; onBusyChange?: (busy: boolean) => void }) {
  const [picked, setPicked] = useState<MusicTrack | null>(null);
  return <fieldset className="music-pick-section">
    <legend><Music2 size={15} /> Song list <small>Optional</small></legend>
    <MusicCatalog testPrefix="post-music" chooseLabel="Use title" onBusyChange={onBusyChange} selectedId={value ? picked?.id : undefined} onChoose={track => { setPicked(track); onChange(track.title); }} />
    {value && <p className="music-selection" data-testid="text-post-song">Selected first playable MP3: <strong>{value}</strong>. An album row can resolve to a different title than the row you tapped. Only this title is shown on your post; no audio is attached. <button type="button" onClick={() => { setPicked(null); onChange(null); }} data-testid="button-clear-post-song">Remove</button></p>}
  </fieldset>;
}

export function EmojiGrid({ onPick, label = 'Add emoji to caption' }: { onPick: (emoji: string) => void; label?: string }) {
  return <div className="music-emoji-section">
    <div className="music-section-label"><Sparkles size={15} /> Emoji picker</div>
    <div className="music-emoji-grid" aria-label="Emoji picker">
      {postEmojis.map(emoji => <button type="button" key={emoji} aria-label={`${label}: ${emoji}`} onClick={() => onPick(emoji)}>{emoji}</button>)}
    </div>
  </div>;
}

export function SongLibrary({ onChoose }: { onChoose: (song: SongTitle) => void }) {
  return <MusicCatalog testPrefix="songs" chooseLabel="Add to post" onChoose={track => onChoose(track.title)} />;
}
