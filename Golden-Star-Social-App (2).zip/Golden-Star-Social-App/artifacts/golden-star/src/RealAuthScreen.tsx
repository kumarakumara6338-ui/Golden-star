import { useEffect, useRef, useState, type FormEvent } from 'react';
import { ArrowLeft, ArrowRight, Star } from 'lucide-react';
import BrandLogo from './BrandLogo';
import {
  createUserWithEmailAndPassword,
  RecaptchaVerifier,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPhoneNumber,
  signOut,
  updateProfile,
  type ConfirmationResult,
} from 'firebase/auth';
import { getFirebaseAuth, getFirebaseConfigIssue } from './firebase-auth';
import { liveClient, supabase } from './live/supabase';
import type { CurrentUser } from './pro-types';
import { completeDemoPhoneLogin, getDemoPhoneUser, getDemoStorageIssue, hasDemoPhoneAccount, resetDemoPhonePassword, saveDemoUser } from './demo-auth';
import { isDemoPinEnabled, verifyDemoPin } from './demo-security';
import './pro.css';

type Props = {
  onDemoLogin?: (user: CurrentUser) => void;
  onRecoveryComplete?: () => void;
  recoveryMode?: boolean;
};

type Country = { code: string; label: string };
const countries: Country[] = [
  { code: '+91', label: 'India (+91)' },
  { code: '+1', label: 'United States / Canada (+1)' },
  { code: '+44', label: 'United Kingdom (+44)' },
  { code: '+61', label: 'Australia (+61)' },
  { code: '+971', label: 'United Arab Emirates (+971)' },
  { code: '+65', label: 'Singapore (+65)' },
];

function canonicalPhone(countryCode: string, phone: string): string {
  const digits = `${countryCode.replace(/\D/g, '')}${phone.replace(/\D/g, '')}`;
  if (digits.length < 8 || digits.length > 15) throw new Error('Enter a phone number with 8 to 15 digits, including its country code.');
  return `+${digits}`;
}

export default function RealAuthScreen({ onDemoLogin, onRecoveryComplete, recoveryMode = false }: Props) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [method, setMethod] = useState<'email' | 'firebase-phone' | 'demo'>('email');
  const [emailProvider, setEmailProvider] = useState<'supabase' | 'firebase'>('supabase');
  const [view, setView] = useState<'main' | 'forgot' | 'phone-reset-otp' | 'phone-reset-password' | 'real-recovery'>(recoveryMode ? 'real-recovery' : 'main');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const [countryCode, setCountryCode] = useState('+91');
  const [phone, setPhone] = useState('');
  const [phoneName, setPhoneName] = useState('');
  const [phoneStep, setPhoneStep] = useState<'phone' | 'otp' | 'pin'>('phone');
  const [phoneOtp, setPhoneOtp] = useState('');
  const [phonePin, setPhonePin] = useState('');
  const [pendingPhone, setPendingPhone] = useState('');
  const [pendingDemoUser, setPendingDemoUser] = useState<CurrentUser | null>(null);

  const [firebasePhoneStep, setFirebasePhoneStep] = useState<'phone' | 'otp'>('phone');
  const [firebaseOtp, setFirebaseOtp] = useState('');
  const [firebasePendingPhone, setFirebasePendingPhone] = useState('');
  const confirmationRef = useRef<ConfirmationResult | null>(null);
  const recaptchaRef = useRef<RecaptchaVerifier | null>(null);
  const phoneRequestRef = useRef(0);
  const mountedRef = useRef(true);

  const [recoveryType, setRecoveryType] = useState<'supabase-email' | 'firebase-email' | 'demo-phone'>('supabase-email');
  const [resetCountryCode, setResetCountryCode] = useState('+91');
  const [resetPhone, setResetPhone] = useState('');
  const [resetOtp, setResetOtp] = useState('');
  const [resetPassword, setResetPassword] = useState('');
  const [resetConfirmPassword, setResetConfirmPassword] = useState('');
  const [pendingResetPhone, setPendingResetPhone] = useState('');
  const demoStorageIssue = getDemoStorageIssue();
  const firebaseConfigIssue = getFirebaseConfigIssue();

  useEffect(() => {
    mountedRef.current = true;
    let unsubscribe = () => {};
    try {
      const { data: { subscription } } = liveClient().auth.onAuthStateChange(event => {
        if (event === 'PASSWORD_RECOVERY') {
          setView('real-recovery');
          setPassword('');
          setConfirmPassword('');
          setError('');
          setNotice('Choose a new password for your Supabase email account.');
        }
      });
      unsubscribe = () => subscription.unsubscribe();
    } catch {
      // The screen remains usable for Firebase accounts when Supabase is not configured.
    }
    return () => {
      mountedRef.current = false;
      unsubscribe();
      phoneRequestRef.current += 1;
      confirmationRef.current = null;
      recaptchaRef.current?.clear();
      recaptchaRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (recoveryMode) {
      setView('real-recovery');
      setError('');
      setNotice('Choose a new password for your Supabase email account.');
    }
  }, [recoveryMode]);

  function clearFeedback() {
    setError('');
    setNotice('');
  }

  function clearFirebasePhoneAttempt() {
    phoneRequestRef.current += 1;
    confirmationRef.current = null;
    recaptchaRef.current?.clear();
    recaptchaRef.current = null;
  }

  async function signOutOtherProvider(provider: 'firebase' | 'supabase') {
    if (provider === 'firebase') {
      const auth = getFirebaseAuth();
      if (auth?.currentUser) await signOut(auth);
    } else if (supabase) {
      const { error: cause } = await supabase.auth.signOut();
      if (cause) throw cause;
    }
  }

  function firebaseErrorMessage(cause: unknown, fallback: string): string {
    const code = typeof cause === 'object' && cause !== null && 'code' in cause
      ? String((cause as { code: unknown }).code)
      : '';
    if (code === 'auth/invalid-verification-code') return 'That six-digit code is incorrect. Check the SMS and try again.';
    if (code === 'auth/code-expired' || code === 'auth/session-expired') return 'That verification code expired. Send a new code and try again.';
    if (code === 'auth/captcha-check-failed' || code === 'auth/invalid-app-credential' || code === 'auth/missing-app-credential') {
      return 'Phone verification expired or could not be verified. Please request a new code.';
    }
    if (code === 'auth/quota-exceeded') return 'Firebase SMS quota is temporarily exhausted. Try again later.';
    if (code === 'auth/too-many-requests') return 'Too many attempts. Wait a while before trying again.';
    if (code === 'auth/invalid-phone-number') return 'Enter a valid phone number, including its country code.';
    if (code === 'auth/operation-not-allowed') return 'This sign-in method is not enabled in Firebase Authentication.';
    if (code === 'auth/network-request-failed') return 'Network error while contacting Firebase. Check your connection and try again.';
    return cause instanceof Error ? cause.message : fallback;
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    setPending(true);
    clearFeedback();
    try {
      if (emailProvider === 'firebase') {
        const auth = getFirebaseAuth();
        if (!auth) throw new Error(getFirebaseConfigIssue() || 'Firebase Authentication is unavailable.');
        const address = email.trim().toLowerCase();
        if (mode === 'signup') {
          if (!name.trim()) throw new Error('Enter your name.');
          const credential = await createUserWithEmailAndPassword(auth, address, password);
          await signOutOtherProvider('supabase');
          await updateProfile(credential.user, { displayName: name.trim() });
        } else {
          await signInWithEmailAndPassword(auth, address, password);
          await signOutOtherProvider('supabase');
        }
      } else {
        const client = liveClient();
        if (mode === 'signup') {
          if (!name.trim()) throw new Error('Enter your name.');
          const { data, error: cause } = await client.auth.signUp({
            email: email.trim().toLowerCase(), password,
            options: { data: { full_name: name.trim() } },
          });
          if (cause) throw cause;
          if (data.session) await signOutOtherProvider('firebase');
          else setNotice('Check your email to confirm your Supabase account, then sign in.');
        } else {
          const { error: cause } = await client.auth.signInWithPassword({ email: email.trim().toLowerCase(), password });
          if (cause) throw cause;
          await signOutOtherProvider('firebase');
        }
      }
    } catch (cause) {
      setError(emailProvider === 'firebase'
        ? firebaseErrorMessage(cause, 'Could not sign in with Firebase.')
        : cause instanceof Error ? cause.message : 'Could not sign in.');
    } finally {
      setPending(false);
    }
  }

  async function startDemoPhoneLogin(event: FormEvent) {
    event.preventDefault();
    clearFeedback();
    try {
      const target = canonicalPhone(countryCode, phone);
      setPendingPhone(target);
      setPhoneOtp('');
      setPhonePin('');
      setPendingDemoUser(null);
      setPhoneStep('otp');
      setNotice('Test-only phone sign-in. No SMS is sent; enter the mock code shown below.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Enter a valid phone number.');
    }
  }

  async function requestFirebasePhoneCode(target: string, keepOtpScreen = false) {
    clearFirebasePhoneAttempt();
    const requestId = phoneRequestRef.current;
    clearFeedback();
    setPending(true);
    setFirebasePendingPhone(target);
    setFirebaseOtp('');
    if (!keepOtpScreen) setFirebasePhoneStep('phone');
    try {
      const auth = getFirebaseAuth();
      if (!auth) throw new Error(getFirebaseConfigIssue() || 'Firebase Authentication is unavailable.');
      const verifier = new RecaptchaVerifier(auth, 'firebase-phone-recaptcha', {
        size: 'invisible',
        'expired-callback': () => {
          if (mountedRef.current && phoneRequestRef.current === requestId) {
            setError('Phone verification expired. Request a new SMS code.');
            setNotice('');
            setPending(false);
            clearFirebasePhoneAttempt();
            setFirebasePhoneStep('phone');
          }
        },
      });
      recaptchaRef.current = verifier;
      const confirmation = await signInWithPhoneNumber(auth, target, verifier);
      if (!mountedRef.current || phoneRequestRef.current !== requestId) return;
      confirmationRef.current = confirmation;
      setFirebasePhoneStep('otp');
      setNotice(`A six-digit verification code was sent to ${target}.`);
    } catch (cause) {
      if (mountedRef.current && phoneRequestRef.current === requestId) {
        setError(firebaseErrorMessage(cause, 'Could not send a Firebase verification code.'));
        setNotice('');
        confirmationRef.current = null;
        recaptchaRef.current?.clear();
        recaptchaRef.current = null;
      }
    } finally {
      if (mountedRef.current && phoneRequestRef.current === requestId) setPending(false);
    }
  }

  async function startFirebasePhoneLogin(event: FormEvent) {
    event.preventDefault();
    try {
      const target = canonicalPhone(countryCode, phone);
      await requestFirebasePhoneCode(target);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Enter a valid phone number.');
    }
  }

  async function verifyFirebasePhoneOtp(event: FormEvent) {
    event.preventDefault();
    clearFeedback();
    const confirmation = confirmationRef.current;
    if (!confirmation) {
      setError('Your Firebase verification expired. Request a new code.');
      setFirebasePhoneStep('phone');
      return;
    }
    setPending(true);
    const requestId = phoneRequestRef.current;
    try {
      const credential = await confirmation.confirm(firebaseOtp);
      if (phoneRequestRef.current === requestId) {
        confirmationRef.current = null;
        recaptchaRef.current?.clear();
        recaptchaRef.current = null;
      }
      await signOutOtherProvider('supabase');
      if (mountedRef.current && phoneRequestRef.current === requestId) {
        phoneRequestRef.current += 1;
        setNotice(`Phone number ${credential.user.phoneNumber || firebasePendingPhone} verified successfully.`);
      }
    } catch (cause) {
      if (mountedRef.current && phoneRequestRef.current === requestId) {
        const code = typeof cause === 'object' && cause !== null && 'code' in cause
          ? String((cause as { code: unknown }).code)
          : '';
        setError(firebaseErrorMessage(cause, 'Could not verify the Firebase code.'));
        if (code === 'auth/code-expired' || code === 'auth/session-expired' || code === 'auth/captcha-check-failed'
          || code === 'auth/invalid-app-credential' || code === 'auth/missing-app-credential') {
          setPending(false);
          clearFirebasePhoneAttempt();
          setFirebasePhoneStep('phone');
        }
      }
    } finally {
      if (mountedRef.current && phoneRequestRef.current === requestId) setPending(false);
    }
  }

  async function finishDemoLogin(user: CurrentUser) {
    const demoUser: CurrentUser = { ...user, authProvider: 'demo' };
    saveDemoUser(demoUser);
    if (onDemoLogin) {
      onDemoLogin(demoUser);
    } else {
      setNotice('Demo identity saved on this device. The app host must connect the optional demo-login callback to open the local demo session.');
    }
  }

  async function verifyDemoPhoneOtp(event: FormEvent) {
    event.preventDefault();
    clearFeedback();
    setPending(true);
    try {
      if (phoneOtp !== '123456') throw new Error('Incorrect demo code. Enter 123456.');
      const existing = getDemoPhoneUser(pendingPhone);
      if (existing && isDemoPinEnabled(existing.id)) {
        setPendingDemoUser(existing);
        setPhoneStep('pin');
        setNotice('Enter your local demo verification PIN to continue.');
        return;
      }
      const user = completeDemoPhoneLogin(pendingPhone, phoneName);
      await finishDemoLogin(user);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not complete demo phone sign-in.');
    } finally {
      setPending(false);
    }
  }

  async function verifyPhonePin(event: FormEvent) {
    event.preventDefault();
    if (!pendingDemoUser) {
      setError('Your demo login expired. Start phone sign-in again.');
      setPhoneStep('phone');
      return;
    }
    setPending(true);
    clearFeedback();
    try {
      if (!await verifyDemoPin(pendingDemoUser.id, phonePin)) throw new Error('Incorrect PIN. Try again.');
      await finishDemoLogin(pendingDemoUser);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not verify the local demo PIN.');
    } finally {
      setPending(false);
    }
  }

  async function submitForgot(event: FormEvent) {
    event.preventDefault();
    setPending(true);
    clearFeedback();
    try {
      if (recoveryType === 'supabase-email') {
        const address = email.trim().toLowerCase();
        if (!address) throw new Error('Enter the email address on your account.');
        const { error: cause } = await liveClient().auth.resetPasswordForEmail(address, {
          redirectTo: `${window.location.origin}${window.location.pathname}`,
        });
        if (cause) throw cause;
        setNotice('If this Supabase account can receive recovery email, follow its secure reset link. The password changes only after Supabase confirms PASSWORD_RECOVERY.');
        return;
      }
      if (recoveryType === 'firebase-email') {
        const address = email.trim().toLowerCase();
        if (!address) throw new Error('Enter the email address on your account.');
        const auth = getFirebaseAuth();
        if (!auth) throw new Error(getFirebaseConfigIssue() || 'Firebase Authentication is unavailable.');
        await sendPasswordResetEmail(auth, address);
        setNotice('If this Firebase account can receive recovery email, follow the secure password reset link from Firebase.');
        return;
      }
      const target = canonicalPhone(resetCountryCode, resetPhone);
      if (!hasDemoPhoneAccount(target)) throw new Error('Password recovery is available only for an existing local demo phone account. Real phone accounts cannot be reset with a mock code.');
      setPendingResetPhone(target);
      setResetOtp('');
      setView('phone-reset-otp');
      setNotice('Local demo recovery only. No SMS is sent; enter the mock code 123456.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not begin password recovery.');
    } finally {
      setPending(false);
    }
  }

  function verifyResetOtp(event: FormEvent) {
    event.preventDefault();
    clearFeedback();
    if (resetOtp !== '123456') {
      setError('Incorrect demo code. Enter 123456.');
      return;
    }
    setView('phone-reset-password');
    setNotice('Choose a new password for this local demo account. Phone login will continue to use the demo OTP.');
  }

  async function submitDemoPasswordReset(event: FormEvent) {
    event.preventDefault();
    setPending(true);
    clearFeedback();
    try {
      if (resetPassword.length < 8) throw new Error('Password must be at least 8 characters.');
      if (resetPassword !== resetConfirmPassword) throw new Error('Passwords do not match.');
      await resetDemoPhonePassword(pendingResetPhone, resetPassword);
      setView('main');
      setRecoveryType('demo-phone');
      setNotice('Local demo password updated. Phone login still uses the test-only OTP, not this password.');
      setResetPassword('');
      setResetConfirmPassword('');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not update the local demo password.');
    } finally {
      setPending(false);
    }
  }

  async function submitRealPasswordReset(event: FormEvent) {
    event.preventDefault();
    setPending(true);
    clearFeedback();
    try {
      if (password.length < 8) throw new Error('Password must be at least 8 characters.');
      if (password !== confirmPassword) throw new Error('Passwords do not match.');
      const { error: cause } = await liveClient().auth.updateUser({ password });
      if (cause) throw cause;
      setView('main');
      setMode('login');
      setPassword('');
      setConfirmPassword('');
      setNotice('Your Supabase account password was updated.');
      onRecoveryComplete?.();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not update your password.');
    } finally {
      setPending(false);
    }
  }

  const goBackToSignIn = () => {
    setView('main');
    setPhoneStep('phone');
    clearFeedback();
  };

  const switchMethod = (nextMethod: 'email' | 'firebase-phone' | 'demo') => {
    if (method === 'firebase-phone' && nextMethod !== 'firebase-phone') {
      clearFirebasePhoneAttempt();
      setPending(false);
      setFirebasePhoneStep('phone');
    }
    setMethod(nextMethod);
    clearFeedback();
  };

  return <main className="gs-pro gs-auth">
    <section className="gs-auth-stage" aria-label="Golden Star Pro">
      <div className="gs-brand"><span className="gs-brand-icon"><BrandLogo size={16} /></span> Golden Star Pro</div>
      <Star className="gs-auth-orbit-star" strokeWidth={.5} fill="currentColor" aria-hidden="true" />
      <div className="gs-auth-stage-copy"><p className="gs-kicker">A place for your people</p><h1>Stay for<br />the <span>moment.</span></h1><p>Stories, conversations, and the people who make your after-hours worth sharing.</p></div>
      <div className="gs-auth-stage-foot"><span>Golden Star Pro / Your inner circle</span><span>Est. after dark</span></div>
    </section>
    <section className="gs-auth-side" aria-label="Sign in to Golden Star Pro">
      <div className="gs-auth-card">
        <div className="gs-auth-intro">
          <p className="gs-kicker">{view === 'main' ? 'Welcome in' : 'Account recovery'}</p>
          <h2>{view === 'main' ? mode === 'signup' ? 'Make it yours.' : 'Good to see you.' : view === 'real-recovery' || view === 'phone-reset-password' ? 'Choose a new password.' : 'Let’s get you back in.'}</h2>
          <p>{view === 'main' ? 'Sign in to connect with people across phones.' : 'Use the recovery flow for the account type you selected.'}</p>
        </div>
        {demoStorageIssue && <p className="gs-auth-note mt-0 rounded-lg border border-amber-300/25 bg-amber-300/[0.06] px-3 py-2.5 text-amber-100" role="status">{demoStorageIssue}</p>}

        {view === 'main' && <>
          <div className="gs-auth-tabs flex flex-wrap gap-x-5 gap-y-2" role="tablist" aria-label="Sign in method">
            <button type="button" role="tab" aria-selected={method === 'email' && mode === 'login'} onClick={() => { switchMethod('email'); setMode('login'); }}>Email login</button>
            <button type="button" role="tab" aria-selected={method === 'email' && mode === 'signup'} onClick={() => { switchMethod('email'); setMode('signup'); }}>Email sign up</button>
            <button type="button" role="tab" aria-selected={method === 'firebase-phone'} onClick={() => { switchMethod('firebase-phone'); setMode('login'); }}>Firebase phone</button>
            <button type="button" role="tab" aria-selected={method === 'demo'} onClick={() => { switchMethod('demo'); setMode('login'); setPhoneStep('phone'); }}>Demo test</button>
          </div>

          {method === 'email' ? <>
            <div className="gs-auth-tabs flex flex-wrap gap-x-5 gap-y-2" role="tablist" aria-label="Email account provider">
              <button type="button" role="tab" aria-selected={emailProvider === 'supabase'} onClick={() => { setEmailProvider('supabase'); clearFeedback(); }}>Supabase account</button>
              <button type="button" role="tab" aria-selected={emailProvider === 'firebase'} onClick={() => { setEmailProvider('firebase'); clearFeedback(); }}>Firebase account</button>
            </div>
            {emailProvider === 'firebase' && firebaseConfigIssue && <p className="gs-auth-note mt-0 rounded-lg border border-amber-300/25 bg-amber-300/[0.06] px-3 py-2.5 text-amber-100" role="status">{firebaseConfigIssue}</p>}
            <form className="gs-auth-form" onSubmit={submit}>
            {mode === 'signup' && <label className="gs-field">Your name<input required autoComplete="name" maxLength={80} value={name} onChange={event => setName(event.target.value)} /></label>}
            <label className="gs-field">Email address<input required type="email" autoComplete="email" value={email} onChange={event => setEmail(event.target.value)} /></label>
            <label className="gs-field">Password<input required type="password" minLength={8} autoComplete={mode === 'signup' ? 'new-password' : 'current-password'} value={password} onChange={event => setPassword(event.target.value)} /></label>
            <button className="gs-primary" disabled={pending}>{pending ? 'Please wait…' : mode === 'signup' ? `Create ${emailProvider === 'firebase' ? 'Firebase' : 'Supabase'} account` : `Sign in with ${emailProvider === 'firebase' ? 'Firebase' : 'Supabase'}`} <ArrowRight size={16} /></button>
            {mode === 'login' && <button type="button" className="gs-quiet justify-self-start" onClick={() => { setView('forgot'); setRecoveryType(emailProvider === 'firebase' ? 'firebase-email' : 'supabase-email'); clearFeedback(); }}>Forgot password?</button>}
            </form>
          </> : method === 'firebase-phone' ? <div className="grid gap-4">
            {firebaseConfigIssue && <p className="gs-auth-note mt-0 rounded-lg border border-amber-300/25 bg-amber-300/[0.06] px-3 py-2.5 text-amber-100" role="status">{firebaseConfigIssue}</p>}
            <div id="firebase-phone-recaptcha" />
            {firebasePhoneStep === 'phone' && <form className="gs-auth-form" onSubmit={startFirebasePhoneLogin}>
              <label className="gs-field">Country or region<select className="w-full rounded-lg border border-amber-300/20 bg-[#1c1812] px-3 py-3 text-sm text-[#f4ecd9]" value={countryCode} onChange={event => setCountryCode(event.target.value)}>{countries.map(country => <option key={country.code} value={country.code}>{country.label}</option>)}</select></label>
              <label className="gs-field">Phone number<input required type="tel" autoComplete="tel-national" inputMode="tel" value={phone} onChange={event => setPhone(event.target.value)} placeholder="Phone number, without country code" /></label>
              <div className="rounded-lg border border-white/10 px-3 py-2 text-xs leading-relaxed text-[#c8bda9]" role="note">Firebase sends a real SMS. Enter the six-digit code you receive to verify this phone number.</div>
              <button className="gs-primary" disabled={pending}>{pending ? 'Sending code…' : 'Send SMS code'} <ArrowRight size={16} /></button>
            </form>}
            {firebasePhoneStep === 'otp' && <form className="gs-auth-form" onSubmit={verifyFirebasePhoneOtp}>
              <p className="gs-auth-note mt-0">Enter the six-digit SMS code sent to <strong>{firebasePendingPhone}</strong>.</p>
              <label className="gs-field">6-digit verification code<input className="gs-auth-code" required inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} value={firebaseOtp} onChange={event => setFirebaseOtp(event.target.value.replace(/\D/g, '').slice(0, 6))} /></label>
              <button className="gs-primary" disabled={pending}>{pending ? 'Verifying…' : 'Verify phone number'} <ArrowRight size={16} /></button>
              <button type="button" className="gs-quiet justify-self-start" disabled={pending} onClick={() => void requestFirebasePhoneCode(firebasePendingPhone, true)}>Resend code</button>
              <button type="button" className="gs-quiet justify-self-start" onClick={() => { clearFirebasePhoneAttempt(); setPending(false); setFirebasePhoneStep('phone'); setFirebaseOtp(''); clearFeedback(); }}><ArrowLeft size={14} /> Change phone number</button>
            </form>}
          </div> : <div className="grid gap-4">
            <div className="rounded-lg border border-amber-300/25 bg-amber-300/[0.06] px-3 py-2 text-xs leading-relaxed text-amber-100" role="note">
              DEMO / TEST ONLY. This phone flow creates a browser-local demo identity and never signs in to Supabase or sends SMS.
            </div>
            {phoneStep === 'phone' && <form className="gs-auth-form" onSubmit={startDemoPhoneLogin}>
              <label className="gs-field">Country or region<select className="w-full rounded-lg border border-amber-300/20 bg-[#1c1812] px-3 py-3 text-sm text-[#f4ecd9]" value={countryCode} onChange={event => setCountryCode(event.target.value)}>{countries.map(country => <option key={country.code} value={country.code}>{country.label}</option>)}</select></label>
              <label className="gs-field">Phone number<input required type="tel" autoComplete="tel-national" inputMode="tel" value={phone} onChange={event => setPhone(event.target.value)} placeholder="Phone number, without country code" /></label>
              <label className="gs-field">Demo display name <span className="font-normal text-[#a69a83]">(used only when creating a local demo account)</span><input maxLength={80} autoComplete="name" value={phoneName} onChange={event => setPhoneName(event.target.value)} placeholder="Your name" /></label>
              <button className="gs-primary" disabled={pending}>Continue with test code <ArrowRight size={16} /></button>
            </form>}
            {phoneStep === 'otp' && <form className="gs-auth-form" onSubmit={verifyDemoPhoneOtp}>
              <p className="gs-auth-note mt-0">Enter the 6-digit test code for <strong>{pendingPhone}</strong>. This code is fixed for this demo.</p>
              <label className="gs-field">6-digit demo OTP<input className="gs-auth-code" required inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} value={phoneOtp} onChange={event => setPhoneOtp(event.target.value.replace(/\D/g, '').slice(0, 6))} /></label>
              <p className="gs-auth-note mt-0"><strong>Test code: 123456</strong> — no message is sent.</p>
              <button className="gs-primary" disabled={pending}>{pending ? 'Verifying…' : 'Verify demo code'} <ArrowRight size={16} /></button>
              <button type="button" className="gs-quiet justify-self-start" onClick={() => { setPhoneStep('phone'); clearFeedback(); }}><ArrowLeft size={14} /> Change phone number</button>
            </form>}
            {phoneStep === 'pin' && <form className="gs-auth-form" onSubmit={verifyPhonePin}>
              <p className="gs-auth-note mt-0">A local demo verification PIN is enabled for this account.</p>
              <label className="gs-field">6-digit PIN<input className="gs-auth-code" required inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} value={phonePin} onChange={event => setPhonePin(event.target.value.replace(/\D/g, '').slice(0, 6))} /></label>
              <button className="gs-primary" disabled={pending}>{pending ? 'Verifying…' : 'Verify PIN'} <ArrowRight size={16} /></button>
              <button type="button" className="gs-quiet justify-self-start" onClick={() => { setPhoneStep('phone'); setPendingDemoUser(null); clearFeedback(); }}><ArrowLeft size={14} /> Start over</button>
            </form>}
          </div>}
        </>}

        {view === 'forgot' && <form className="gs-auth-form" onSubmit={submitForgot}>
          <div className="gs-auth-tabs" role="tablist" aria-label="Recovery account type">
            <button type="button" role="tab" aria-selected={recoveryType === 'supabase-email'} onClick={() => { setRecoveryType('supabase-email'); clearFeedback(); }}>Supabase email</button>
            <button type="button" role="tab" aria-selected={recoveryType === 'firebase-email'} onClick={() => { setRecoveryType('firebase-email'); clearFeedback(); }}>Firebase email</button>
            <button type="button" role="tab" aria-selected={recoveryType === 'demo-phone'} onClick={() => { setRecoveryType('demo-phone'); clearFeedback(); }}>Demo phone</button>
          </div>
          {(recoveryType === 'supabase-email' || recoveryType === 'firebase-email') && <>
            {recoveryType === 'firebase-email' && firebaseConfigIssue && <p className="gs-auth-note mt-0 rounded-lg border border-amber-300/25 bg-amber-300/[0.06] px-3 py-2.5 text-amber-100" role="status">{firebaseConfigIssue}</p>}
            <label className="gs-field">Account email<input required type="email" autoComplete="email" value={email} onChange={event => setEmail(event.target.value)} /></label>
          </>}
          {recoveryType === 'demo-phone' && <>
            <p className="gs-auth-note mt-0">Demo/test-only recovery for a phone account created on this device. Real phone accounts cannot use mock OTP recovery.</p>
            <label className="gs-field">Country or region<select className="w-full rounded-lg border border-amber-300/20 bg-[#1c1812] px-3 py-3 text-sm text-[#f4ecd9]" value={resetCountryCode} onChange={event => setResetCountryCode(event.target.value)}>{countries.map(country => <option key={country.code} value={country.code}>{country.label}</option>)}</select></label>
            <label className="gs-field">Demo phone number<input required type="tel" inputMode="tel" value={resetPhone} onChange={event => setResetPhone(event.target.value)} /></label>
          </>}
          <button className="gs-primary" disabled={pending}>{pending ? 'Please wait…' : recoveryType === 'demo-phone' ? 'Continue with demo recovery' : `Send ${recoveryType === 'firebase-email' ? 'Firebase' : 'Supabase'} reset link`} <ArrowRight size={16} /></button>
          <button type="button" className="gs-quiet justify-self-start" onClick={goBackToSignIn}><ArrowLeft size={14} /> Back to sign in</button>
        </form>}

        {view === 'phone-reset-otp' && <form className="gs-auth-form" onSubmit={verifyResetOtp}>
          <p className="gs-auth-note mt-0">Local demo account <strong>{pendingResetPhone}</strong>. No message is sent.</p>
          <label className="gs-field">6-digit demo OTP<input className="gs-auth-code" required inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} value={resetOtp} onChange={event => setResetOtp(event.target.value.replace(/\D/g, '').slice(0, 6))} /></label>
          <p className="gs-auth-note mt-0"><strong>Test code: 123456</strong></p>
          <button className="gs-primary">Verify demo code <ArrowRight size={16} /></button>
          <button type="button" className="gs-quiet justify-self-start" onClick={goBackToSignIn}><ArrowLeft size={14} /> Cancel recovery</button>
        </form>}

        {view === 'phone-reset-password' && <form className="gs-auth-form" onSubmit={submitDemoPasswordReset}>
          <p className="gs-auth-note mt-0">This updates only the local demo account’s stored password hash. Phone login remains OTP-only.</p>
          <label className="gs-field">New password<input required type="password" minLength={8} autoComplete="new-password" value={resetPassword} onChange={event => setResetPassword(event.target.value)} /></label>
          <label className="gs-field">Confirm new password<input required type="password" minLength={8} autoComplete="new-password" value={resetConfirmPassword} onChange={event => setResetConfirmPassword(event.target.value)} /></label>
          <button className="gs-primary" disabled={pending}>{pending ? 'Saving…' : 'Update local demo password'} <ArrowRight size={16} /></button>
          <button type="button" className="gs-quiet justify-self-start" onClick={goBackToSignIn}><ArrowLeft size={14} /> Cancel recovery</button>
        </form>}

        {view === 'real-recovery' && <form className="gs-auth-form" onSubmit={submitRealPasswordReset}>
          <p className="gs-auth-note mt-0">Supabase confirmed a real email-account recovery session. No mock OTP is used for real accounts.</p>
          <label className="gs-field">New password<input required type="password" minLength={8} autoComplete="new-password" value={password} onChange={event => setPassword(event.target.value)} /></label>
          <label className="gs-field">Confirm new password<input required type="password" minLength={8} autoComplete="new-password" value={confirmPassword} onChange={event => setConfirmPassword(event.target.value)} /></label>
          <button className="gs-primary" disabled={pending}>{pending ? 'Saving…' : 'Update Supabase password'} <ArrowRight size={16} /></button>
        </form>}

        {error && <p className="gs-auth-error mt-4" role="alert">{error}</p>}
        {notice && <p className="gs-auth-note" role="status">{notice}</p>}
      </div>
      <p className="gs-auth-end">Choose Supabase or Firebase for real email accounts. Firebase phone verification sends a real SMS; demo test accounts remain browser-local.</p>
    </section>
  </main>;
}