const pinKeyPrefix = 'golden-star-demo-phone-pin:';

type PinRecord = {
  salt: string;
  hash: string;
};

function storageKey(userId: string): string {
  if (!userId.startsWith('demo-phone-')) throw new Error('Two-step verification is available only for local demo phone accounts.');
  return `${pinKeyPrefix}${userId}`;
}

function readRecord(userId: string): PinRecord | null {
  const raw = localStorage.getItem(storageKey(userId));
  if (!raw) return null;
  try {
    const value: unknown = JSON.parse(raw);
    if (value && typeof value === 'object'
      && typeof (value as PinRecord).salt === 'string'
      && typeof (value as PinRecord).hash === 'string') {
      return value as PinRecord;
    }
  } catch {
    throw new Error('Saved demo verification data is invalid. Disable it after restoring valid local data.');
  }
  throw new Error('Saved demo verification data is invalid. Disable it after restoring valid local data.');
}

async function hashPin(pin: string, salt: Uint8Array): Promise<string> {
  if (!globalThis.crypto?.subtle) throw new Error('Secure PIN storage is unavailable in this browser.');
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({
    name: 'PBKDF2',
    salt: Uint8Array.from(salt),
    iterations: 120000,
    hash: 'SHA-256',
  }, key, 256);
  return [...new Uint8Array(bits)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

function sameHash(left: string, right: string): boolean {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return difference === 0;
}

export function isDemoPinEnabled(userId: string): boolean {
  return readRecord(userId) !== null;
}

export async function setDemoPin(userId: string, pin: string): Promise<void> {
  if (!/^\d{6}$/.test(pin)) throw new Error('PIN must be exactly 6 digits.');
  if (!globalThis.crypto?.subtle || !globalThis.crypto?.getRandomValues) throw new Error('Secure PIN storage is unavailable in this browser.');
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const record: PinRecord = {
    salt: [...salt].map(byte => byte.toString(16).padStart(2, '0')).join(''),
    hash: await hashPin(pin, salt),
  };
  localStorage.setItem(storageKey(userId), JSON.stringify(record));
}

export async function verifyDemoPin(userId: string, pin: string): Promise<boolean> {
  if (!/^\d{6}$/.test(pin)) return false;
  const record = readRecord(userId);
  if (!record) return false;
  if (!/^(?:[a-f\d]{2})+$/i.test(record.salt) || !/^[a-f\d]{64}$/i.test(record.hash)) {
    throw new Error('Saved demo verification data is invalid. Disable it after restoring valid local data.');
  }
  const salt = new Uint8Array(record.salt.match(/.{2}/g)!.map(byte => parseInt(byte, 16)));
  return sameHash(await hashPin(pin, salt), record.hash);
}

export function clearDemoPin(userId: string): void {
  localStorage.removeItem(storageKey(userId));
}