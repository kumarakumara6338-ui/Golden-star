export type CurrentUser = {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  authProvider?: 'firebase' | 'supabase' | 'demo';
};

export type ChatMessage = {
  id: number;
  text: string;
  createdAt?: number;
  status?: 'sent' | 'delivered' | 'seen';
  replyTo?: { id: number; text: string };
  forwarded?: boolean;
  attachmentId?: string;
  attachmentName?: string;
  attachmentType?: string;
};

export type Preferences = {
  lastSeen: 'everyone' | 'contacts' | 'nobody';
  photoPrivacy: 'everyone' | 'contacts' | 'nobody';
  notifications: { message: boolean; call: boolean; reels: boolean };
  darkMode: boolean;
  theme: 'gold' | 'amber' | 'champagne';
};

export const defaultPreferences: Preferences = {
  lastSeen: 'everyone',
  photoPrivacy: 'everyone',
  notifications: { message: true, call: true, reels: true },
  darkMode: true,
  theme: 'gold',
};