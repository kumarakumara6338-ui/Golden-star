export type Post = {
  id: number;
  creator: string;
  handle: string;
  initials: string;
  image: string;
  location: string;
  caption: string;
  likes: number;
  comments: number;
  shares: number;
  time: string;
  mine?: boolean;
  liked?: boolean;
};

export type Profile = { name: string; handle: string; bio: string };

export type AppData = {
  profile: Profile;
  posts: Post[];
  liked: number[];
  saved: number[];
  reelLiked: number[];
  comments: Record<number, string[]>;
  shares: Record<number, number>;
  reelShares: Record<number, number>;
  viewedStories: number[];
};

export function artwork(label: string, seed: number) {
  const palettes = [
    ['#f9dd63', '#8a6515', '#281705'],
    ['#e7b52e', '#572f16', '#110d0a'],
    ['#ffd700', '#9e3e1c', '#24130c'],
    ['#c89a25', '#241c10', '#070707'],
  ];
  const [bright, mid, dark] = palettes[seed % palettes.length];
  const safeLabel = label.replace(/[<>&"']/g, '').slice(0, 38);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 1100"><defs><linearGradient id="bg" x2="1" y2="1"><stop stop-color="${dark}"/><stop offset=".52" stop-color="${mid}"/><stop offset="1" stop-color="${bright}"/></linearGradient><radialGradient id="glow" cx=".78" cy=".18" r=".72"><stop stop-color="#fff3ad" stop-opacity=".92"/><stop offset=".35" stop-color="${bright}" stop-opacity=".28"/><stop offset="1" stop-color="${bright}" stop-opacity="0"/></radialGradient></defs><rect width="900" height="1100" fill="url(#bg)"/><circle cx="730" cy="180" r="250" fill="url(#glow)"/><path d="M-80 800 C150 620 250 1060 520 760 S850 510 980 660 L980 1160 L-80 1160Z" fill="#080706" opacity=".62"/><path d="M-50 640 C150 490 350 710 570 490 S820 250 980 330" fill="none" stroke="#fff0a0" stroke-opacity=".26" stroke-width="3"/><text x="58" y="1015" fill="#fff5c5" font-family="Arial,sans-serif" font-size="25" letter-spacing="3">${safeLabel.toUpperCase()}</text></svg>`;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}