import type { CurrentUser, Preferences } from './pro-types';
import { defaultPreferences } from './pro-types';

type Account = CurrentUser & { salt?: string; passwordHash?: string };
const accountsKey = 'golden-star-accounts';
const currentUserKey = 'currentUser';
const blockedKey = 'blockedUsers';

function accounts(): Account[] {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(accountsKey) || '[]');
    return Array.isArray(value) ? value.filter((item): item is Account => !!item && typeof item.id === 'string' && typeof item.name === 'string') : [];
  } catch { return []; }
}

function publicUser(account: Account): CurrentUser {
  return { id: account.id, name: account.name, ...(account.phone ? { phone: account.phone } : {}), ...(account.email ? { email: account.email } : {}) };
}

function startSession(account: Account): CurrentUser {
  const user = publicUser(account);
  localStorage.setItem(currentUserKey, JSON.stringify(user));
  return user;
}

export function getCurrentUser(): CurrentUser | null {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(currentUserKey) || 'null');
    if (!value || typeof value !== 'object' || !('id' in value) || typeof value.id !== 'string') return null;
    const account = accounts().find(item => item.id === value.id);
    return account ? publicUser(account) : null;
  } catch { return null; }
}

export function logout(): void {
  localStorage.removeItem(currentUserKey);
}

function normalizePhone(value: string): string {
  if (!/^\+?[\d\s()-]+$/.test(value)) throw new Error('Enter a valid mobile number.');
  const phone = value.replace(/\D/g, '');
  if (phone.length < 10 || phone.length > 15) throw new Error('Enter a mobile number with 10 to 15 digits.');
  return phone;
}

export function loginPhone(value: string): CurrentUser {
  const phone = normalizePhone(value);
  const found = accounts().find(account => account.phone === phone);
  if (found) return startSession(found);
  const account: Account = { id: crypto.randomUUID(), name: `+${phone}`, phone };
  localStorage.setItem(accountsKey, JSON.stringify([...accounts(), account]));
  return startSession(account);
}

async function hashPassword(password: string, salt: Uint8Array): Promise<string> {
  const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: Uint8Array.from(salt), iterations: 120000, hash: 'SHA-256' }, base, 256);
  return [...new Uint8Array(bits)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

export async function signupEmail(nameInput: string, emailInput: string, password: string): Promise<CurrentUser> {
  const name = nameInput.trim();
  const email = emailInput.trim().toLowerCase();
  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Enter your name and a valid email address.');
  if (password.length < 8) throw new Error('Password must be at least 8 characters.');
  if (accounts().some(account => account.email === email)) throw new Error('An account with this email already exists. Sign in instead.');
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const account: Account = { id: crypto.randomUUID(), name, email, salt: [...salt].map(byte => byte.toString(16).padStart(2,'0')).join(''), passwordHash: await hashPassword(password, salt) };
  localStorage.setItem(accountsKey, JSON.stringify([...accounts(), account]));
  return startSession(account);
}

export async function loginEmail(emailInput: string, password: string): Promise<CurrentUser> {
  const email = emailInput.trim().toLowerCase();
  const account = accounts().find(item => item.email === email && item.salt && item.passwordHash);
  if (!account?.salt || !account.passwordHash || !password) throw new Error('Incorrect email or password.');
  const salt = new Uint8Array(account.salt.match(/.{2}/g)!.map(byte => parseInt(byte, 16)));
  const hash = await hashPassword(password, salt);
  if (hash !== account.passwordHash) throw new Error('Incorrect email or password.');
  return startSession(account);
}

export function changeAccountName(id: string, nameInput: string): void {
  const name = nameInput.trim();
  if (!name) throw new Error('Name cannot be empty.');
  const updated = accounts().map(account => account.id === id ? { ...account, name } : account);
  localStorage.setItem(accountsKey, JSON.stringify(updated));
  const current = updated.find(account => account.id === id);
  if (current) startSession(current);
}

export function getBlockedUsers(id: string): string[] {
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(blockedKey) || '{}');
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return [];
    const list = (parsed as Record<string, unknown>)[id];
    return Array.isArray(list) ? list.filter((name): name is string => typeof name === 'string') : [];
  } catch { return []; }
}

export function setBlockedUsers(id: string, list: string[]): void {
  let all: Record<string, string[]> = {};
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(blockedKey) || '{}');
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) all = parsed as Record<string, string[]>;
  } catch { /* reset invalid local preferences */ }
  localStorage.setItem(blockedKey, JSON.stringify({ ...all, [id]: list }));
}

export function getPreferences(id: string): Preferences {
  try {
    const parsed = JSON.parse(localStorage.getItem(`golden-star-preferences:${id}`) || 'null') as Partial<Preferences> | null;
    return parsed ? { ...defaultPreferences, ...parsed, notifications: { ...defaultPreferences.notifications, ...parsed.notifications } } : defaultPreferences;
  } catch { return defaultPreferences; }
}

export function setPreferences(id: string, value: Preferences): void {
  localStorage.setItem(`golden-star-preferences:${id}`, JSON.stringify(value));
}

export function deleteLocalAccount(id: string): void {
  localStorage.setItem(accountsKey, JSON.stringify(accounts().filter(account => account.id !== id)));
  localStorage.removeItem(currentUserKey);
  localStorage.removeItem(`golden-star-v1:${id}`);
  localStorage.removeItem(`golden-star-preferences:${id}`);
  if (localStorage.getItem('golden-star-legacy-owner') === id) {
    localStorage.removeItem('golden-star-v1');
    localStorage.removeItem('golden-star-legacy-owner');
  }
  const blocked = JSON.parse(localStorage.getItem(blockedKey) || '{}') as Record<string, string[]>;
  if (blocked && typeof blocked === 'object' && !Array.isArray(blocked)) {
    delete blocked[id];
    localStorage.setItem(blockedKey, JSON.stringify(blocked));
  }
}