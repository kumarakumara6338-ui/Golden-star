import { useEffect, useState } from 'react';

const databaseName = 'golden-star-media';
const storeName = 'files';

function openMediaStore(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(databaseName, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(storeName);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveMedia(file: File): Promise<string> {
  const id = crypto.randomUUID();
  const db = await openMediaStore();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      tx.objectStore(storeName).put(file, id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
    return id;
  } finally {
    db.close();
  }
}

export async function removeMedia(id: string): Promise<void> {
  const db = await openMediaStore();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      tx.objectStore(storeName).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}

export function useMediaUrl(id?: string): string | null | undefined {
  const [url, setUrl] = useState<string | null | undefined>(undefined);
  useEffect(() => {
    if (!id) { setUrl(null); return; }
    setUrl(undefined);
    let cancelled = false;
    let objectUrl: string | null = null;
    openMediaStore().then(db => {
      const tx = db.transaction(storeName, 'readonly');
      const request = tx.objectStore(storeName).get(id);
      request.onsuccess = () => {
        if (request.result instanceof Blob && !cancelled) {
          objectUrl = URL.createObjectURL(request.result);
          setUrl(objectUrl);
        } else if (!cancelled) setUrl(null);
        db.close();
      };
      request.onerror = () => { if (!cancelled) setUrl(null); db.close(); };
    }).catch(() => { if (!cancelled) setUrl(null); });
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [id]);
  return url;
}