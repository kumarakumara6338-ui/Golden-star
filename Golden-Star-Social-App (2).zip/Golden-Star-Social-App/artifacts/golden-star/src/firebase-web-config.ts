export type FirebaseWebConfig = {
  apiKey: string;
  authDomain: string;
  projectId: string;
  appId: string;
  storageBucket?: string;
  messagingSenderId?: string;
  measurementId?: string;
};

export type FirebaseWebConfigParseResult = {
  config: FirebaseWebConfig | null;
  issue: string;
};

const configFields = [
  'apiKey',
  'authDomain',
  'projectId',
  'appId',
  'storageBucket',
  'messagingSenderId',
  'measurementId',
] as const;

function decodeConfigString(value: string): string | null {
  let decoded = '';
  for (let index = 0; index < value.length; index += 1) {
    const character = value[index];
    if (character !== '\\') {
      if (character === '\n' || character === '\r') return null;
      decoded += character;
      continue;
    }

    index += 1;
    if (index >= value.length) return null;
    const escaped = value[index];
    const simpleEscapes: Record<string, string> = {
      '"': '"',
      "'": "'",
      '\\': '\\',
      '/': '/',
      b: '\b',
      f: '\f',
      n: '\n',
      r: '\r',
      t: '\t',
      v: '\v',
      '0': '\0',
    };
    if (escaped in simpleEscapes) {
      if (escaped === '0' && /[0-9]/.test(value[index + 1] ?? '')) return null;
      decoded += simpleEscapes[escaped];
      continue;
    }
    if (escaped === '\n') continue;
    if (escaped === '\r') {
      if (value[index + 1] === '\n') index += 1;
      continue;
    }
    if (escaped === 'x') {
      const hex = value.slice(index + 1, index + 3);
      if (!/^[\da-f]{2}$/i.test(hex)) return null;
      decoded += String.fromCharCode(Number.parseInt(hex, 16));
      index += 2;
      continue;
    }
    if (escaped === 'u') {
      const hex = value.slice(index + 1, index + 5);
      if (!/^[\da-f]{4}$/i.test(hex)) return null;
      decoded += String.fromCharCode(Number.parseInt(hex, 16));
      index += 4;
      continue;
    }
    return null;
  }
  return decoded;
}

function extractConfigProperties(source: string): { values: Record<string, string>; issue: string } {
  const values: Record<string, string> = {};
  const fields = configFields.join('|');
  const propertyPattern = new RegExp(String.raw`(?:"(${fields})"|'(${fields})'|\b(${fields})\b)\s*:\s*(["'])((?:\\[\s\S]|(?!\4)[^\\])*)\4`, 'g');
  let match: RegExpExecArray | null;
  while ((match = propertyPattern.exec(source))) {
    const key = match[1] || match[2] || match[3];
    const decoded = decodeConfigString(match[5]);
    if (Object.hasOwn(values, key)) {
      return { values: {}, issue: `Firebase configuration contains duplicate ${key} fields. Remove duplicate keys.` };
    }
    if (decoded === null) {
      return { values: {}, issue: `Firebase configuration contains an invalid escaped string for ${key}.` };
    }
    values[key] = decoded;
  }
  return { values, issue: '' };
}

function getDuplicateJsonConfigFields(source: string): string[] {
  const duplicates = new Set<string>();
  const seen = new Set<string>();
  const whitespace = /\s/;
  let index = 0;
  const skipWhitespace = () => {
    while (whitespace.test(source[index] ?? '') && index < source.length) index += 1;
  };
  const skipString = (): string => {
    const start = index;
    index += 1;
    while (index < source.length) {
      if (source[index] === '\\') index += 2;
      else if (source[index++] === '"') break;
    }
    return source.slice(start, index);
  };

  skipWhitespace();
  if (source[index] !== '{') return [];
  index += 1;
  while (index < source.length) {
    skipWhitespace();
    if (source[index] === '}') break;
    if (source[index] !== '"') return [];
    let key: string;
    try {
      key = JSON.parse(skipString()) as string;
    } catch {
      return [];
    }
    skipWhitespace();
    if (source[index] !== ':') return [];
    index += 1;
    if ((configFields as readonly string[]).includes(key)) {
      if (seen.has(key)) duplicates.add(key);
      seen.add(key);
    }

    let depth = 0;
    let inString = false;
    while (index < source.length) {
      const character = source[index];
      if (inString) {
        if (character === '\\') index += 2;
        else {
          index += 1;
          if (character === '"') inString = false;
        }
        continue;
      }
      if (character === '"') {
        inString = true;
        index += 1;
      } else if (character === '{' || character === '[') {
        depth += 1;
        index += 1;
      } else if (character === '}' || character === ']') {
        if (depth === 0) break;
        depth -= 1;
        index += 1;
      } else if (character === ',' && depth === 0) {
        break;
      } else {
        index += 1;
      }
    }
    skipWhitespace();
    if (source[index] === ',') {
      index += 1;
      continue;
    }
    break;
  }
  return [...duplicates];
}

export function parseFirebaseWebConfig(source: unknown): FirebaseWebConfigParseResult {
  if (typeof source !== 'string' || !source.trim()) {
    return {
      config: null,
      issue: 'Firebase is not configured. Add VITE_FIREBASE_CONFIG with apiKey, authDomain, projectId, and appId.',
    };
  }

  let value: unknown;
  try {
    value = JSON.parse(source);
  } catch {
    const extracted = extractConfigProperties(source);
    if (extracted.issue) return { config: null, issue: extracted.issue };
    value = extracted.values;
  }
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return {
      config: null,
      issue: 'Firebase configuration must be a JSON object containing apiKey, authDomain, projectId, and appId.',
    };
  }

  const candidate = value as Record<string, unknown>;
  if (source.trimStart().startsWith('{')) {
    const duplicates = getDuplicateJsonConfigFields(source);
    if (duplicates.length) {
      return {
        config: null,
        issue: `Firebase configuration contains duplicate fields: ${duplicates.join(', ')}. Remove duplicate keys.`,
      };
    }
  }
  const required = ['apiKey', 'authDomain', 'projectId', 'appId'] as const;
  const missing = required.filter(key => typeof candidate[key] !== 'string' || !candidate[key].trim());
  if (missing.length) {
    return {
      config: null,
      issue: `Firebase configuration is missing required fields: ${missing.join(', ')}. Set VITE_FIREBASE_CONFIG to JSON or a Firebase console JavaScript SDK config snippet containing these fields.`,
    };
  }
  const invalidOptional = configFields.slice(4).filter(key => candidate[key] !== undefined && typeof candidate[key] !== 'string');
  if (invalidOptional.length) {
    return {
      config: null,
      issue: `Firebase configuration fields must be string values: ${invalidOptional.join(', ')}.`,
    };
  }

  const config: FirebaseWebConfig = {
    apiKey: candidate.apiKey as string,
    authDomain: candidate.authDomain as string,
    projectId: candidate.projectId as string,
    appId: candidate.appId as string,
  };
  for (const key of configFields.slice(4)) {
    if (typeof candidate[key] === 'string') config[key] = candidate[key];
  }
  return { config, issue: '' };
}