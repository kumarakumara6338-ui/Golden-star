import { removeMedia, saveMedia } from './media';
import type { YouTubeVideo } from './youtube';
import type { MusicTrack } from '@workspace/api-client-react';

export const MAX_REEL_BYTES = 25 * 1024 * 1024;

export type StoredReel = {
  id: string;
  creator: string;
  caption: string;
  mediaId: string;
  mediaType: 'image' | 'video';
  song?: YouTubeVideo;
  music?: MusicTrack;
  createdAt: number;
};

const key = (userId: string) => `golden-star:own-reels:${userId}`;

export function validateReelFile(file: File): string | null {
  if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) return 'Choose a photo or a video file.';
  if (file.size > MAX_REEL_BYTES) return 'File is larger than 25 MB.';
  return null;
}

export function loadReels(userId: string): StoredReel[] {
  try {
    const raw = JSON.parse(localStorage.getItem(key(userId)) || '[]');
    return Array.isArray(raw) ? raw.filter(r => r && typeof r.id === 'string' && typeof r.mediaId === 'string') : [];
  } catch {
    return [];
  }
}

function write(userId: string, reels: StoredReel[]) {
  localStorage.setItem(key(userId), JSON.stringify(reels)); // throws on failure
}

export async function publishReel(userId: string, creator: string, file: File, caption: string, song?: YouTubeVideo, music?: MusicTrack): Promise<StoredReel> {
  const problem = validateReelFile(file);
  if (problem) throw new Error(problem);
  if (music && !(music.provider === 'archive' && music.reelSafe && music.audioUrl && /^https:\/\/([a-z0-9-]+\.)*archive\.org\/download\//i.test(music.audioUrl))) throw new Error('This music track is not a valid archive download. Remove it and choose again.');
  let mediaId: string;
  try { mediaId = await saveMedia(file); } catch { throw new Error('Could not save the file in this browser. Reel not published.'); }
  const reel: StoredReel = {
    id: crypto.randomUUID(), creator, caption: caption.trim(), mediaId,
    mediaType: file.type.startsWith('video/') ? 'video' : 'image', song, ...(music ? { music } : {}), createdAt: Date.now(),
  };
  try {
    write(userId, [...loadReels(userId), reel]);
  } catch {
    await removeMedia(mediaId).catch(() => undefined);
    throw new Error('Browser storage is full or unavailable. Reel not published.');
  }
  return reel;
}

export async function deleteReel(userId: string, reelId: string): Promise<void> {
  const all = loadReels(userId);
  const target = all.find(r => r.id === reelId);
  if (!target) return;
  write(userId, all.filter(r => r.id !== reelId));
  saveOwnLikes(userId, loadOwnLikes(userId).filter(id => id !== reelId));
  await removeMedia(target.mediaId).catch(() => undefined);
}

export async function deleteAllOwnReels(userId: string): Promise<void> {
  const all = loadReels(userId);
  const failed: StoredReel[] = [];
  for (const reel of all) {
    try { await removeMedia(reel.mediaId); } catch { failed.push(reel); }
  }
  if (failed.length) {
    // keep metadata only for reels whose media could not be removed so a retry can finish the job
    write(userId, failed);
    throw new Error(`Could not delete ${failed.length} saved reel file(s) from this browser.`);
  }
  localStorage.removeItem(key(userId));
  localStorage.removeItem(likesKey(userId));
}

const likesKey = (userId: string) => `golden-star:own-reel-likes:${userId}`;

export function loadOwnLikes(userId: string): string[] {
  try {
    const raw = JSON.parse(localStorage.getItem(likesKey(userId)) || '[]');
    return Array.isArray(raw) ? raw.filter(x => typeof x === 'string') : [];
  } catch { return []; }
}

export function saveOwnLikes(userId: string, ids: string[]): boolean {
  try { localStorage.setItem(likesKey(userId), JSON.stringify(ids)); return true; } catch { return false; }
}

export function ownReelShareUrl(id: string): string {
  return `${window.location.origin}${import.meta.env.BASE_URL}reels/own/${encodeURIComponent(id)}`;
}

/** Cheap regression check: deleting one reel must leave every other id unchanged and in order. */
export function idsStableAfterDelete(userId: string, removedId: string): boolean {
  const expected = loadReels(userId).map(r => r.id).filter(id => id !== removedId);
  const actual = loadReels(userId).map(r => r.id);
  return expected.length === actual.length && expected.every((id, i) => id === actual[i]);
}
