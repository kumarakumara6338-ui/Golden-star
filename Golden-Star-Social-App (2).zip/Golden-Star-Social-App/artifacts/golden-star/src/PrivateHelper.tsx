import { useEffect, useRef, useState, type FormEvent } from 'react';
import { MessageCircle, Send, X, Trash2, ShieldCheck } from 'lucide-react';
import { getLocalAnswer, detectLocalLanguage, type LocalLanguage } from './private-helper-knowledge';

type Msg = { id: number; from: 'me' | 'bot'; text: string; at: number };
const LANGS: [LocalLanguage | 'auto', string][] = [['auto', 'Auto'], ['en', 'English'], ['kn', 'ಕನ್ನಡ'], ['hi', 'हिन्दी'], ['ta', 'தமிழ்'], ['te', 'తెలుగు'], ['ml', 'മലയാളം']];
const WELCOME = 'Hi! I answer app FAQs from a preset six-language list (English, Kannada, Hindi, Tamil, Telugu, Malayalam). Your messages stay in this widget and are not sent or saved. This is not generative AI. Any rewards information is unverified preset information; check the current app terms before relying on amounts or timing.';
let seq = 0;
const mk = (from: Msg['from'], text: string): Msg => ({ id: ++seq, from, text, at: Date.now() });

export default function PrivateHelper() {
  const [open, setOpen] = useState(false);
  const [lang, setLang] = useState<LocalLanguage | 'auto'>('auto');
  const [text, setText] = useState('');
  const [msgs, setMsgs] = useState<Msg[]>(() => [mk('bot', WELCOME)]);
  const btn = useRef<HTMLButtonElement>(null);
  const input = useRef<HTMLInputElement>(null);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => { if (open) input.current?.focus(); }, [open]);
  useEffect(() => { end.current?.scrollIntoView?.({ block: 'end' }); }, [msgs, open]);
  const close = () => { setOpen(false); window.setTimeout(() => btn.current?.focus(), 0); };
  const submit = (e: FormEvent) => {
    e.preventDefault();
    const v = text.trim();
    if (!v) return;
    const l = lang === 'auto' ? detectLocalLanguage(v) : lang;
    setMsgs((m) => [...m, mk('me', v), mk('bot', getLocalAnswer(v, l))].slice(-100));
    setText('');
  };
  const fmt = (t: number) => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (!open) return <button ref={btn} type="button" className="ph-launcher" data-testid="button-helper-open" aria-label="Open local FAQ helper" onClick={() => setOpen(true)}><MessageCircle size={26} aria-hidden="true" /></button>;
  return (
    <div className="ph-panel" role="dialog" aria-modal="false" aria-label="Golden Star AI local helper" data-testid="panel-helper" onKeyDown={(e) => { if (e.key === 'Escape') close(); }}>
      <header className="ph-head">
        <ShieldCheck size={20} color="#25d366" aria-hidden="true" />
        <div><h2>Golden Star AI</h2><p data-testid="text-helper-label">Local • No AI API fees</p></div>
        <select className="ph-sel" value={lang} onChange={(e) => setLang(e.target.value as LocalLanguage | 'auto')} aria-label="Helper language" data-testid="select-helper-language">
          {LANGS.map(([k, n]) => <option key={k} value={k}>{n}</option>)}
        </select>
        <button type="button" className="ph-ib" aria-label="Clear chat" data-testid="button-helper-clear" onClick={() => setMsgs([mk('bot', WELCOME)])}><Trash2 size={16} aria-hidden="true" /></button>
        <button type="button" className="ph-ib" aria-label="Close helper" data-testid="button-helper-close" onClick={close}><X size={18} aria-hidden="true" /></button>
      </header>
      <div className="ph-msgs" data-testid="list-helper-messages" aria-live="polite">
        {msgs.map((m) => <div key={m.id} className={`ph-m ${m.from}`} data-testid={`message-helper-${m.id}`}>{m.text}<time>{fmt(m.at)}</time></div>)}
        <div ref={end} />
      </div>
      <form className="ph-form" onSubmit={submit}>
        <input ref={input} value={text} maxLength={1000} onChange={(e) => setText(e.target.value)} placeholder="Type a question" aria-label="Your question" data-testid="input-helper-message" />
        <button type="submit" className="ph-send" aria-label="Send" data-testid="button-helper-send"><Send size={16} aria-hidden="true" /></button>
      </form>
    </div>
  );
}
