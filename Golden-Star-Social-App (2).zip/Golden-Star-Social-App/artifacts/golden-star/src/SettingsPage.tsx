import { useEffect, useState, type FormEvent } from 'react';
import LogoSettings from './LogoSettings';
import BrandLogo from './BrandLogo';
import { ArrowLeft, Bell, Camera, ChevronRight, CircleHelp, Eye, HardDrive, LogOut, Palette, Settings2, Share2, Shield, Star, Trash2, UserRound } from 'lucide-react';
import type { CurrentUser, Preferences } from './pro-types';
import { languages, type Language } from './i18n';
import { clearDemoPin, isDemoPinEnabled, setDemoPin as storeDemoPin, verifyDemoPin } from './demo-security';
import './pro.css';

type SettingsPageProps = {
  user: CurrentUser;
  profile: { name: string; handle: string; bio: string; photoId?: string };
  photoUrl?: string | null;
  blockedUsers: string[];
  preferences: Preferences;
  language: Language;
  onLanguage: (value: Language) => void;
  onPreferences: (value: Preferences) => void;
  onNameChange: (name: string) => void;
  onPhotoChange: () => void;
  onUnblock: (name: string) => void;
  onClearChats: () => void;
  onClearCache: () => void;
  onLogout: () => void;
  onDelete: () => void;
  onShare: () => void;
  onBack: () => void;
};

const sectionLinks = [
  { id: 'account', label: 'Account', icon: UserRound },
  { id: 'privacy', label: 'Privacy', icon: Shield },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'appearance', label: 'Appearance', icon: Palette },
  { id: 'storage', label: 'Storage', icon: HardDrive },
  { id: 'about', label: 'About', icon: CircleHelp },
] as const;

function Toggle({ label, checked, onChange, testId }: { label: string; checked: boolean; onChange: () => void; testId: string }) {
  return <button type="button" className="gs-settings-switch" role="switch" aria-label={label} aria-checked={checked} onClick={onChange} data-testid={testId} />;
}

export default function SettingsPage({
  user, profile, photoUrl, blockedUsers, preferences, language,
  onLanguage, onPreferences, onNameChange, onPhotoChange, onUnblock,
  onClearChats, onClearCache, onLogout, onDelete, onShare, onBack,
}: SettingsPageProps) {
  const [editingName, setEditingName] = useState(false);
  const [nameDraft, setNameDraft] = useState(profile.name);
  const [disclosure, setDisclosure] = useState<'help' | 'terms' | null>(null);
  const [nameError, setNameError] = useState('');
  const [demoPinEnabled, setDemoPinEnabled] = useState(false);
  const [demoPinMode, setDemoPinMode] = useState<'setup' | 'disable' | null>(null);
  const [demoPin, setDemoPin] = useState('');
  const [demoPinConfirm, setDemoPinConfirm] = useState('');
  const [demoPinError, setDemoPinError] = useState('');
  const [demoPinNotice, setDemoPinNotice] = useState('');
  const [demoPinPending, setDemoPinPending] = useState(false);
  const setPreference = <K extends keyof Preferences>(key: K, value: Preferences[K]) => onPreferences({ ...preferences, [key]: value });
  const setNotification = (key: keyof Preferences['notifications']) => onPreferences({ ...preferences, notifications: { ...preferences.notifications, [key]: !preferences.notifications[key] } });
  const confirmAction = (message: string, action: () => void) => { if (window.confirm(message)) action(); };
  const isLocalDemo = user.id.startsWith('demo-phone-');

  useEffect(() => {
    if (!isLocalDemo) return;
    try {
      setDemoPinEnabled(isDemoPinEnabled(user.id));
      setDemoPinError('');
    } catch (cause) {
      setDemoPinError(cause instanceof Error ? cause.message : 'Could not read local demo verification settings.');
    }
  }, [isLocalDemo, user.id]);

  function saveName(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const next = nameDraft.trim();
    if (!next) { setNameError('Name cannot be empty.'); return; }
    onNameChange(next);
    setEditingName(false);
    setNameError('');
  }

  async function saveDemoSecurity(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!isLocalDemo || !demoPinMode) return;
    setDemoPinPending(true);
    setDemoPinError('');
    setDemoPinNotice('');
    try {
      if (demoPinMode === 'setup') {
        if (!/^\d{6}$/.test(demoPin)) throw new Error('PIN must be exactly 6 digits.');
        if (demoPin !== demoPinConfirm) throw new Error('PINs do not match.');
        await storeDemoPin(user.id, demoPin);
        setDemoPinEnabled(true);
        setDemoPinNotice('Local demo two-step verification is enabled. The PIN is stored as a WebCrypto-derived hash on this device.');
      } else {
        if (!await verifyDemoPin(user.id, demoPin)) throw new Error('Incorrect PIN. Try again.');
        clearDemoPin(user.id);
        setDemoPinEnabled(false);
        setDemoPinNotice('Local demo two-step verification is disabled.');
      }
      setDemoPinMode(null);
      setDemoPin('');
      setDemoPinConfirm('');
    } catch (cause) {
      setDemoPinError(cause instanceof Error ? cause.message : 'Could not update local demo verification.');
    } finally {
      setDemoPinPending(false);
    }
  }

  return (
    <div className={`gs-pro gs-settings ${preferences.darkMode ? '' : 'gs-settings-light'} gs-settings-theme-${preferences.theme}`}>
      <div className="gs-settings-wrap">
        <header className="gs-settings-top">
          <div className="gs-brand"><span className="gs-brand-icon"><BrandLogo size={15} /></span> Golden Star Pro</div>
          <button type="button" className="gs-quiet" onClick={onBack} data-testid="button-back-settings"><ArrowLeft size={16} /> Back to profile</button>
        </header>
        <div className="gs-settings-heading"><p className="gs-kicker">Your space / Your rules</p><h1>Settings<span style={{ color: 'var(--pro-gold)' }}>.</span></h1><p>Make your corner of Golden Star Pro feel like yours.</p></div>
        <div className="gs-settings-grid">
          <nav className="gs-settings-nav" aria-label="Settings sections">
            {sectionLinks.map(({ id, label, icon: Icon }) => <a href={`#${id}`} key={id} data-testid={`link-settings-${id}`}><Icon /> {label}</a>)}
          </nav>
          <div className="gs-settings-main">
            <section className="gs-settings-section" id="account" aria-labelledby="gs-account-title">
              <div className="gs-settings-section-head"><span><UserRound size={17} /></span><h2 id="gs-account-title">Account</h2></div>
              <div className="gs-settings-panel">
                <div className="gs-settings-account">
                  <div className="gs-settings-avatar" data-testid="img-profile-photo">{photoUrl ? <img src={photoUrl} alt={`${profile.name}'s profile`} /> : profile.name.trim().slice(0, 2).toUpperCase()}</div>
                  <div className="gs-settings-account-copy"><strong data-testid="text-profile-name">{profile.name}</strong><small data-testid="text-profile-handle">{profile.handle}</small></div>
                  <button type="button" className="gs-settings-action" onClick={onPhotoChange} data-testid="button-change-photo"><Camera size={13} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 5 }} />Change photo</button>
                </div>
                <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Display name</strong><small>How you appear to the rest of the circle</small></div>
                  {editingName ? <form className="gs-settings-name-form" onSubmit={saveName}><input autoFocus maxLength={80} aria-label="Display name" value={nameDraft} onChange={event => { setNameDraft(event.target.value); setNameError(''); }} data-testid="input-display-name" /><button type="submit" data-testid="button-save-name">Save</button><button type="button" onClick={() => { setEditingName(false); setNameError(''); }} data-testid="button-cancel-name">Cancel</button></form> : <button type="button" className="gs-settings-action" onClick={() => { setNameDraft(profile.name); setEditingName(true); }} data-testid="button-edit-name">Edit</button>}
                </div>
                {nameError && <div className="gs-settings-details" role="alert" data-testid="status-name-error">{nameError}</div>}
                 <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Phone number</strong><small>Connected to this account</small></div><span className="gs-settings-row-value" data-testid="text-account-phone">{user.phone || 'Not added'}</span></div>
                 <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Email address</strong><small>Connected to this account</small></div><span className="gs-settings-row-value" data-testid="text-account-email">{user.email || 'Not added'}</span></div>
                <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Log out</strong><small>Come back whenever you like</small></div><button type="button" className="gs-settings-action gs-settings-danger" onClick={onLogout} data-testid="button-logout"><LogOut size={13} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 5 }} />Log out</button></div>
                 <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Delete account</strong><small>Permanently remove your shared account and this device's saved posts, chats and media</small></div><button type="button" className="gs-settings-action gs-settings-danger" onClick={() => confirmAction('Permanently delete your shared account and the posts, photos, chat history and attachments saved on this device? This cannot be undone.', onDelete)} data-testid="button-delete-account"><Trash2 size={13} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 5 }} />Delete</button></div>
              </div>
            </section>

            <section className="gs-settings-section" id="privacy" aria-labelledby="gs-privacy-title">
              <div className="gs-settings-section-head"><span><Shield size={17} /></span><h2 id="gs-privacy-title">Privacy</h2></div>
              <div className="gs-settings-panel">
                <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Last seen</strong><small>Who can see when you were last around</small></div><select aria-label="Last seen privacy" value={preferences.lastSeen} onChange={event => setPreference('lastSeen', event.target.value as Preferences['lastSeen'])} data-testid="select-last-seen"><option value="everyone">Everyone</option><option value="contacts">Contacts</option><option value="nobody">Nobody</option></select></div>
                <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Profile photo</strong><small>Choose who sees your picture</small></div><select aria-label="Profile photo privacy" value={preferences.photoPrivacy} onChange={event => setPreference('photoPrivacy', event.target.value as Preferences['photoPrivacy'])} data-testid="select-photo-privacy"><option value="everyone">Everyone</option><option value="contacts">Contacts</option><option value="nobody">Nobody</option></select></div>
                <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Blocked accounts</strong><small>People you've removed from your circle</small></div><span className="gs-settings-row-value" data-testid="text-blocked-count">{blockedUsers.length}</span></div>
                {blockedUsers.length === 0 ? <div className="gs-settings-empty" data-testid="status-no-blocked-users">No blocked accounts. Your circle is open.</div> : blockedUsers.map((blocked, index) => <div className="gs-settings-blocked" key={`${blocked}-${index}`}><strong data-testid={`text-blocked-user-${index}`}>{blocked}</strong><button type="button" className="gs-settings-action" onClick={() => onUnblock(blocked)} data-testid={`button-unblock-${index}`}>Unblock</button></div>)}
                 <p className="gs-settings-details">These choices are saved locally. Other people cannot see this browser-only profile or last-seen state.</p>
                  {isLocalDemo && <>
                    <div className="gs-settings-row">
                      <div className="gs-settings-row-copy"><strong>Local demo two-step verification</strong><small>Browser-only PIN challenge after the demo phone OTP. This is not MFA for a real account.</small></div>
                      <button type="button" className="gs-settings-action" onClick={() => { setDemoPinMode(demoPinEnabled ? 'disable' : 'setup'); setDemoPin(''); setDemoPinConfirm(''); setDemoPinError(''); setDemoPinNotice(''); }} data-testid="button-demo-two-step">{demoPinEnabled ? 'Disable' : 'Set up'}</button>
                    </div>
                    {demoPinMode && <form className="grid gap-3 border-t border-[var(--pro-line)] px-4 py-4 sm:px-5" onSubmit={saveDemoSecurity} data-testid="form-demo-two-step">
                      <p className="m-0 text-xs leading-relaxed text-[var(--pro-muted)]">{demoPinMode === 'setup' ? 'Choose a six-digit PIN and confirm it. Only a salted WebCrypto-derived hash is saved locally.' : 'Enter your current six-digit PIN to disable the local demo challenge.'}</p>
                      <label className="grid gap-2 text-xs font-bold text-[var(--pro-ink)]">{demoPinMode === 'setup' ? 'Create 6-digit PIN' : 'Current 6-digit PIN'}
                        <input required inputMode="numeric" pattern="[0-9]{6}" maxLength={6} autoComplete="new-password" value={demoPin} onChange={event => setDemoPin(event.target.value.replace(/\D/g, '').slice(0, 6))} className="w-full rounded-lg border border-[var(--pro-line)] bg-[var(--pro-raised)] px-3 py-2.5 text-sm text-[var(--pro-ink)]" />
                      </label>
                      {demoPinMode === 'setup' && <label className="grid gap-2 text-xs font-bold text-[var(--pro-ink)]">Confirm 6-digit PIN
                        <input required inputMode="numeric" pattern="[0-9]{6}" maxLength={6} autoComplete="new-password" value={demoPinConfirm} onChange={event => setDemoPinConfirm(event.target.value.replace(/\D/g, '').slice(0, 6))} className="w-full rounded-lg border border-[var(--pro-line)] bg-[var(--pro-raised)] px-3 py-2.5 text-sm text-[var(--pro-ink)]" />
                      </label>}
                      <div className="flex flex-wrap gap-2">
                        <button type="submit" className="gs-settings-action" disabled={demoPinPending}>{demoPinPending ? 'Saving…' : demoPinMode === 'setup' ? 'Save PIN' : 'Verify and disable'}</button>
                        <button type="button" className="gs-settings-action" onClick={() => { setDemoPinMode(null); setDemoPinError(''); setDemoPin(''); setDemoPinConfirm(''); }}>Cancel</button>
                      </div>
                    </form>}
                    {demoPinError && <p className="gs-settings-details m-0 text-red-300" role="alert" data-testid="status-demo-two-step-error">{demoPinError}</p>}
                    {demoPinNotice && <p className="gs-settings-details m-0" role="status" data-testid="status-demo-two-step-notice">{demoPinNotice}</p>}
                  </>}
              </div>
            </section>

            <section className="gs-settings-section" id="notifications" aria-labelledby="gs-notifications-title">
              <div className="gs-settings-section-head"><span><Bell size={17} /></span><h2 id="gs-notifications-title">Notifications</h2></div>
              <div className="gs-settings-panel">
                {([
                  ['message', 'Messages', 'Know when someone reaches out'],
                  ['call', 'Calls', 'Never miss a conversation'],
                  ['reels', 'Reels', 'Fresh clips from your circle'],
                ] as const).map(([key, title, description]) => <div className="gs-settings-row" key={key}><div className="gs-settings-row-copy"><strong>{title}</strong><small>{description}</small></div><Toggle label={`${title} notifications`} checked={preferences.notifications[key]} onChange={() => setNotification(key)} testId={`switch-notifications-${key}`} /></div>)}
                 <p className="gs-settings-details">Saved as preferences. This local demo does not receive live message, call or reel notifications.</p>
              </div>
            </section>

            <section className="gs-settings-section" id="appearance" aria-labelledby="gs-appearance-title">
              <div className="gs-settings-section-head"><span><Palette size={17} /></span><h2 id="gs-appearance-title">Appearance</h2></div>
              <div className="gs-settings-panel">
                <LogoSettings />
                <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Language</strong><small>The words around your feed</small></div><select aria-label="Language" value={language} onChange={event => onLanguage(event.target.value as Language)} data-testid="select-settings-language">{languages.map(value => <option key={value} value={value}>{value}</option>)}</select></div>
                <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Dark mode</strong><small>The familiar after-hours look</small></div><Toggle label="Dark mode" checked={preferences.darkMode} onChange={() => setPreference('darkMode', !preferences.darkMode)} testId="switch-dark-mode" /></div>
                <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Theme</strong><small>Your accent, your atmosphere</small></div><select aria-label="Theme" value={preferences.theme} onChange={event => setPreference('theme', event.target.value as Preferences['theme'])} data-testid="select-settings-theme"><option value="gold">Golden</option><option value="amber">Amber</option><option value="champagne">Champagne</option></select></div>
              </div>
            </section>

            <section className="gs-settings-section" id="storage" aria-labelledby="gs-storage-title">
              <div className="gs-settings-section-head"><span><HardDrive size={17} /></span><h2 id="gs-storage-title">Storage</h2></div>
              <div className="gs-settings-panel">
                 <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Clear chats</strong><small>Remove your saved conversations and attachments from this device</small></div><button type="button" className="gs-settings-action" onClick={() => confirmAction('Permanently clear all saved chats and chat attachments from this browser? This cannot be undone.', onClearChats)} data-testid="button-clear-chats">Clear chats</button></div>
                 <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Clear cache</strong><small>Clear temporary app data; saved posts and chats stay</small></div><button type="button" className="gs-settings-action" onClick={onClearCache} data-testid="button-clear-cache">Clear cache</button></div>
              </div>
            </section>

            <section className="gs-settings-section" id="about" aria-labelledby="gs-about-title">
              <div className="gs-settings-section-head"><span><Settings2 size={17} /></span><h2 id="gs-about-title">About</h2></div>
              <div className="gs-settings-panel">
                <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Version</strong><small>Golden Star Pro for the web</small></div><span className="gs-settings-row-value" data-testid="text-app-version">1.0.0</span></div>
                <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Help</strong><small>Answers for your time here</small></div><button type="button" className="gs-settings-action" aria-expanded={disclosure === 'help'} onClick={() => setDisclosure(disclosure === 'help' ? null : 'help')} data-testid="button-help">Read <ChevronRight size={12} style={{ display: 'inline', verticalAlign: 'middle' }} /></button></div>
                {disclosure === 'help' && <div className="gs-settings-details" data-testid="panel-help"><p>Having trouble signing in? Check your email and password, or use the phone preview flow with code 123456. For profile and privacy changes, use the controls above. Your account settings are managed in this browser session.</p></div>}
                <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Terms</strong><small>The ground rules of the circle</small></div><button type="button" className="gs-settings-action" aria-expanded={disclosure === 'terms'} onClick={() => setDisclosure(disclosure === 'terms' ? null : 'terms')} data-testid="button-terms">Read <ChevronRight size={12} style={{ display: 'inline', verticalAlign: 'middle' }} /></button></div>
                {disclosure === 'terms' && <div className="gs-settings-details" data-testid="panel-terms"><p>Share only content you have the right to post. Be respectful of other members, their work, and their privacy. You can manage your own account and locally stored data in these settings.</p></div>}
                <div className="gs-settings-row"><div className="gs-settings-row-copy"><strong>Share Golden Star</strong><small>Bring someone into the circle</small></div><button type="button" className="gs-settings-action" onClick={onShare} data-testid="button-share-app"><Share2 size={13} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 5 }} />Share app</button></div>
              </div>
              <p className="gs-settings-footer"><Eye size={12} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 5 }} />You decide what stays, what goes, and who gets to see it.</p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}