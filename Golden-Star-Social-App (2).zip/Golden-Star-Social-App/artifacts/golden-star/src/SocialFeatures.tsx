import { useEffect, useState, type FormEvent } from 'react';
import { MoreHorizontal, X } from 'lucide-react';
import { getLocalSocialCounts } from './social';

export type FollowButtonProps = {
  name: string;
  following: boolean;
  onToggle: (name: string) => void;
  disabled?: boolean;
};

export function FollowButton({ name, following, onToggle, disabled = false }: FollowButtonProps) {
  return (
    <button
      type="button"
      aria-pressed={following}
      disabled={disabled}
      onClick={() => onToggle(name)}
      className={`inline-flex min-h-10 items-center justify-center rounded-full px-5 py-2 text-sm font-semibold transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FFD700] disabled:cursor-not-allowed disabled:opacity-50 ${
        following
          ? 'border border-[#FFD700]/50 bg-[#171511] text-[#FFD700] hover:bg-[#29251b]'
          : 'border border-[#FFD700] bg-[#FFD700] text-black hover:bg-[#f1c900]'
      }`}
    >
      {following ? 'Following' : 'Follow'}
    </button>
  );
}

export type SocialProfileDialogProps = {
  name: string;
  photo?: string;
  following: boolean;
  onFollow: () => void;
  blocked: boolean;
  onBlock: () => void;
  onReport: (reason: string) => void;
  onClose: () => void;
};

const reportReasons = [
  'Spam',
  'Harassment or bullying',
  'Inappropriate content',
  'Impersonation',
  'Other',
];

function initials(name: string): string {
  return name.trim().split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]?.toUpperCase()).join('') || '?';
}

export function SocialProfileDialog({
  name,
  photo,
  following,
  onFollow,
  blocked,
  onBlock,
  onReport,
  onClose,
}: SocialProfileDialogProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [reporting, setReporting] = useState(false);
  const [reason, setReason] = useState(reportReasons[0]);
  const [reportMessage, setReportMessage] = useState('');
  const counts = getLocalSocialCounts(name, following);

  useEffect(() => {
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [onClose]);

  function submitReport(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    try {
      onReport(reason);
      setReporting(false);
      setReportMessage('Report saved locally on this device. It was not sent to a moderation service.');
    } catch {
      setReportMessage('The report could not be saved on this device. It was not sent.');
    }
  }

  function toggleBlocked() {
    onBlock();
    setMenuOpen(false);
  }

  return (
    <div
      className="fixed inset-0 z-[100] flex items-end justify-center overflow-y-auto bg-black/75 p-0 backdrop-blur-sm sm:items-center sm:p-4"
      onMouseDown={event => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby="social-profile-title"
        className="relative w-full max-w-md rounded-t-3xl border border-[#413716] bg-[#11100d] p-6 text-[#f3eee1] shadow-2xl sm:rounded-3xl"
      >
        <button
          type="button"
          aria-label="Close profile"
          onClick={onClose}
          className="absolute right-4 top-4 inline-flex h-10 w-10 items-center justify-center rounded-full text-[#c7c0b2] hover:bg-white/10 hover:text-white"
        >
          <X size={20} aria-hidden="true" />
        </button>

        <div className="absolute right-16 top-4">
          <button
            type="button"
            aria-label="More profile options"
            aria-haspopup="menu"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(open => !open)}
            className="inline-flex h-10 w-10 items-center justify-center rounded-full text-[#c7c0b2] hover:bg-white/10 hover:text-white"
          >
            <MoreHorizontal size={22} aria-hidden="true" />
          </button>
          {menuOpen && (
            <div role="menu" className="absolute right-0 top-12 z-10 w-52 overflow-hidden rounded-xl border border-white/10 bg-[#1b1914] p-1 shadow-xl">
              <button
                type="button"
                role="menuitem"
                onClick={toggleBlocked}
                className="block min-h-11 w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-white/10"
              >
                {blocked ? 'Unblock User' : 'Block User'}
              </button>
              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  setMenuOpen(false);
                  setReportMessage('');
                  setReporting(true);
                }}
                className="block min-h-11 w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-white/10"
              >
                Report User
              </button>
            </div>
          )}
        </div>

        <div className="flex flex-col items-center pt-4 text-center">
          {photo ? (
            <img src={photo} alt="" className="h-24 w-24 rounded-full border-2 border-[#FFD700]/70 object-cover" />
          ) : (
            <div aria-hidden="true" className="grid h-24 w-24 place-items-center rounded-full border-2 border-[#FFD700]/70 bg-[#272216] text-2xl font-bold text-[#FFD700]">
              {initials(name)}
            </div>
          )}
          <h2 id="social-profile-title" className="mt-4 max-w-full break-words text-xl font-semibold">{name}</h2>
          {blocked && <p className="mt-1 text-sm text-[#c7c0b2]">This user is blocked.</p>}
          <div className="mt-5 flex w-full max-w-xs items-center justify-center gap-8 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3">
            <div>
              <strong className="block text-lg tabular-nums">{counts.followers}</strong>
              <span className="text-xs text-[#a7a092]">Local followers</span>
            </div>
            <div aria-hidden="true" className="h-8 w-px bg-white/10" />
            <div>
              <strong className="block text-lg tabular-nums">{counts.following}</strong>
              <span className="text-xs text-[#a7a092]">Local following</span>
            </div>
          </div>
          <p className="mt-2 text-center text-xs text-[#817b70]">Counts are saved on this device only.</p>
          <FollowButton name={name} following={following} onToggle={onFollow} disabled={blocked} />
        </div>

        {reportMessage && (
          <p role="status" className="mt-5 rounded-xl border border-[#FFD700]/20 bg-[#FFD700]/[0.06] p-3 text-sm text-[#e6d898]">
            {reportMessage}
          </p>
        )}

        {reporting && (
          <form onSubmit={submitReport} className="mt-6 border-t border-white/10 pt-5">
            <h3 className="text-base font-semibold">Report {name}</h3>
            <label htmlFor="social-report-reason" className="mt-4 block text-sm text-[#c7c0b2]">Choose a reason</label>
            <select
              id="social-report-reason"
              value={reason}
              onChange={event => setReason(event.target.value)}
              className="mt-2 min-h-12 w-full rounded-xl border border-white/15 bg-[#1b1914] px-3 text-sm text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#FFD700]"
            >
              {reportReasons.map(item => <option key={item} value={item}>{item}</option>)}
            </select>
            <p className="mt-3 text-xs leading-relaxed text-[#a7a092]">
              This test feature stores your report locally. It does not send it to a moderation service.
            </p>
            <div className="mt-4 flex justify-end gap-3">
              <button type="button" onClick={() => setReporting(false)} className="min-h-11 rounded-full px-4 text-sm text-[#c7c0b2] hover:bg-white/10">
                Cancel
              </button>
              <button type="submit" className="min-h-11 rounded-full bg-[#FFD700] px-5 text-sm font-semibold text-black hover:bg-[#f1c900]">
                Save report
              </button>
            </div>
          </form>
        )}
      </section>
    </div>
  );
}