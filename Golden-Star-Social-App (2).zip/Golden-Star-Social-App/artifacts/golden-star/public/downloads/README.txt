Golden Star Pro — updated existing app source

App.tsx.txt is the complete updated application entry file.
golden-star-updated-source.zip also includes the supporting frontend modules,
styles, package configuration, and the existing live token API source.
App.tsx is not standalone: use the included modules in the existing project.

Current features:
- Firebase phone login uses real reCAPTCHA and SMS OTP verification.
- Firebase email accounts use Firebase login and password-reset emails.
- Existing Supabase email accounts and recovery are preserved separately.
- The optional Demo test tab is clearly separate: OTP 123456 sends no SMS.
- Firebase and Supabase accounts can request authenticated Agora Live tokens.
- Demo Go Live is visibly a local camera preview, not a shared broadcast.
- Create Reel accepts gallery photos/videos, caption, and YouTube song search.
- Reels and uploaded app logos persist in this browser's IndexedDB storage.
- Selected songs play through the official YouTube embed, separately from
  the reel media. No song audio is extracted, mixed, or exported.
- Settings / Appearance supports logo upload/reset without changing the name.
- Music discovery uses live Internet Archive metadata and iTunes store search.
  Results load 50 at a time in a virtualized list; no dummy songs are generated.
  Archive totals count matching recordings/albums, not verified playable songs.
  Only Archive items with explicit CC0/Public Domain metadata can be selected;
  the uploader's declaration is not an independent copyright clearance.
  iTunes previews are promotional-only and cannot be attached to reels/posts.
  Archive MP3s stream separately from reel media and are not mixed or exported.
- The green local helper is the only assistant. It uses six-language preset
  FAQ answers without sending or saving chat messages. It is not generative AI.
  Reward amounts and payout timing in its preset copy are unverified.
- Follows, reports, blocked-user filtering, and chat remain browser-local.
- Chat explicitly says end-to-end encryption is not enabled.

No secrets, tokens, credentials, environment values, or private user data are
included. Supabase, Agora, Firebase web configuration, and YouTube API access
are required for their real services. No external AI API key is needed.
Enable Firebase Phone and Email/Password providers and authorize the app's
domain. The mock OTP never authenticates a real Supabase or Firebase account.