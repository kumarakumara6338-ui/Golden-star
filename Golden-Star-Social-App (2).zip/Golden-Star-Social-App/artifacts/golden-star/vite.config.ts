import path from 'path';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { defineConfig, loadEnv } from 'vite';
import { parseFirebaseWebConfig } from './src/firebase-web-config';

import runtimeErrorOverlay from '@replit/vite-plugin-runtime-error-modal';

const rawPort = process.env.PORT;

if (!rawPort) {
  throw new Error(
    'PORT environment variable is required but was not provided.',
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const basePath = process.env.BASE_PATH;

if (!basePath) {
  throw new Error(
    'BASE_PATH environment variable is required but was not provided.',
  );
}

const appRoot = path.resolve(import.meta.dirname);
const plugins = [
  react(),
  tailwindcss(),
  runtimeErrorOverlay(),
  ...(process.env.NODE_ENV !== 'production' &&
  process.env.REPL_ID !== undefined
    ? [
        await import('@replit/vite-plugin-cartographer').then((m) =>
          m.cartographer({
            root: path.resolve(import.meta.dirname, '..'),
          }),
        ),
        await import('@replit/vite-plugin-dev-banner').then((m) =>
          m.devBanner(),
        ),
      ]
    : []),
];

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, appRoot, '');
  const rawFirebaseConfig = process.env.VITE_FIREBASE_CONFIG ?? env.VITE_FIREBASE_CONFIG;
  const { config } = parseFirebaseWebConfig(rawFirebaseConfig);
  const safeFirebaseConfig = JSON.stringify(JSON.stringify(config ?? {}));

  return {
    base: basePath,
    define: {
      'import.meta.env.VITE_FIREBASE_CONFIG': safeFirebaseConfig,
    },
    envPrefix: ['VITE_SUPABASE_', 'VITE_AGORA_'],
    plugins,
    resolve: {
      alias: {
        '@': path.resolve(appRoot, 'src'),
        '@assets': path.resolve(
          appRoot,
          '..',
          '..',
          'attached_assets',
        ),
      },
      dedupe: ['react', 'react-dom'],
    },
    root: appRoot,
    build: {
      outDir: path.resolve(appRoot, 'dist/public'),
      emptyOutDir: true,
    },
    server: {
      port,
      strictPort: true,
      host: '0.0.0.0',
      allowedHosts: true,
      fs: {
        strict: true,
      },
    },
    preview: {
      port,
      host: '0.0.0.0',
      allowedHosts: true,
    },
  };
});
