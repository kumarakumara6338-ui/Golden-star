import { Router, type IRouter } from "express";
import {
  ResolveMusicTrackQueryParams,
  ResolveMusicTrackResponse,
  SearchMusicQueryParams,
  SearchMusicResponse,
} from "@workspace/api-zod";
import { checkRateLimit } from "../lib/rate-limit";

const router: IRouter = Router();
const archivePageSize = 50;
const maximumArchivePagesPerSearch = 10;
const maximumCacheEntries = 100;
const cacheTtlMs = 5 * 60_000;
const archiveAudioProbeTimeoutMs = 12_000;
const maximumArchiveAudioProbeCandidates = 5;
const cache = new Map<string, { expiresAt: number; value: unknown }>();
const inFlight = new Map<string, Promise<unknown>>();

const publicDomainLicenseSearchUrls = [
  "https://creativecommons.org/publicdomain/zero/1.0/",
  "https://creativecommons.org/publicdomain/mark/1.0/",
];

const archiveLanguages: Record<string, { codes: string[]; words: string[] }> = {
  Kannada: { codes: ["kan", "kn"], words: ["Kannada"] },
  Hindi: { codes: ["hin", "hi"], words: ["Hindi"] },
  Tamil: { codes: ["tam", "ta"], words: ["Tamil"] },
  Telugu: { codes: ["tel", "te"], words: ["Telugu"] },
  Malayalam: { codes: ["mal", "ml"], words: ["Malayalam"] },
  English: { codes: ["eng", "en"], words: ["English"] },
};

const archiveMusicSignal =
  /\b(music|song|soundtrack|score|instrument(?:al)?|musical|concert|album|devotional|bhajan|anthem|chant|folk|classical|opera|jazz|rock|pop|choir|singer|vocal)\b/i;
const excludedAudioSignal =
  /\b(podcast|audio[\s_-]*book|audiobook|talk[\s_-]*show|talk[\s_-]*radio|radio[\w-]*programs?|radio[\w-]*shows?)\b/i;

type MusicQuery = {
  q: string;
  language: "all" | "Kannada" | "Hindi" | "Tamil" | "Telugu" | "Malayalam" | "English";
  source: "archive" | "itunes";
  category: "all" | "trending" | "no-copyright";
  limit: number;
  offset: number;
};

type ArchiveSearchDocument = {
  identifier?: unknown;
  title?: unknown;
  creator?: unknown;
  uploader?: unknown;
  licenseurl?: unknown;
  language?: unknown;
  collection?: unknown;
  subject?: unknown;
};

type ArchiveSearchPage = {
  response?: {
    numFound?: unknown;
    start?: unknown;
    docs?: unknown;
  };
};

function stringField(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined;
  const normalized = value.trim();
  return normalized ? normalized : undefined;
}

function stringList(value: unknown): string[] {
  if (Array.isArray(value)) {
    return value.flatMap((entry) => {
      const normalized = stringField(entry);
      return normalized ? [normalized] : [];
    });
  }
  const normalized = stringField(value);
  return normalized ? [normalized] : [];
}

function metadataString(value: unknown, maximumLength: number): string | undefined {
  const result = stringList(value).join(", ").trim();
  return result ? result.slice(0, maximumLength) : undefined;
}

function validArchiveIdentifier(value: unknown): value is string {
  return typeof value === "string" &&
    /^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/.test(value) &&
    value !== "." &&
    value !== "..";
}

function archiveLicense(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined;
  const licenseUrl = value.trim();
  const match = /^https?:\/\/creativecommons\.org\/publicdomain\/(zero|mark)\/1\.0\/?$/i.exec(licenseUrl);
  if (!match) return undefined;
  return match[1].toLocaleLowerCase() === "zero"
    ? "Archive metadata declares CC0 1.0 Universal"
    : "Archive metadata declares Public Domain Mark 1.0";
}

function normalizeLanguage(value: unknown, requestedLanguage: MusicQuery["language"]): string {
  if (requestedLanguage !== "all") return requestedLanguage;
  const tags = stringList(value);
  for (const [language, details] of Object.entries(archiveLanguages)) {
    if (tags.some((tag) => [...details.codes, ...details.words].some(
      (entry) => tag.toLocaleLowerCase() === entry.toLocaleLowerCase(),
    ))) {
      return language;
    }
  }
  return tags[0] ?? "Unknown";
}

function isMusicRelated(document: ArchiveSearchDocument): boolean {
  const subjects = stringList(document.subject);
  const collections = stringList(document.collection);
  if ([...subjects, ...collections].some((entry) => excludedAudioSignal.test(entry))) {
    return false;
  }
  return subjects.some((entry) => archiveMusicSignal.test(entry)) ||
    collections.some((entry) => /\b(netlabels|etree|hifidelity_soundtracks)\b/i.test(entry));
}

function archiveArtist(document: ArchiveSearchDocument): string {
  return metadataString(document.creator, 500) ??
    metadataString(document.uploader, 500) ??
    "Unknown artist";
}

function archiveTrackFromSearch(
  document: ArchiveSearchDocument,
  language: MusicQuery["language"],
): Record<string, unknown> | undefined {
  const id = stringField(document.identifier);
  const title = metadataString(document.title, 2_000);
  const license = archiveLicense(document.licenseurl);
  if (
    !validArchiveIdentifier(id) ||
    !title ||
    !license ||
    !isMusicRelated(document)
  ) {
    return undefined;
  }
  return {
    id,
    provider: "archive",
    title,
    artist: archiveArtist(document),
    sourceUrl: `https://archive.org/details/${id}`,
    license,
    reelSafe: true,
    language: normalizeLanguage(document.language, language),
  };
}

function escapeArchivePhrase(value: string): string {
  return value.replaceAll("\\", "\\\\").replaceAll("\"", "\\\"");
}

function archiveSearchQuery(query: MusicQuery): string {
  const licenseClause = publicDomainLicenseSearchUrls
    .map((license) => `licenseurl:"${license}"`)
    .join(" OR ");
  const musicClause = [
    "subject:music",
    "subject:song",
    "subject:soundtrack",
    "subject:instrumental",
    "subject:musical",
    "subject:devotional",
    "subject:bhajan",
    "subject:anthem",
    "subject:chant",
    "subject:folk",
    "subject:classical",
    "subject:jazz",
    "subject:rock",
    "subject:pop",
    "subject:choir",
    "subject:vocal",
    "collection:netlabels",
    "collection:etree",
    "collection:hifidelity_soundtracks",
  ].join(" OR ");
  const clauses = [
    "mediatype:audio",
    `(${licenseClause})`,
    `(${musicClause})`,
    "NOT collection:podcasts",
    "NOT collection:radio",
    "NOT collection:radio_programs",
    "NOT collection:radioprograms",
    "NOT subject:podcast",
    "NOT subject:audiobook",
    "NOT subject:\"audio book\"",
    "NOT subject:\"talk show\"",
  ];
  if (query.q) clauses.push(`"${escapeArchivePhrase(query.q)}"`);
  if (query.language !== "all") {
    const language = archiveLanguages[query.language];
    clauses.push(`language:(${[...language.codes, ...language.words].join(" OR ")})`);
  }
  return clauses.join(" AND ");
}

function providerUrl(base: string, params: Record<string, string>): URL {
  const url = new URL(base);
  for (const [name, value] of Object.entries(params)) {
    url.searchParams.set(name, value);
  }
  return url;
}

function trimExpiredCache(now: number): void {
  for (const [key, entry] of cache) {
    if (entry.expiresAt <= now) cache.delete(key);
  }
}

async function cached<T>(key: string, load: () => Promise<T>): Promise<T> {
  const now = Date.now();
  const existing = cache.get(key);
  if (existing && existing.expiresAt > now) {
    cache.delete(key);
    cache.set(key, existing);
    return existing.value as T;
  }
  if (existing) cache.delete(key);
  const pending = inFlight.get(key);
  if (pending) return pending as Promise<T>;

  const request = load().then((value) => {
    trimExpiredCache(Date.now());
    while (cache.size >= maximumCacheEntries) {
      const oldest = cache.keys().next().value;
      if (oldest === undefined) break;
      cache.delete(oldest);
    }
    cache.set(key, { expiresAt: Date.now() + cacheTtlMs, value });
    return value;
  }).finally(() => {
    inFlight.delete(key);
  });
  inFlight.set(key, request);
  return request;
}

async function fetchArchivePage(
  query: string,
  page: number,
  trending: boolean,
): Promise<ArchiveSearchPage> {
  const key = `archive-page:${JSON.stringify([query, page, trending])}`;
  return cached(key, async () => {
    const url = providerUrl("https://archive.org/advancedsearch.php", {
      q: query,
      "fl[]": "identifier,title,creator,uploader,licenseurl,language,collection,subject",
      rows: String(archivePageSize),
      page: String(page),
      output: "json",
    });
    url.searchParams.delete("fl[]");
    url.searchParams.append("fl[]", "identifier");
    url.searchParams.append("fl[]", "title");
    url.searchParams.append("fl[]", "creator");
    url.searchParams.append("fl[]", "uploader");
    url.searchParams.append("fl[]", "licenseurl");
    url.searchParams.append("fl[]", "language");
    url.searchParams.append("fl[]", "collection");
    url.searchParams.append("fl[]", "subject");
    if (trending) url.searchParams.append("sort[]", "downloads desc");
    else url.searchParams.append("sort[]", "identifier asc");

    const response = await fetch(url, { signal: AbortSignal.timeout(12_000) });
    if (!response.ok) throw new Error(`Internet Archive search returned HTTP ${response.status}`);
    const payload: unknown = await response.json();
    if (!payload || typeof payload !== "object") {
      throw new Error("Internet Archive returned an invalid search response");
    }
    const body = payload as ArchiveSearchPage;
    if (!body.response || !Array.isArray(body.response.docs)) {
      throw new Error("Internet Archive returned an invalid search response");
    }
    const numFound = body.response.numFound;
    if (
      (typeof numFound !== "number" && typeof numFound !== "string") ||
      !Number.isSafeInteger(Number(numFound)) ||
      Number(numFound) < 0
    ) {
      throw new Error("Internet Archive returned an invalid result count");
    }
    return body;
  });
}

async function searchArchive(query: MusicQuery): Promise<Record<string, unknown>> {
  const searchQuery = archiveSearchQuery(query);
  const responseItems: { position: number; track: Record<string, unknown> }[] = [];
  const firstPageIndex = Math.floor(query.offset / archivePageSize);
  const skipInFirstPage = query.offset % archivePageSize;
  let lastScannedOffset = query.offset;
  let providerHasMore = false;
  let pagesRead = 0;
  let total: number | undefined;

  for (let pageIndex = firstPageIndex; pagesRead < maximumArchivePagesPerSearch; pageIndex++, pagesRead++) {
    const pageNumber = pageIndex + 1;
    const result = await fetchArchivePage(searchQuery, pageNumber, query.category === "trending");
    const docs = result.response?.docs as ArchiveSearchDocument[];
    const count = Number(result.response?.numFound ?? 0);
    total = count;
    const pageStart = pageIndex * archivePageSize;
    const firstDocument = pageIndex === firstPageIndex ? skipInFirstPage : 0;

    for (let index = firstDocument; index < docs.length; index++) {
      const position = pageStart + index;
      lastScannedOffset = position + 1;
      const track = archiveTrackFromSearch(docs[index], query.language);
      if (!track) continue;
      responseItems.push({ position, track });
      if (responseItems.length > query.limit) break;
    }

    if (responseItems.length > query.limit) {
      providerHasMore = true;
      break;
    }
    if (pageStart + docs.length >= count || docs.length < archivePageSize) {
      providerHasMore = false;
      break;
    }
    providerHasMore = true;
    if (pagesRead + 1 >= maximumArchivePagesPerSearch) break;
  }

  const items = responseItems.slice(0, query.limit).map(({ track }) => track);
  const hasMore = responseItems.length > query.limit || providerHasMore;
  const nextOffset = hasMore
    ? responseItems.length > query.limit
      ? responseItems[query.limit - 1].position + 1
      : Math.max(query.offset + 1, lastScannedOffset)
    : undefined;
  return {
    items,
    ...(nextOffset !== undefined ? { nextOffset } : {}),
    hasMore,
    source: "archive",
    ...(total !== undefined ? { total } : {}),
    notice: "Archive.org total counts metadata-matching recordings, not playable MP3 tracks; matches may include albums or items without a usable MP3. CC0 and Public Domain Mark values are uploader-declared metadata, not an independent rights guarantee.",
  };
}

function appleHttpsUrl(value: unknown, allowedSuffixes: string[]): string | undefined {
  const candidate = stringField(value);
  if (!candidate) return undefined;
  try {
    const url = new URL(candidate);
    if (
      url.protocol !== "https:" ||
      !allowedSuffixes.some((suffix) => url.hostname === suffix || url.hostname.endsWith(`.${suffix}`))
    ) {
      return undefined;
    }
    return url.toString();
  } catch {
    return undefined;
  }
}

function normalizeItunesTrack(
  value: unknown,
  language: MusicQuery["language"],
): Record<string, unknown> | undefined {
  if (!value || typeof value !== "object") return undefined;
  const track = value as Record<string, unknown>;
  const rawId = track.trackId;
  const id = typeof rawId === "number" && Number.isSafeInteger(rawId) && rawId > 0
    ? String(rawId)
    : typeof rawId === "string" && /^\d{1,20}$/.test(rawId)
      ? rawId
      : undefined;
  const title = stringField(track.trackName);
  const artist = stringField(track.artistName);
  const sourceUrl = appleHttpsUrl(track.trackViewUrl, ["apple.com"]);
  if (!id || !title || !artist || !sourceUrl) return undefined;

  const artworkUrl = appleHttpsUrl(track.artworkUrl100, ["apple.com", "mzstatic.com"]);
  const audioUrl = appleHttpsUrl(track.previewUrl, ["itunes.apple.com"]);
  return {
    id,
    provider: "itunes",
    title: title.slice(0, 2_000),
    artist: artist.slice(0, 500),
    ...(artworkUrl ? { artworkUrl } : {}),
    sourceUrl,
    ...(audioUrl ? { audioUrl } : {}),
    license: "Copyrighted promotional preview — not licensed for reels",
    reelSafe: false,
    language: language === "all" ? "Unknown" : language,
  };
}

async function fetchItunesTracks(query: MusicQuery): Promise<Record<string, unknown>[]> {
  const term = query.q
    ? `${query.q}${query.language === "all" ? "" : ` ${query.language}`}`
    : query.language === "all"
      ? "music"
      : `${query.language} music`;
  const country = query.language === "English" ? "US" : "IN";
  const key = `itunes-results:${JSON.stringify([term.toLocaleLowerCase(), country])}`;
  return cached(key, async () => {
    const url = providerUrl("https://itunes.apple.com/search", {
      term,
      country,
      media: "music",
      entity: "song",
      limit: "200",
    });
    const response = await fetch(url, { signal: AbortSignal.timeout(12_000) });
    if (!response.ok) throw new Error(`iTunes search returned HTTP ${response.status}`);
    const payload: unknown = await response.json();
    if (!payload || typeof payload !== "object" || !Array.isArray((payload as { results?: unknown }).results)) {
      throw new Error("iTunes returned an invalid search response");
    }
    return ((payload as { results: unknown[] }).results)
      .slice(0, 200)
      .flatMap((result) => {
        const track = normalizeItunesTrack(result, query.language);
        return track ? [track] : [];
      });
  });
}

async function searchItunes(query: MusicQuery): Promise<Record<string, unknown>> {
  const tracks = await fetchItunesTracks(query);
  const items = tracks.slice(query.offset, query.offset + query.limit);
  const hasMore = query.offset + items.length < tracks.length;
  return {
    items,
    ...(hasMore ? { nextOffset: query.offset + items.length } : {}),
    hasMore,
    source: "itunes",
    notice: "iTunes previews are copyrighted promotional previews and are not licensed for reels. At most 200 provider results are available per query; no global total is reported.",
  };
}

function saneArchiveFilename(value: unknown): string | undefined {
  const name = stringField(value);
  if (
    !name ||
    name.length > 512 ||
    name.startsWith("/") ||
    name.includes("\\") ||
    /[\u0000-\u001f\u007f]/.test(name) ||
    !name.toLocaleLowerCase().endsWith(".mp3")
  ) {
    return undefined;
  }
  const parts = name.split("/");
  if (parts.some((part) => !part || part === "." || part === "..")) return undefined;
  return name;
}

function isPrivateFile(value: unknown): boolean {
  if (value === true) return true;
  const normalized = stringField(value)?.toLocaleLowerCase();
  return normalized === "true" || normalized === "1" || normalized === "yes";
}

function archiveDownloadUrl(identifier: string, filename: string): string {
  const encodedPath = filename.split("/").map((part) => encodeURIComponent(part)).join("/");
  return `https://archive.org/download/${encodeURIComponent(identifier)}/${encodedPath}`;
}

type ArchiveMp3File = Record<string, unknown>;

function archiveMp3FileGroups(value: unknown): ArchiveMp3File[][] {
  if (!Array.isArray(value)) return [];
  const groups = new Map<string, ArchiveMp3File[]>();
  for (const rawFile of value) {
    if (!rawFile || typeof rawFile !== "object") continue;
    const file = rawFile as ArchiveMp3File;
    const name = saneArchiveFilename(file.name);
    if (!name || isPrivateFile(file.private)) continue;
    const format = stringField(file.format);
    if (format && !/\bmp3\b/i.test(format)) continue;
    const size = Number(file.size);
    if (!Number.isFinite(size) || size <= 0) continue;
    const logicalTrack = stringField(file.original) ?? name;
    const group = groups.get(logicalTrack) ?? [];
    group.push(file);
    groups.set(logicalTrack, group);
  }
  return [...groups.values()].map((group) =>
    group.sort((left, right) => compareArchiveMp3Files(left, right)),
  );
}

function compareArchiveMp3Files(left: ArchiveMp3File, right: ArchiveMp3File): number {
  function rank(file: ArchiveMp3File): number {
    const source = stringField(file.source)?.toLocaleLowerCase();
    if (source === "original") return 0;
    if (metadataString(file.title, 2_000)) return 1;
    const name = saneArchiveFilename(file.name);
    const original = stringField(file.original);
    if (!name || !original) return 3;
    const nameStem = name.split("/").at(-1)?.replace(/\.[^.]+$/, "").toLocaleLowerCase();
    const originalStem = original.split("/").at(-1)?.replace(/\.[^.]+$/, "").toLocaleLowerCase();
    return nameStem && nameStem === originalStem ? 2 : 3;
  }
  return rank(left) - rank(right);
}

async function archiveMp3IsReachable(url: string, signal: AbortSignal): Promise<boolean> {
  const response = await fetch(url, {
    headers: { Range: "bytes=0-0" },
    signal,
  });
  try {
    if (response.status === 206) {
      const contentRange = response.headers.get("content-range") ?? "";
      const contentType = response.headers.get("content-type")?.toLocaleLowerCase() ?? "";
      const rangeMatch = /^bytes 0-(\d+)\/(\d+)$/.exec(contentRange);
      const rangeEnd = rangeMatch ? Number(rangeMatch[1]) : Number.NaN;
      const rangeTotal = rangeMatch ? Number(rangeMatch[2]) : Number.NaN;
      const validRange =
        Number.isSafeInteger(rangeEnd) &&
        Number.isSafeInteger(rangeTotal) &&
        rangeEnd >= 0 &&
        rangeTotal > rangeEnd;
      const audioContent =
        !contentType ||
        contentType.startsWith("audio/") ||
        contentType.includes("octet-stream");
      return validRange && audioContent;
    }

    if (response.status === 200) {
      const contentLength = Number(response.headers.get("content-length"));
      const contentType = response.headers.get("content-type")?.toLocaleLowerCase() ?? "";
      return Number.isFinite(contentLength) &&
        contentLength > 0 &&
        (contentType.startsWith("audio/") || contentType.includes("octet-stream"));
    }

    if (response.status === 429 || response.status >= 500) {
      throw new Error(`Archive audio returned HTTP ${response.status}`);
    }
    return false;
  } finally {
    await response.body?.cancel().catch(() => {});
  }
}

type ArchiveMetadata = {
  metadata?: Record<string, unknown>;
  files?: unknown;
};

async function resolveArchiveTrack(identifier: string): Promise<Record<string, unknown> | undefined> {
  const key = `archive-metadata:${identifier}`;
  return cached(key, async () => {
    const url = new URL(`https://archive.org/metadata/${encodeURIComponent(identifier)}`);
    const response = await fetch(url, { signal: AbortSignal.timeout(12_000) });
    if (response.status === 404) return undefined;
    if (!response.ok) throw new Error(`Internet Archive metadata returned HTTP ${response.status}`);
    const payload: unknown = await response.json();
    if (!payload || typeof payload !== "object") {
      throw new Error("Internet Archive returned invalid item metadata");
    }
    const archive = payload as ArchiveMetadata;
    const metadata = archive.metadata;
    if (
      !metadata ||
      stringField(metadata.identifier) !== identifier ||
      stringField(metadata.mediatype)?.toLocaleLowerCase() !== "audio" ||
      !archiveLicense(metadata.licenseurl) ||
      isMusicExcluded(metadata)
    ) {
      return undefined;
    }

    const mp3Groups = archiveMp3FileGroups(archive.files);
    const mp3Files = mp3Groups.flat();
    if (mp3Files.length === 0) return undefined;
    let selectedFile: Record<string, unknown> | undefined;
    let fileProbeError: unknown;
    const probeCandidates = mp3Files.slice(0, maximumArchiveAudioProbeCandidates);
    const probeSignal = AbortSignal.timeout(archiveAudioProbeTimeoutMs);
    for (const candidate of probeCandidates) {
      if (probeSignal.aborted) break;
      const candidateName = saneArchiveFilename(candidate.name);
      if (!candidateName) continue;
      try {
        if (await archiveMp3IsReachable(archiveDownloadUrl(identifier, candidateName), probeSignal)) {
          selectedFile = candidate;
          break;
        }
      } catch (error) {
        fileProbeError = error;
        if (probeSignal.aborted) break;
      }
    }
    if (!selectedFile && (fileProbeError || mp3Files.length > probeCandidates.length)) {
      throw new Error("Archive audio availability could not be verified", { cause: fileProbeError });
    }
    if (!selectedFile) return undefined;
    const filename = saneArchiveFilename(selectedFile.name);
    const license = archiveLicense(metadata.licenseurl);
    if (!filename || !license) return undefined;
    const filenameTitle = filename.split("/").at(-1)?.replace(/\.mp3$/i, "").trim();
    const title =
      metadataString(selectedFile.title, 2_000) ??
      (mp3Groups.length === 1 ? metadataString(metadata.title, 2_000) : undefined) ??
      (filenameTitle ? filenameTitle.slice(0, 2_000) : undefined);
    if (!title) return undefined;

    return {
      id: identifier,
      provider: "archive",
      title,
      artist:
        metadataString(selectedFile.artist, 500) ??
        metadataString(selectedFile.creator, 500) ??
        metadataString(metadata.creator, 500) ??
        metadataString(metadata.uploader, 500) ??
        "Unknown artist",
      sourceUrl: `https://archive.org/details/${identifier}`,
      audioUrl: archiveDownloadUrl(identifier, filename),
      license,
      reelSafe: true,
      language: normalizeLanguage(metadata.language, "all"),
    };
  });
}

function isMusicExcluded(metadata: Record<string, unknown>): boolean {
  const subjects = stringList(metadata.subject);
  const collections = stringList(metadata.collection);
  return [...subjects, ...collections].some((entry) => excludedAudioSignal.test(entry));
}

router.get("/search-music", async (req, res): Promise<void> => {
  const limit = checkRateLimit(req, null, "music", 30, 60_000);
  if (!limit.allowed) {
    res.setHeader("Retry-After", String(limit.retryAfterSeconds));
    res.status(429).json({ error: "Too many music requests. Please try again shortly." });
    return;
  }

  const rawStringParameters = ["q", "language", "source", "category"];
  if (rawStringParameters.some((key) => req.query[key] !== undefined && typeof req.query[key] !== "string")) {
    res.status(400).json({ error: "Music search parameters must each be supplied once." });
    return;
  }
  const rawNumberParameters = ["limit", "offset"];
  if (rawNumberParameters.some((key) => req.query[key] !== undefined && typeof req.query[key] !== "string")) {
    res.status(400).json({ error: "Limit and offset must be single integer values." });
    return;
  }
  const parsed = SearchMusicQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Music search parameters are invalid." });
    return;
  }
  const query: MusicQuery = {
    ...parsed.data,
    q: parsed.data.q.trim(),
  };
  if (query.q.length > 100) {
    res.status(400).json({ error: "Search text must be at most 100 characters." });
    return;
  }
  const source = query.category === "no-copyright" ? "archive" : query.source;
  const effectiveQuery = { ...query, source };
  const cacheKey = `music-search:${JSON.stringify(effectiveQuery)}`;

  try {
    const result = await cached(cacheKey, () =>
      effectiveQuery.source === "itunes"
        ? searchItunes(effectiveQuery)
        : searchArchive(effectiveQuery),
    );
    res.json(SearchMusicResponse.parse(result));
  } catch (error) {
    req.log.warn({ error: error instanceof Error ? error.message : "unknown provider error" }, "Music search provider failed");
    res.status(503).json({ error: "Music search is temporarily unavailable from the selected provider." });
  }
});

router.get("/music/resolve", async (req, res): Promise<void> => {
  const limit = checkRateLimit(req, null, "music", 30, 60_000);
  if (!limit.allowed) {
    res.setHeader("Retry-After", String(limit.retryAfterSeconds));
    res.status(429).json({ error: "Too many music requests. Please try again shortly." });
    return;
  }
  if (typeof req.query.id !== "string") {
    res.status(400).json({ error: "A single Archive.org item id is required." });
    return;
  }
  const parsed = ResolveMusicTrackQueryParams.safeParse(req.query);
  if (!parsed.success || !validArchiveIdentifier(parsed.data.id)) {
    res.status(400).json({ error: "The Archive.org item id is invalid." });
    return;
  }

  try {
    const track = await resolveArchiveTrack(parsed.data.id);
    if (!track) {
      res.status(404).json({ error: "This Archive.org item does not have an eligible MP3 with matching license metadata." });
      return;
    }
    res.json(ResolveMusicTrackResponse.parse(track));
  } catch (error) {
    req.log.warn({ error: error instanceof Error ? error.message : "unknown provider error" }, "Music track resolution failed");
    res.status(503).json({ error: "Archive.org metadata or audio availability could not be verified right now." });
  }
});

export default router;