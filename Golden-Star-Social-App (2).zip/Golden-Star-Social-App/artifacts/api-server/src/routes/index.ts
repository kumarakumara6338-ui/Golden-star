import { Router, type IRouter } from "express";
import healthRouter from "./health";
import liveRouter from "./live";
import musicRouter from "./music";
import youtubeRouter from "./youtube";

const router: IRouter = Router();

router.use(healthRouter);
router.use(liveRouter);
router.use(musicRouter);
router.use(youtubeRouter);

export default router;
