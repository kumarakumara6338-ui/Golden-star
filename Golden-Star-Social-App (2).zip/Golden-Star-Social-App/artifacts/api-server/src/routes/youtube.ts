import { Router, type IRouter } from "express";
import {
  SearchYouTubeQueryParams,
  SearchYouTubeResponse,
} from "@workspace/api-zod";
import { verifyAppIdentity } from "../lib/app-identity";
import { checkRateLimit } from "../lib/rate-limit";

const router: IRouter = Router();
const cacheTtlMs = 60_000;
const maximumCacheEntries = 100;
const cache = new Map<string, { expiresAt: number; value: unknown }>();

function stringField(value: unknown): string | undefined {
  return typeof value === "string" ? value : undefined;
}

function decodeEntities(value: string): string {
  return value.replace(/&(?:#(\d+)|#x([0-9a-f]+)|(amp|lt|gt|quot|apos));/gi, (entity, decimal, hexadecimal, named) => {
    if (decimal || hexadecimal) {
      const codePoint = Number.parseInt(decimal ?? hexadecimal, decimal ? 10 : 16);
      if (codePoint > 0 && codePoint <= 0x10ffff && (codePoint < 0xd800 || codePoint > 0xdfff)) {
        return String.fromCodePoint(codePoint);
      }
      return entity;
    }
    const replacements: Record<string, string> = {
      amp: "&",
      lt: "<",
      gt: ">",
      quot: "\"",
      apos: "'",
    };
    return replacements[String(named).toLowerCase()] ?? entity;
  });
}

function getReason(payload: unknown): string | undefined {
  if (!payload || typeof payload !== "object") return undefined;
  const error = (payload as { error?: unknown }).error;
  if (!error || typeof error !== "object") return undefined;
  const errors = (error as { errors?: unknown }).errors;
  if (!Array.isArray(errors) || !errors[0] || typeof errors[0] !== "object") {
    return undefined;
  }
  return stringField((errors[0] as { reason?: unknown }).reason);
}

function normalizeResults(payload: unknown): unknown {
  if (!payload || typeof payload !== "object") {
    throw new Error("Invalid YouTube response");
  }
  const response = payload as {
    items?: unknown;
    nextPageToken?: unknown;
  };
  if (!Array.isArray(response.items)) {
    throw new Error("Invalid YouTube response");
  }

  const items = response.items.flatMap((rawItem) => {
    if (!rawItem || typeof rawItem !== "object") return [];
    const item = rawItem as {
      id?: { videoId?: unknown };
      snippet?: {
        title?: unknown;
        channelTitle?: unknown;
        thumbnails?: {
          high?: { url?: unknown };
          medium?: { url?: unknown };
          default?: { url?: unknown };
        };
      };
    };
    const id = stringField(item.id?.videoId);
    const rawTitle = stringField(item.snippet?.title);
    const rawChannel = stringField(item.snippet?.channelTitle);
    const title = rawTitle ? decodeEntities(rawTitle) : undefined;
    const channel = rawChannel ? decodeEntities(rawChannel) : undefined;
    const thumbnail = stringField(
      item.snippet?.thumbnails?.high?.url ??
      item.snippet?.thumbnails?.medium?.url ??
      item.snippet?.thumbnails?.default?.url,
    );
    if (
      !id || id.length > 100 ||
      !title || title.length > 1_000 ||
      !channel || channel.length > 500 ||
      !thumbnail
    ) return [];
    try {
      if (new URL(thumbnail).protocol !== "https:") return [];
    } catch {
      return [];
    }
    return [{ id, title, channel, thumbnail }];
  });

  const nextPageToken = stringField(response.nextPageToken);
  return {
    items,
    ...(nextPageToken ? { nextPageToken } : {}),
  };
}

router.get("/youtube/search", async (req, res): Promise<void> => {
  const authorization = req.get("authorization");
  const identity = authorization ? await verifyAppIdentity(req) : null;
  const limit = checkRateLimit(req, identity, "youtube-search", 20, 60_000);
  if (!limit.allowed) {
    res.setHeader("Retry-After", String(limit.retryAfterSeconds));
    res.status(429).json({ error: "Too many searches. Please try again shortly." });
    return;
  }
  if (authorization && !identity) {
    res.status(401).json({ error: "Your sign-in could not be verified." });
    return;
  }

  if (typeof req.query.q !== "string" ||
    (req.query.pageToken !== undefined && typeof req.query.pageToken !== "string")) {
    res.status(400).json({ error: "A single search query and page token are required." });
    return;
  }
  const parsed = SearchYouTubeQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Search text must be between 1 and 100 characters." });
    return;
  }
  const query = parsed.data.q.trim();
  const pageToken = parsed.data.pageToken;
  if (query.length < 1 || query.length > 100) {
    res.status(400).json({ error: "Search text must be between 1 and 100 characters." });
    return;
  }

  const apiKey = process.env.VITE_YOUTUBE_API_KEY;
  if (!apiKey) {
    res.status(503).json({ error: "YouTube search is not configured." });
    return;
  }

  const cacheKey = JSON.stringify([query.toLowerCase(), pageToken ?? ""]);
  const cached = cache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) {
    res.json(SearchYouTubeResponse.parse(cached.value));
    return;
  }
  if (cached) cache.delete(cacheKey);

  const url = new URL("https://www.googleapis.com/youtube/v3/search");
  url.searchParams.set("part", "snippet");
  url.searchParams.set("type", "video");
  url.searchParams.set("maxResults", "10");
  url.searchParams.set("videoCategoryId", "10");
  url.searchParams.set("videoEmbeddable", "true");
  url.searchParams.set("q", query);
  url.searchParams.set("key", apiKey);
  if (pageToken) url.searchParams.set("pageToken", pageToken);

  try {
    const upstream = await fetch(url, { signal: AbortSignal.timeout(8_000) });
    if (!upstream.ok) {
      let reason: string | undefined;
      try {
        reason = getReason(await upstream.json());
      } catch {
        // Provider error payloads are intentionally not returned or logged.
      }
      if (reason === "quotaExceeded" || reason === "dailyLimitExceeded" || reason === "rateLimitExceeded") {
        res.status(503).json({ error: "YouTube search quota is temporarily exhausted." });
        return;
      }
      if (reason === "keyInvalid" || reason === "accessNotConfigured") {
        res.status(503).json({ error: "YouTube search is not configured correctly." });
        return;
      }
      req.log.warn({ status: upstream.status }, "YouTube search provider request failed");
      res.status(503).json({ error: "YouTube search is temporarily unavailable." });
      return;
    }

    let data: unknown;
    try {
      data = normalizeResults(await upstream.json());
    } catch {
      res.status(503).json({ error: "YouTube search returned an invalid response." });
      return;
    }
    const result = SearchYouTubeResponse.parse(data);
    if (cache.size >= maximumCacheEntries) {
      const now = Date.now();
      for (const [key, entry] of cache) {
        if (entry.expiresAt <= now) cache.delete(key);
      }
      if (cache.size >= maximumCacheEntries) {
        cache.delete(cache.keys().next().value as string);
      }
    }
    cache.set(cacheKey, { expiresAt: Date.now() + cacheTtlMs, value: result });
    res.json(result);
  } catch {
    req.log.warn("YouTube search timed out or could not be reached");
    res.status(503).json({ error: "YouTube search is temporarily unavailable." });
  }
});

export default router;