import { createHmac, randomInt, timingSafeEqual } from "node:crypto";
import { Router, type IRouter } from "express";
import { RtcRole, RtcTokenBuilder } from "agora-token";
import {
  IssueLiveTokenBody,
  IssueLiveTokenResponse,
} from "@workspace/api-zod";
import { verifyAppIdentity } from "../lib/app-identity";

const router: IRouter = Router();
function signRoom(hostId: string, expiresAt: number, secret: string) {
  return createHmac("sha256", secret).update(`${hostId}:${expiresAt}`).digest("base64url");
}
function validRoomProof(hostId: string, proof: unknown, secret: string): boolean {
  if (typeof proof !== "string") return false;
  const match = /^(\d{10})\.([A-Za-z0-9_-]{43})$/.exec(proof);
  if (!match) return false;
  const expiresAt = Number(match[1]);
  if (expiresAt <= Math.floor(Date.now() / 1000) || expiresAt > Math.floor(Date.now() / 1000) + 12 * 3600) return false;
  const expected = Buffer.from(signRoom(hostId, expiresAt, secret));
  const received = Buffer.from(match[2]);
  return expected.length === received.length && timingSafeEqual(expected, received);
}

router.post("/live/token", async (req, res): Promise<void> => {
  const url = process.env.VITE_SUPABASE_URL;
  const appId = process.env.VITE_AGORA_APP_ID;
  const certificate = process.env.AGORA_APP_CERTIFICATE;
  if (!appId || !certificate) {
    res.status(503).json({ error: "Live service is not configured." });
    return;
  }
  const parsed = IssueLiveTokenBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(422).json({ error: "A valid host and role are required." });
    return;
  }
  const { role, hostId, roomProof } = parsed.data;
  const identity = await verifyAppIdentity(req);
  if (!identity) {
    res.status(401).json({ error: "Sign in to join a live broadcast." });
    return;
  }
  try {
    if (role === "host" && hostId !== identity.id) {
      res.status(403).json({ error: "You can only broadcast from your own account." });
      return;
    }
    if (role === "viewer" && !validRoomProof(hostId, roomProof, certificate)) {
      if (identity.provider === "firebase") {
        res.status(403).json({ error: "A valid broadcast room proof is required." });
        return;
      }
      if (!url || !identity.supabaseHeaders) {
        res.status(503).json({ error: "Live status verification is not configured." });
        return;
      }
      const query = new URLSearchParams({ select: "last_seen_at", user_id: `eq.${hostId}`, is_live: "eq.true", limit: "1" });
      const status = await fetch(`${url.replace(/\/$/, "")}/rest/v1/live_users?${query}`, {
        headers: identity.supabaseHeaders,
        signal: AbortSignal.timeout(5_000),
      });
      if (!status.ok) {
        res.status(503).json({ error: "Live status is temporarily unavailable." });
        return;
      }
      const rows = await status.json() as { last_seen_at?: string }[];
      if (!rows[0]?.last_seen_at || Date.now() - Date.parse(rows[0].last_seen_at) > 60_000) {
        res.status(403).json({ error: "This broadcast has ended." });
        return;
      }
    }
    const uid = randomInt(1, 2 ** 32);
    const channel = `gs-live-${hostId}`;
    const token = RtcTokenBuilder.buildTokenWithUid(appId, certificate, channel, uid, role === "host" ? RtcRole.PUBLISHER : RtcRole.SUBSCRIBER, 3600, 3600);
    const expiresAt = Math.floor(Date.now() / 1000) + 12 * 3600;
    res.json(IssueLiveTokenResponse.parse({
      token,
      uid,
      channel,
      ...(role === "host" ? { roomProof: `${expiresAt}.${signRoom(hostId, expiresAt, certificate)}` } : {}),
    }));
  } catch {
    req.log.error("Could not issue live token");
    res.status(503).json({ error: "Live service is temporarily unavailable." });
  }
});

export default router;