import type { Request } from "express";
import type { AppIdentity } from "./app-identity";

type RateLimitWindow = {
  count: number;
  resetAt: number;
};

const windows = new Map<string, RateLimitWindow>();

export function checkRateLimit(
  req: Request,
  identity: AppIdentity | null,
  bucket: string,
  maximum: number,
  windowMs: number,
): { allowed: boolean; retryAfterSeconds: number } {
  const caller = identity
    ? `${identity.provider}:${identity.id}`
    : `ip:${req.ip || req.socket.remoteAddress || "unknown"}`;
  const key = `${bucket}:${caller}`;
  const now = Date.now();
  let current = windows.get(key);

  if (!current || current.resetAt <= now) {
    if (current) windows.delete(key);
    if (windows.size >= 5_000) {
      for (const [entryKey, entry] of windows) {
        if (entry.resetAt <= now) windows.delete(entryKey);
      }
      if (windows.size >= 5_000) {
        return { allowed: false, retryAfterSeconds: Math.max(1, Math.ceil(windowMs / 1000)) };
      }
    }
    current = { count: 0, resetAt: now + windowMs };
    windows.set(key, current);
  }

  if (current.count >= maximum) {
    return {
      allowed: false,
      retryAfterSeconds: Math.max(1, Math.ceil((current.resetAt - now) / 1000)),
    };
  }

  current.count += 1;
  return { allowed: true, retryAfterSeconds: 0 };
}