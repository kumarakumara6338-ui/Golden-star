import { createHash } from "node:crypto";
import type { Request } from "express";
import { createRemoteJWKSet, jwtVerify } from "jose";

export type AppIdentity = {
  provider: "supabase" | "firebase";
  id: string;
  supabaseHeaders?: {
    apikey: string;
    Authorization: string;
  };
};

const supabaseUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const firebaseConfigKeys = [
  "apiKey",
  "authDomain",
  "projectId",
  "appId",
  "storageBucket",
  "messagingSenderId",
  "measurementId",
] as const;
type FirebaseConfigKey = (typeof firebaseConfigKeys)[number];
type FirebaseConfigFields = Partial<Record<FirebaseConfigKey, string>>;
const firebaseJwks = createRemoteJWKSet(
  new URL("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com"),
  { timeoutDuration: 5_000, cooldownDuration: 30_000, cacheMaxAge: 10 * 60 * 1_000 },
);

function decodeStringLiteral(value: string, quote: "'" | '"'): string | undefined {
  let decoded = "";
  for (let index = 0; index < value.length; index += 1) {
    const character = value[index];
    if (character !== "\\") {
      decoded += character;
      continue;
    }

    index += 1;
    const escaped = value[index];
    if (escaped === undefined) return undefined;
    if (escaped === "\\" || escaped === "/" || escaped === quote || escaped === "'" || escaped === '"') {
      decoded += escaped;
    } else if (escaped === "n") {
      decoded += "\n";
    } else if (escaped === "r") {
      decoded += "\r";
    } else if (escaped === "t") {
      decoded += "\t";
    } else if (escaped === "b") {
      decoded += "\b";
    } else if (escaped === "f") {
      decoded += "\f";
    } else if (escaped === "v") {
      decoded += "\v";
    } else if (escaped === "0") {
      decoded += "\0";
    } else if (escaped === "u" || escaped === "x") {
      const digits = escaped === "u" ? 4 : 2;
      const code = value.slice(index + 1, index + 1 + digits);
      if (code.length !== digits || !/^[0-9a-f]+$/i.test(code)) return undefined;
      decoded += String.fromCharCode(Number.parseInt(code, 16));
      index += digits;
    } else {
      return undefined;
    }
  }
  return decoded;
}

function extractFirebaseConfigFields(source: string): FirebaseConfigFields | undefined {
  const keyPattern = firebaseConfigKeys.join("|");
  const keyOccurrencePattern = new RegExp(
    String.raw`(?:^|[,{;\n\r])\s*(?:"(${keyPattern})"|'(${keyPattern})'|(${keyPattern}))\s*:`,
    "g",
  );
  const occurrences = new Set<string>();
  let occurrence: RegExpExecArray | null;
  while ((occurrence = keyOccurrencePattern.exec(source)) !== null) {
    const key = occurrence[1] ?? occurrence[2] ?? occurrence[3];
    if (occurrences.has(key)) return undefined;
    occurrences.add(key);
  }

  const propertyPattern = new RegExp(
    String.raw`(?:^|[,{;\n\r])\s*(?:"(${keyPattern})"|'(${keyPattern})'|(${keyPattern}))\s*:\s*(?:"((?:\\.|[^"\\])*)"|'((?:\\.|[^'\\])*)')\s*(?=,|})`,
    "g",
  );
  const fields: FirebaseConfigFields = {};
  let match: RegExpExecArray | null;
  while ((match = propertyPattern.exec(source)) !== null) {
    const key = (match[1] ?? match[2] ?? match[3]) as FirebaseConfigKey;
    const value = match[4] !== undefined
      ? decodeStringLiteral(match[4], '"')
      : decodeStringLiteral(match[5], "'");
    if (value === undefined) return undefined;
    fields[key] = value.trim();
  }
  return fields;
}

function normalizedFirebaseConfig(
  fields: FirebaseConfigFields,
): FirebaseConfigFields | undefined {
  const required: FirebaseConfigKey[] = ["apiKey", "authDomain", "projectId", "appId"];
  const normalized: FirebaseConfigFields = {};
  for (const key of firebaseConfigKeys) {
    const value = fields[key];
    if (value === undefined) continue;
    const trimmed = value.trim();
    if (!trimmed) return undefined;
    normalized[key] = trimmed;
  }
  if (required.some((key) => !normalized[key])) return undefined;
  if (!/^[a-z0-9-]+$/.test(normalized.projectId ?? "")) return undefined;
  return normalized;
}

function firebaseProjectId(): string | undefined {
  const config = process.env.VITE_FIREBASE_CONFIG;
  if (!config) return undefined;

  let parsed: unknown;
  try {
    parsed = JSON.parse(config);
  } catch {
    const extracted = extractFirebaseConfigFields(config);
    return extracted ? normalizedFirebaseConfig(extracted)?.projectId : undefined;
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return undefined;

  const source = parsed as Record<string, unknown>;
  const extracted = extractFirebaseConfigFields(config);
  if (!extracted) return undefined;
  const fields: FirebaseConfigFields = {};
  for (const key of firebaseConfigKeys) {
    if (!Object.prototype.hasOwnProperty.call(source, key)) continue;
    const value = source[key];
    if (typeof value !== "string" || extracted[key] === undefined || extracted[key] !== value) {
      return undefined;
    }
    fields[key] = value.trim();
  }
  return normalizedFirebaseConfig(fields)?.projectId;
}

async function verifyFirebaseToken(token: string): Promise<AppIdentity | null> {
  const projectId = firebaseProjectId();
  if (!projectId) return null;

  try {
    const { payload } = await jwtVerify(token, firebaseJwks, {
      issuer: `https://securetoken.google.com/${projectId}`,
      audience: projectId,
      algorithms: ["RS256"],
    });
    if (typeof payload.sub !== "string" || payload.sub.trim().length === 0) {
      return null;
    }
    const digest = createHash("sha256")
      .update(`firebase:${projectId}:${payload.sub}`)
      .digest("hex")
      .slice(0, 32);
    return { provider: "firebase", id: `firebase-${digest}` };
  } catch {
    return null;
  }
}

async function verifySupabaseToken(
  token: string,
): Promise<AppIdentity | null> {
  const url = process.env.VITE_SUPABASE_URL;
  const key = process.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) return null;

  const supabaseHeaders = {
    apikey: key,
    Authorization: `Bearer ${token}`,
  };
  try {
    const response = await fetch(`${url.replace(/\/$/, "")}/auth/v1/user`, {
      headers: supabaseHeaders,
      signal: AbortSignal.timeout(5_000),
    });
    if (!response.ok) return null;
    const user: unknown = await response.json();
    if (!user || typeof user !== "object") return null;
    const id = (user as { id?: unknown }).id;
    if (typeof id !== "string" || !supabaseUuid.test(id)) return null;
    return { provider: "supabase", id, supabaseHeaders };
  } catch {
    return null;
  }
}

export async function verifyAppIdentity(
  req: Request,
): Promise<AppIdentity | null> {
  const authorization = req.get("authorization");
  const match = authorization && /^Bearer\s+(\S+)$/i.exec(authorization);
  if (!match) return null;

  const token = match[1];
  const firebaseIdentity = await verifyFirebaseToken(token);
  if (firebaseIdentity) return firebaseIdentity;
  return verifySupabaseToken(token);
}